"""Reject an I/O-only environment mismatch before a binding writes state."""
from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import Mock,patch
import unittest
from tools.research.core import bind

class IoBindingPreflight(unittest.TestCase):
    def test_package_mismatch_cannot_write_new_scientific_profile(self):
        old=dict(input=dict(policy={}),dependencies={'backend.test@1':dict(sources={},packages=dict(pydantic='2.14.0'))})
        new=deepcopy(old);new['dependencies']['backend.test@1']['packages']['pydantic']='2.13.5'
        study=dict(pending=None,freeze='original',spec=dict(runtime=dict(provider={})),
                   profile=dict(identity='original-profile',version=1,science_hashes={},execution_environment={}))
        host=SimpleNamespace(store=Mock(),reg=Mock(),run_id='unstarted-study')
        host.store.connect.return_value.__enter__=Mock(return_value=Mock())
        host.store.connect.return_value.__exit__=Mock(return_value=False)
        host.store.connect.return_value.__enter__.return_value.execute.return_value.fetchone.return_value=[0]
        host.store.session.return_value=dict(snapshot=old)
        before=deepcopy(study)
        with patch('tools.research.core.implementation_status',return_value=dict(worktree_dirty=False,project_commit='new')):
            with patch('tools.research.core.state',return_value=study),patch('tools.research.core.science_hashes',return_value={}):
                with patch('tools.platform_tasks.compile_input',return_value=new):
                    with self.assertRaisesRegex(ValueError,'IO_ONLY_BINDING_CANNOT_CHANGE_SCIENTIFIC_PROFILE'):
                        bind(host,reason='I/O repair only',store_io_only=True)
        self.assertEqual(study,before);host.store.transaction.assert_not_called();host.store.update_state.assert_not_called()

if __name__=='__main__':unittest.main()
