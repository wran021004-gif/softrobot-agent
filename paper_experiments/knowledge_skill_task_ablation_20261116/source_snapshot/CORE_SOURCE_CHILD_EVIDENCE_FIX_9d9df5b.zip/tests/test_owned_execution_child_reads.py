"""Sealed current-execution exports remain readable without cross-study grants."""
from copy import deepcopy
from types import SimpleNamespace
import json
import unittest
from unittest.mock import Mock,patch
from tools.research.core import read_evidence
from tools.research.evidence_policy import study_references
from tools.platform_store import plain

def ref(letter,media_type='application/json'):
    return dict(artifact_id=letter*64,media_type=media_type)

class OwnedExecutionChildReads(unittest.TestCase):
    def fixture(self):
        root,backend,manifest,foreign=map(ref,'abcd')
        observations=ref('e','application/octet-stream')
        result=dict(execution_id='native-execution',owner_run_id='owned-child',profile=None)
        study=dict(spec=dict(knowledge=dict(organization='typed_knowledge_v1')),results=[root],physical_replays=[])
        values={root['artifact_id']:result,backend['artifact_id']:dict(status='completed'),
                observations['artifact_id']:json.dumps([dict(time_s=0.5,measured=True)]).encode(),
                foreign['artifact_id']:dict(status='unrelated')}
        store=Mock();store.session.return_value=dict(state=study)
        store.events.return_value=[dict(outputs=[root])]
        store.artifact.side_effect=lambda reference,**kwargs:deepcopy(values[plain(reference)['artifact_id']])
        source=dict(owner='owned-child',metadata=dict(artifact_id=backend['artifact_id']),
                    manifest=manifest,files={'controller_observations.json':observations})
        return SimpleNamespace(store=store,run_id='current-study'),study,backend,observations,foreign,source

    def test_owned_backend_and_observation_are_readable_even_when_protected(self):
        host,study,backend,observations,foreign,source=self.fixture();before=deepcopy(study)
        with patch('extensions.tendon_family.control_evidence.ControlEvidence.resolve',return_value=source):
            with patch('tools.research.core.protected',return_value=True):
                self.assertEqual(read_evidence(host,dict(reference=backend,view='full'),record_read=False),dict(status='completed'))
                self.assertEqual(read_evidence(host,dict(reference=observations,view='full',pointer='/0'),record_read=False),dict(time_s=0.5,measured=True))
        self.assertEqual(study,before);host.store.event.assert_not_called();host.store.reserve.assert_not_called()

    def test_arbitrary_same_store_reference_is_still_rejected(self):
        host,study,backend,observations,foreign,source=self.fixture()
        with patch('extensions.tendon_family.control_evidence.ControlEvidence.resolve',return_value=source):
            with self.assertRaisesRegex(ValueError,'EVIDENCE_OUTSIDE_CURRENT_STUDY'):
                read_evidence(host,dict(reference=foreign,view='full'),record_read=False)

    def test_mismatched_execution_owner_never_grants_child_read(self):
        host,study,backend,observations,foreign,source=self.fixture();source['owner']='another-child'
        with patch('extensions.tendon_family.control_evidence.ControlEvidence.resolve',return_value=source):
            self.assertNotIn(backend,study_references(host))
            self.assertNotIn(observations,study_references(host))
            with self.assertRaisesRegex(ValueError,'EVIDENCE_OUTSIDE_CURRENT_STUDY'):
                read_evidence(host,dict(reference=observations,view='full'),record_read=False)

    def test_incorrect_reference_media_type_is_not_silently_reinterpreted(self):
        host,study,backend,observations,foreign,source=self.fixture()
        with patch('extensions.tendon_family.control_evidence.ControlEvidence.resolve',return_value=source):
            incorrect=dict(artifact_id=observations['artifact_id'],media_type='application/json')
            with self.assertRaisesRegex(ValueError,'EVIDENCE_OUTSIDE_CURRENT_STUDY'):
                read_evidence(host,dict(reference=incorrect,view='full'),record_read=False)

if __name__=='__main__':unittest.main()
