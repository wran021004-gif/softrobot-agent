"""Explicit operator recovery after an evidenced pre-simulation I/O stop."""
from tools.research.state import state,save,update


def prelaunch_io_failure(result):
    execution=result.get('execution') or {}
    receipt=execution.get('receipts',{}).get('simulation') or {}
    return (result.get('status')=='execution_incomplete' and result.get('acceptance') is None
        and execution.get('stage')=='simulation' and receipt.get('execution_status')=='failed'
        and receipt.get('solver_status')=='not_run' and '[WinError 206]' in str(receipt.get('error')))


def resume_after_prelaunch_io_stop(host,*,user_authorization,reason,reviewed_prior_replays=None,reviewed_reopening_basis=None):
    """Retain all charged costs/evidence; no scientific result is reclassified."""
    if user_authorization is not True or not reason:raise ValueError('EXPLICIT_OPERATOR_AUTHORIZATION_REQUIRED')
    s=state(host)
    if s['research_status']!='stopped' or s.get('selected') or s.get('success_gate') or s.get('pending'):
        raise ValueError('ONLY_UNSELECTED_STOPPED_IO_EPISODE_CAN_RESUME')
    with host.store.connect(True) as db:
        if db.execute('SELECT count(*) FROM calls WHERE receipt IS NULL').fetchone()[0]:raise ValueError('UNSEALED_OPERATION_RETAINS_HOLD')
    failures=[(ref,host.store.artifact(ref)) for ref in s.get('results',[])]
    if not failures or not all(prelaunch_io_failure(value) for _,value in failures):
        raise ValueError('EXACT_PRELAUNCH_IO_FAILURE_EVIDENCE_REQUIRED')
    complete=[ref for ref in s.get('physical_replays',[]) if (host.store.artifact(ref).get('profile') or {}).get('complete')]
    if complete:
        if complete!=reviewed_prior_replays:raise ValueError('COMPLETED_PHYSICAL_EPISODE_REQUIRES_SEPARATE_REVIEW')
        for ref in complete:
            acceptance=host.store.artifact(ref).get('acceptance') or {}
            if acceptance.get('accepted') is not False or acceptance.get('status')!='valid_failure':
                raise ValueError('PRIOR_PASS_OR_UNKNOWN_REPLAY_CANNOT_USE_FAILURE_REVIEW')
        stop=host.store.artifact(s['final_disposition'])['original_plan']
        explicit_repair_basis=not ('WinError 206' not in stop.get('interpretation','') or
                'repair' not in stop.get('weakening_observation','').lower() or
                'nmpc' not in stop.get('weakening_observation','').lower())
        if not explicit_repair_basis:
            # Operator-only review may bind a feedback reopening statement to
            # the exact original unstarted receipts cited by that same STOP.
            # Never infer permission merely from a failed scientific replay.
            basis=reviewed_reopening_basis or {}
            observation=stop.get('weakening_observation','')
            failure_refs=[ref for ref,_ in failures]
            if not (basis.get('original_final_disposition')==s['final_disposition']
                    and basis.get('failure_references')==failure_refs
                    and basis.get('original_weakening_observation')==observation
                    and basis.get('reason')
                    and 'feedback' in observation.lower() and 'reopen' in observation.lower()
                    and all(ref in stop.get('supporting_evidence',[]) for ref in failure_refs)):
                raise ValueError('STOP_MUST_EXPLICITLY_IDENTIFY_REPAIRED_NMPC_AS_REOPENING_BASIS')
    before=host.store.remaining(host.run_id)
    proof=save(host,dict(user_authorization=True,reason=reason,original_final_disposition=s.get('final_disposition'),
        original_closed_unix=s.get('closed_unix'),failure_references=[ref for ref,_ in failures],
        retained_costs=before,scientific_failure=False,new_scientific_executions=0,budgets_reset=False,
        reviewed_prior_complete_replays=complete,prior_valid_failures_retained_unchanged=True,
        reviewed_reopening_basis=reviewed_reopening_basis,
        operator_implementation=__import__('tools.paths',fromlist=['implementation_status']).implementation_status()['project_commit']),
        'operator_authorized_prelaunch_io_continuation')
    update(host,research_status='ready',final_disposition=None,closed_unix=None,
        interface_continuations=[*s.get('interface_continuations',[]),proof])
    assert before==host.store.remaining(host.run_id)
    return proof
