# Trace and cost specification

Format version: `main_replay_input_v1`. Source authority is the actual immutable Store and original provider ledger. No hand-authored successful replay input is provided in this phase.

## Decision and invocation events

`trace.decision` stores `event_id`, Study/task identities, actor, UTC timestamp, research question, concise public rationale, selected tool, next operation and evidence references. It does not request or store private chain-of-thought. Existing native Plan/analysis entries also retain their original public request before intent compilation mutates or projects it.

Every `Host.invoke` records the original ToolRequest, exact registered input/output schemas, parameter types, task/model/robot binding, receipt, output reference, status/error, actual start/completion time, wall time and host-process CPU time. Repeated request IDs reuse the original receipt and do not create duplicate execution cost. Rejected preflight requests are retained even if no reservation was charged. Cache reuse references the producer; new physics cost is zero.

Native Main Plan and mathematical dispatchers record their exact original arguments and entrypoint. Internal Worker request dictionaries are sealed before launch. Replay export traverses child sessions, retains candidate/evidence dependency graphs and lists any call without sufficient reconstruction material. Unknown calls remain unknown and are never automatically retried.

## Provider usage

The original provider boundary retains request/response artifacts and raw usage; export records:

```text
Core request_id, provider_request_id, actor/role, model, provider,
input_tokens, output_tokens, cached_input_tokens, reasoning_tokens,
total_tokens, retry metadata, timestamp, raw_usage
```

Conversation requests are grouped as Main; Reporter and other purposes remain separate. Responses API usage is read from the original upstream body rather than a derived chat view. Missing counts are `unavailable`, including aggregate fields with any missing component. No token, cache, reasoning, retry or monetary cost is estimated. The export contains usage counts, not private reasoning text.

## Resource dimensions and budgets

Charged budget and measured resources are separate. The original Store ledger remains authoritative for model/tool/worker/backend quotas and settled wall reservations. `research.dispatch` does not duplicate the original Plan's public-operation reservation. `research.math` charges its public wrapper once and retains the existing numerical/Worker admission. Static initial qualification uses the original mathematical counter when executed in a formal Study; offline static fixture checks are not Study solves.

Per-call records include wall-clock time, host-process CPU time, physical steps/launches when actually recorded, failed/rejected/unknown status and budget receipts. Worker CPU or unrecorded mathematics/iteration/verification counts are `unavailable`. Original mathematical evaluations, optimizer iterations/function evaluations, actual resource vectors, Worker timings and independent Replay costs are retained with exact source artifact/JSON Pointer through `recorded_cost_measurements` and original research counters. A charged allocation is not relabeled as a measured optimizer evaluation count.

`physics_steps` means completed `mj_step` calls, separately from attempted steps and static forward evaluations. Applied impulse is the sum of the actual preceding-step force times physical timestep; the current waveform sample is retained separately. Independent verification remains an explicitly labeled original execution role/cost, not inferred from a successful ordinary run.

`tool_operations` counts recorded invocation boundaries; `store_reservations` and `charged_tool_operations` expose the distinct ledger meanings. Failed calls include uncharged preflight rejections. Nested Main/Worker/Host wall times overlap and must not be summed. There is no undefined aggregate cost combining tokens, seconds, physics steps and mathematical evaluations.

## Export completeness and acceptance

The export includes Core commit/dirty flag, frozen SessionInputs/dependency identities, catalog protocol hash and bound task identity, tool sequence, complete requests/schemas/outputs, Worker requests, candidate/evidence dependencies, role usage, separate costs and final acceptance references. The actual saved success/selection/final-disposition gate is kept separate from the latest exploratory evaluation. Historical evaluator PASS never becomes `NEW_STUDY_PASS`.

An in-flight export can report its own request as not yet sealed. The settled CLI export is the final material for Main replay. The existing Core export also produces an immutable artifact archive; the JSON references that archive's content hashes rather than embedding every binary trajectory. Completeness flags are explicit; a partially recorded legacy Store is never declared fully reconstructible.
