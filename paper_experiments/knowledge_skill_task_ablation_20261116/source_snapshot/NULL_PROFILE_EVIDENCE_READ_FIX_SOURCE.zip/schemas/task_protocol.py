"""Serializable task protocols. No callback, controller code or historical answer."""
from typing import Annotated, Literal
from pydantic import Field, FiniteFloat, model_validator
from schemas.common import Contract

Vector3 = tuple[FiniteFloat, FiniteFloat, FiniteFloat]
Name = Annotated[str, Field(pattern=r'^[A-Za-z][A-Za-z0-9_]*$')]


class ReferenceGenerator(Contract):
    version: Literal['reference_generator_v1'] = 'reference_generator_v1'
    kind: Literal['constant', 'figure_eight', 'quintic_nodes']
    frame: Literal['world'] = 'world'
    units: Literal['m'] = 'm'
    center_m: Vector3
    amplitude_y_m: FiniteFloat = Field(default=0, ge=0)
    amplitude_z_m: FiniteFloat = Field(default=0, ge=0)
    frequency_hz: FiniteFloat = Field(default=.1, gt=0)
    cycles: int = Field(default=2, gt=0)
    phase_rad: FiniteFloat = 0
    start_ramp_s: FiniteFloat = Field(default=0, ge=0)
    stop_ramp_s: FiniteFloat = Field(default=0, ge=0)
    duration_s: FiniteFloat = Field(gt=0)
    times_s: list[FiniteFloat] = Field(default_factory=list)
    positions_m: list[Vector3] = Field(default_factory=list)
    prediction_tail: Literal['hold_endpoint'] = 'hold_endpoint'

    @model_validator(mode='after')
    def definition(self):
        if self.start_ramp_s + self.stop_ramp_s > self.duration_s:
            raise ValueError('REFERENCE_RAMPS_OVERLAP')
        if self.kind == 'figure_eight':
            effective = self.duration_s - (self.start_ramp_s + self.stop_ramp_s)/2
            if abs(self.frequency_hz*effective-self.cycles)>1e-10:
                raise ValueError('FIGURE_EIGHT_PHASE_DURATION_CYCLE_MISMATCH')
        if self.kind == 'quintic_nodes':
            if (len(self.times_s)<2 or len(self.times_s)!=len(self.positions_m)
                    or self.times_s[0]!=0 or self.times_s[-1]!=self.duration_s
                    or any(a>=b for a,b in zip(self.times_s,self.times_s[1:]))):
                raise ValueError('REFERENCE_ORDERED_COMPLETE_NODES_REQUIRED')
        elif self.times_s or self.positions_m:
            raise ValueError('NODES_REQUIRE_QUINTIC_REFERENCE')
        return self


class Wrench(Contract):
    version: Literal['world_com_wrench_v1'] = 'world_com_wrench_v1'
    entity: Name
    frame: Literal['world'] = 'world'
    point: Literal['center_of_mass'] = 'center_of_mass'
    force_n: Vector3
    torque_nm: Vector3 = (0., 0., 0.)
    start_s: FiniteFloat = Field(ge=0)
    end_s: FiniteFloat = Field(gt=0)
    waveform: Literal['constant', 'half_sine', 'linear', 'smoothstep'] = 'constant'

    @model_validator(mode='after')
    def window(self):
        if self.end_s<=self.start_s:raise ValueError('WRENCH_WINDOW_REQUIRED')
        return self


class ContactGeometry(Contract):
    name: Name
    body: Name
    kind: Literal['sphere', 'box', 'cylinder', 'capsule']
    position_m: Vector3 = (0.,0.,0.)
    quaternion_wxyz: tuple[FiniteFloat, FiniteFloat, FiniteFloat, FiniteFloat] = (1.,0.,0.,0.)
    size_m: list[FiniteFloat] = Field(min_length=1,max_length=3)
    contype: int = Field(default=1,ge=0)
    conaffinity: int = Field(default=1,ge=0)

    @model_validator(mode='after')
    def dimensions(self):
        if len(self.size_m)!={'sphere':1,'box':3,'cylinder':2,'capsule':2}[self.kind] or min(self.size_m)<=0:
            raise ValueError('CONTACT_GEOMETRY_SIZE_MISMATCH')
        if abs(sum(v*v for v in self.quaternion_wxyz)-1)>1e-10:
            raise ValueError('CONTACT_QUATERNION_MUST_BE_UNIT_WXYZ')
        return self


class EnvironmentBody(Contract):
    name: Name
    position_m: Vector3
    quaternion_wxyz: tuple[FiniteFloat,FiniteFloat,FiniteFloat,FiniteFloat] = (1.,0.,0.,0.)
    mass_kg: FiniteFloat = Field(gt=0)
    com_local_m: Vector3 = (0.,0.,0.)
    inertia_com_local_kg_m2: tuple[Vector3,Vector3,Vector3]
    joint_name: Name
    joint_kind: Literal['slide','hinge'] = 'slide'
    axis_local: Vector3
    joint_range: tuple[FiniteFloat,FiniteFloat]
    stiffness: FiniteFloat = Field(ge=0,description='N/m for a slide; N.m/rad for a hinge.')
    damping: FiniteFloat = Field(ge=0,description='N.s/m for a slide; N.m.s/rad for a hinge.')
    spring_reference: FiniteFloat = 0
    initial_position: FiniteFloat = 0
    initial_velocity: FiniteFloat = 0

    @model_validator(mode='after')
    def physics(self):
        import numpy as np
        tensor=np.asarray(self.inertia_com_local_kg_m2)
        if abs(sum(v*v for v in self.quaternion_wxyz)-1)>1e-10:raise ValueError('ENVIRONMENT_BODY_QUATERNION_MUST_BE_UNIT_WXYZ')
        if not np.allclose(tensor,tensor.T,rtol=0,atol=1e-15) or min(np.linalg.eigvalsh(tensor))<=0:
            raise ValueError('POSITIVE_SYMMETRIC_FULL_INERTIA_REQUIRED')
        if abs(sum(v*v for v in self.axis_local)-1)>1e-10 or not self.joint_range[0]<self.joint_range[1]:
            raise ValueError('UNIT_AXIS_AND_ORDERED_RANGE_REQUIRED')
        if not self.joint_range[0]<=self.initial_position<=self.joint_range[1]:
            raise ValueError('INITIAL_ENVIRONMENT_JOINT_OUTSIDE_RANGE')
        return self


class ContactPair(Contract):
    geom1: Name
    geom2: Name
    condim: Literal[1,3,4,6] = 1
    friction: tuple[FiniteFloat,FiniteFloat,FiniteFloat,FiniteFloat,FiniteFloat] = (0.,0.,0.,0.,0.)
    solref: tuple[FiniteFloat,FiniteFloat] = (.003,1.)
    solimp: tuple[FiniteFloat,FiniteFloat,FiniteFloat] = (.98,.995,.0001)


class ObservationSite(Contract):
    name: Name
    body: Name
    position_m: Vector3


class PhysicalEnvironment(Contract):
    version: Literal['physical_environment_v1'] = 'physical_environment_v1'
    bodies: list[EnvironmentBody] = Field(default_factory=list)
    geometries: list[ContactGeometry] = Field(default_factory=list)
    contact_pairs: list[ContactPair] = Field(default_factory=list)
    wrenches: list[Wrench] = Field(default_factory=list)
    replace_robot_geometries: list[Name] = Field(default_factory=list)
    sites: list[ObservationSite] = Field(default_factory=list)
    collision_policy: Literal['native_default','self_environment_frictionless'] = 'native_default'
    solver_iterations: int | None = Field(default=None,gt=0)
    solver_tolerance: FiniteFloat | None = Field(default=None,gt=0)
    input_freeze_after_s: FiniteFloat | None = Field(default=None,ge=0,
        description='Independent environment control condition; hold the actual preceding input, without calling feedback after this time.')
    robot_hinge_range_rad: tuple[FiniteFloat,FiniteFloat] | None = None
    actuator_min_tension_n: FiniteFloat | None = Field(default=None,ge=0)

    @model_validator(mode='after')
    def unique(self):
        for names in ([b.name for b in self.bodies],[b.joint_name for b in self.bodies],[g.name for g in self.geometries]):
            if len(names)!=len(set(names)):raise ValueError('UNIQUE_ENVIRONMENT_NAMES_REQUIRED')
        if self.robot_hinge_range_rad and self.robot_hinge_range_rad[0]>=self.robot_hinge_range_rad[1]:
            raise ValueError('ORDERED_ROBOT_HINGE_RANGE_REQUIRED')
        pairs=[frozenset((p.geom1,p.geom2)) for p in self.contact_pairs]
        if len(pairs)!=len(set(pairs)):raise ValueError('DUPLICATE_NATIVE_CONTACT_PAIR')
        return self


class SourceFile(Contract):
    path: str
    sha256: str = Field(pattern=r'^[a-f0-9]{64}$')


class Acceptance(Contract):
    version: Literal['task_acceptance_v1'] = 'task_acceptance_v1'
    evaluator: Literal['reach_hold','figure_eight','tool_axis','oriented_tracking','passive_program','contact_press','impact_recovery']
    parameters: dict
    source_files: list[SourceFile] = Field(min_length=1)
    required_signals: list[str] = Field(min_length=1)
    grid: Literal['physics_including_initial','formal_post_step']
    historical_status: str | None = None
    task_id: str | None = Field(default=None,pattern=r'^T(0[1-9]|10)$')


class ProtocolCase(Contract):
    condition_id: Name
    role: Literal['required','control'] = 'required'
    task: dict
    acceptance: Acceptance
    environment_extension: PhysicalEnvironment | None = None
    independent_channels: int = Field(ge=0)
    initial_state_source: str
    structure_sources: list[SourceFile]


class TaskProtocol(Contract):
    version: Literal['core_task_protocol_v1'] = 'core_task_protocol_v1'
    task_id: str = Field(pattern=r'^T(0[1-9]|10)$')
    name: str
    source_repository: Literal['wran021004-gif/softrobot-demo-showcase'] = 'wran021004-gif/softrobot-demo-showcase'
    source_commit: Literal['2e5d1088746df0916e2a7ec60f4780998c6ba004'] = '2e5d1088746df0916e2a7ec60f4780998c6ba004'
    source_status: str
    cases: list[ProtocolCase] = Field(min_length=1)
    reference: ReferenceGenerator | None = None
    algorithm_bindings: list[str]
    restrictions: list[str]

    @model_validator(mode='after')
    def case_ids(self):
        if len({c.condition_id for c in self.cases})!=len(self.cases):raise ValueError('UNIQUE_PROTOCOL_CASE_IDS_REQUIRED')
        if not any(c.role=='required' for c in self.cases):raise ValueError('REQUIRED_PROTOCOL_CASE_MISSING')
        return self


class ObservationDefinition(Contract):
    dimension: int = Field(gt=0)
    units: str
    frame: str
    phase: str
    source: str


class TaskEvidence(Contract):
    version: Literal['core_task_evidence_v1'] = 'core_task_evidence_v1'
    task_identity: str = Field(pattern=r'^[a-f0-9]{64}$')
    origin: Literal['core_execution'] = 'core_execution'
    design_identity: str
    physics_identity: str
    controller_identity: str | None = None
    model_xml_sha256: str = Field(pattern=r'^[a-f0-9]{64}$')
    tendon_order: list[str]
    joint_layout: list[dict]
    arrays: dict[str,list]
    signal_definitions: dict[str,ObservationDefinition]
    environment_states: list[dict | None]
    applied_wrench_history: list[list[dict]]
    timing: dict
    physics_steps: int = Field(ge=0)

    @model_validator(mode='after')
    def complete_metadata(self):
        if set(self.arrays)!=set(self.signal_definitions):raise ValueError('EVERY_OBSERVATION_REQUIRES_UNITS_FRAME_PHASE_AND_SOURCE')
        n=len(self.arrays.get('time_s',[]))
        if any(len(v)!=n for v in self.arrays.values()) or n!=self.physics_steps+1:
            raise ValueError('DENSE_PHYSICAL_EVIDENCE_TIME_COVERAGE_REQUIRED')
        return self
