"""Developer protocols; concrete serialized state still uses registry contracts."""
from typing import Protocol
from schemas.platform import Payload, BackendResult, EvaluationResult, SessionInput, TaskDefinition, EvidenceRef, RobotDescription, Signal
from schemas.platform_math import (DynamicSystem, LinearizedModel, MathematicalModel,
    OptimizationProblem, OptimizationResult, OptimizationSpecification, ParameterDefinitions, SystemContext)
from schemas.platform_learning import RLProblem, RLTrainingSpecification, TrainingJob, TrainingResult


class ModelAdapter(Protocol):
    """1.0 text transport. Registry declares real_requests, timeout and cancellation."""
    adapter_id: str
    def encode(self, model_input, config) -> dict: ...
    def respond(self, serialized_request: dict, turn: int): ...
    def decode(self, response, turn: int, tool_bindings: dict): ...


class AgentStrategy(Protocol):
    """1.0 typed action selection; no execution or accounting authority."""
    def decide(self, decoded, context): ...


class CandidateBuilder(Protocol):
    """Receives a private copy; edits declared design/control/model/discretization data.

    Task and extension bindings (identity, version, parameter contract) stay fixed.
    """
    def __call__(self, baseline: SessionInput, parameters, changes: dict[str, object]) -> SessionInput: ...


class Worker(Protocol):
    """WorkerOutput 2.0; own child session, common restricted execution client."""
    def __call__(self, order, parameters, fixed_input, client): ...


class WorkerResultChecker(Protocol):
    def __call__(self, order, output, source, registry, evidence: list): ...


class OneShotBackend(Protocol):
    """All execution adapters normalize native data to BackendResult + Signal."""
    @staticmethod
    def check(inp: SessionInput, parameters, control) -> None: ...
    def compile(self, inp: SessionInput, registry) -> None: ...
    def initialize(self, initial: Payload, controller) -> None: ...
    def run(self, **declared_options) -> BackendResult: ...
    def close(self) -> None: ...


class SteppingBackend(OneShotBackend, Protocol):
    def step(self) -> None: ...
    def observe(self) -> list[Signal]: ...
    def export(self) -> BackendResult: ...
    def cancel(self) -> None: ...


class Controller(Protocol):
    """Model dependency is Extension.capabilities['model_requirement'].

    The value is a platform_math.ModelRequirement; omission defaults to 'none'.
    Existing controller objects need no new attribute or lifecycle method.
    """
    def reset(self) -> None: ...
    def restore(self, state) -> None: ...
    def command(self, time_s: float, observations): ...
    def finish(self, interrupted: bool = False) -> None: ...
    def checkpoint(self) -> Payload: ...


class Search(Protocol):
    """Expensive black-box ask/tell search; evaluations remain Host-owned."""
    def propose(self) -> dict[str, float]: ...
    def feedback(self, score: float | None) -> None: ...
    def stopped(self) -> bool: ...
    def save(self) -> Payload: ...
    def restore(self, state) -> None: ...


class Solver(Protocol):
    """Registered as solver, independently of Search and backend execution."""
    def solve(self, problem: OptimizationProblem) -> OptimizationResult: ...


class RLTrainer(Protocol):
    """Registered as rl_trainer; persistent lifecycle, independent of Search.

    start seals problem/specification in the existing Store before returning a
    durable job identity. A freshly bound adapter must accept a restored job for
    status/cancel/collect, using existing Worker facilities or its external handle.
    Unknown/unconfirmed status stays unknown; collect requires explicit artifacts
    and gates rather than inferring success from a process exit code.
    """
    def start(self, problem: RLProblem, specification: RLTrainingSpecification) -> TrainingJob: ...
    def status(self, job: TrainingJob) -> TrainingJob: ...
    def cancel(self, job: TrainingJob) -> TrainingJob: ...
    def collect(self, job: TrainingJob) -> TrainingResult: ...


class OptimizationAssembler(Protocol):
    """Trusted deterministic templates, registered as optimization_assembler.

    space is the authorized path/specification projection of existing Space
    parameter maps, not Agent-supplied bounds. Template IDs are declared in
    Extension.capabilities['supported_objectives'/'supported_constraints'].
    Use tools.platform_optimization.assemble_optimization for checked dispatch.
    """
    def assemble(self, task: TaskDefinition, robot: RobotDescription,
                 space: ParameterDefinitions, mathematical_model: MathematicalModel,
                 specification: OptimizationSpecification, context: SystemContext) -> OptimizationProblem: ...


class KinematicsProvider(Protocol):
    """Forward kinematics provider using a typed model-specific request."""

    def forward(
        self,
        robot: RobotDescription,
        request: Payload,
        registry,
    ) -> Payload: ...


class DynamicSystemProvider(Protocol):
    """Export using explicit context.x0/u0; resolve scene via its existing contract."""
    def build_system(self, robot: RobotDescription, parameters: Payload,
                     discretization: Payload | None, context: SystemContext) -> DynamicSystem: ...


class Linearizer(Protocol):
    """Linearize at explicit system.x0/u0 from SystemContext; never infer a point.

    To select another operating point, export a system with that context first.
    """
    def linearize(self, system: DynamicSystem) -> LinearizedModel: ...


class ModelBasedController(Controller, Protocol):
    """Optional setup for controllers declaring a public model dependency."""
    def configure_model(self, model: MathematicalModel | DynamicSystem | LinearizedModel) -> None: ...


class Evaluator(Protocol):
    def __call__(self, task: TaskDefinition, result: BackendResult, source: EvidenceRef, registry,
                 comparison_identity: str) -> EvaluationResult: ...
