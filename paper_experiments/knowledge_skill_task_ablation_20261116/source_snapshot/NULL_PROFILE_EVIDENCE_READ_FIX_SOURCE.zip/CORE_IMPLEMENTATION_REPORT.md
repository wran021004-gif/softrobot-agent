# Core implementation report

Base: `2c83f8b7bd654328dd7648f844295c54a7c15223`. Branch: `codex/ten-task-core-interfaces-20261112`. Version: 0.2.0. The Git commit containing this report is the unified deliverable; main is unchanged.

## Implemented

| Modules | Change and purpose |
|---|---|
| schemas/task_protocol.py, schemas/platform.py | Frozen multi-case protocol, safe reference/environment/observation contracts and additive task acceptance |
| tools/task_protocols.py, extensions/task_protocol/manifest.py | Registered discovery/binding/evaluation/aggregation, candidate lineage, source checks and unified backend declaration |
| extensions/reference/generators.py | Analytical figure-eight integrated speed ramps, derivatives and safe quintic/constant references |
| extensions/reference/protocol_evaluation.py | Complete original hold/axis/tracking/contact/recovery constraints, grids, margins and failure reasons |
| extensions/tendon_family/environment.py, mjcf.py, compiler.py, scene.py | Native moving bodies, extra joints, full inertia, pair contact, spring/damper, COM wrenches, frozen-input control condition and tip-frame rotation |
| extensions/tendon_family/task_observations.py, contracts.py, backends.py | Dense typed robot/environment observations, true contact force and actual force/impulse history in the existing physical lifecycle |
| gvs_nmpc.py, gvs_profile.py, gvs_trajectory.py | Existing controller consumes safe references and task lower tension bounds; prepared initial input; blind M7 views/reference clock. No control or optimization algorithm added |
| generated_serial.py, tools/research/design.py | Preserve source-authorized generation and allow a separately qualified prepared initial state with immutable parent lineage |
| tools/research/protocol_adapter.py, protocol_tools.py, registry_bridge.py, config.py, agent.py | Existing task/Main interfaces expose granted schemas and delegate to original method/permission/budget/Worker paths |
| tools/research/evidence_views.py | Reporter result cards retain actual hard checks, margins, failures and historical origin |
| tools/research/replay_export.py, platform_host.py, core.py, analysis.py, execution.py, mechanics.py, physical_replay.py, provider.py | Capture exact public/native/Worker inputs, role usage and scoped costs; export real Store-derived replay material |
| tools/research/state.py | New scientific source/asset hashes enter original binding/migration guards |
| tools/development/, tests/ | Reproducible source freezing, offline oracles, actual result reports and guarded contract/Host/static-model tests |

## Reused unchanged algorithms

The existing FamilySpace/generator, GVS NMPC, native sequence search, model/solver Registry, passive equilibrium/KKT/tangent/compliance/sensitivity machinery, passive staged backend/evaluator, Host budget ledger, Store and Main/Reporter architecture remain the research machinery. There is no new optimizer, task-local solver, LQR, tension-allocation search, copied C009 controller, copied M7 controller or historical feedforward default.

Task data is taken from the pinned Showcase commit. P3 reuses a source-hash-verified prior Core task translation. No related development branch was merged wholesale. Account/resume fixes, ablation setups, experimental states, credentials, historical Stores, PHS2D data and successful candidates are not imported.

## Limits and final acceptance

The interface readiness report distinguishes available code from offline evidence. T08's complete original raw qualification/route/mechanism/confirmation evidence is missing from the frozen Showcase; it remains `NOT_CORE_RESEARCH_READY` under the requested strict eleven-gate rule. Its source status remains `development_not_registered_SELECT`. No raw data or equivalence claim is fabricated.

NativeModel mathematics still rejects dynamic contact/extra joint state. T09 can use existing nominal GVS geometry/statics/position control and the full native environment/evaluator; contact-aware native optimization was not invented. T05/T06 continue to require the existing native sequence/physical Replay route for tool-axis objectives; full pose NMPC remains unsupported. These restrictions are exposed in admission/discovery and do not claim new task performance.

Actual test counts, failures fixed during development, dependency versions and zero-execution boundaries are in `TEST_REPORT.md` / `TEST_RESULTS.json`. Historical regression details are in `EVALUATOR_REGRESSION_REPORT.md` / its JSON. No formal Main Study, Provider request, candidate search, optimizer execution, real Worker, trajectory integration, new successful structure or Main replay was performed. Static XML/forward checks and Mock tests are identified explicitly.

## Compatibility and use

Optional fields preserve legacy serialization when absent/default. New schemas and source hashes intentionally change immutable dependency identities; this work does not migrate or resume existing Studies. The original Core checkout and installed environment are not replaced. Use this branch/worktree or its packaged 0.2.0 wheel in the separately authorized next phase, freeze its final commit and grant only the required Registry tools.

`TEN_TASK_READINESS.json` is the machine-readable gate matrix. Overall ten-task acceptance remains incomplete solely where its report lists an evidence-source blocker; historical PASS and future Study PASS are separate states.

## P3 recovery follow-up (0.2.1)

Registered `evidence.passive_history.audit` verified the original Store and task hashes, recovered all eight CSV cases (1,600,000 physical-step rows), reran the exact source evaluator and compared existing Core v2 stiffness metrics. The original Store/family/model identities are retained in `T08_HISTORICAL_RECOVERY_RESULTS.json`. Legacy complete integration-state/current binding proofs are still absent, so no raw legacy result becomes a current Core execution or new Study pass.

The existing passive CSV now appends actual force-point world position/velocity/displacement, all constraint rows/classifications, cumulative route-check state and solver warm state on each completed step. The original integration/qualification/evaluator paths remain in use. New registered source identities include this recording module. See `T08_HISTORICAL_EVIDENCE_RECOVERY.md`.

The first surrogate Study preparation exposed strict composition rejecting `registry_tools` before grants were applied. Version 0.2.2 extracts this optional field before the legacy strict merge and preserves explicit grants in the resolved specification. A full offline generic prepare/bind/Registry-Host/Plan/generator regression now covers this real entrypoint. No new scientific candidate, optimizer or physical integration had started when the issue was found; the batch is refrozen before solving.
# 2026-11-13 interrupted-batch metadata repair

T01 exposed an interaction between the registered exact-task adapter and frozen multi-condition aliasing. The alias copied `protocol_binding` for central_high while changing to negative_low; strict verification correctly rejected the contradictory proof. The repair leaves the exact parent unchanged, removes that inherited proof from the new alias, and uses the existing authorized frozen-condition verifier. A specifically identified invalid legacy alias can be replaced without deleting its artifact or failure evidence.

The batch stopped at this settled boundary. No controller, mathematical kernel, physical model, task threshold or Evaluator changed. Scientific hashes/dependencies remain identical. Implementation migration must be explicit, preserve earlier execution SHA fields and cumulative costs, and rerun the affected request before continuing. T08's original developer classification and historical equivalence boundary remain unchanged.
