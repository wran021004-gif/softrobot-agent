"""Representative Main-visible native feedback and long-path evidence export."""
from copy import deepcopy
import json,os,gc,shutil,unittest
from pathlib import Path
from uuid import uuid4
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('SOFTROBOT_AGENT_HOME',str(ROOT/'.offline-home'))

class NativeFeedbackInterface(unittest.TestCase):
    def test_registered_controller_host_simulation_and_profile(self):
        from tools.platform_host import Host
        from tools.research.protocol_tools import freeze_registry_tools
        from tools.task_protocols import load
        from tools.platform_registry import registry
        from schemas.platform import ProjectConfig
        from extensions.tendon_family.native_feedback import NativeFeedbackControl
        from tools.platform_store import plain
        from tools.state_io import io_path
        cfg=json.loads((ROOT.parent/'showcase-ten-task-reference-20261112/M2_loaded_hold/zero/configuration.json').read_text(encoding='utf8'))
        cfg['run_id']='native-feedback-'+uuid4().hex
        case=next(c for c in load('T10').cases if c.condition_id=='no_impulse')
        cfg['task']=deepcopy(case.task);cfg['task']['acceptance']=plain(case.acceptance)
        cfg['task']['environment']['data']['physical_environment']=plain(case.environment_extension)
        cfg['policy']['backend']['version']='1.5.0'
        cfg['policy']['controller']=dict(extension_id='controller.native_state_feedback',version='1.0.0',parameters=dict(contract='family.native_feedback_control',version='1.0.0',data=plain(NativeFeedbackControl())))
        from tools.research.design import family_configuration,numerical_binding
        from tools.state_io import digest
        archive=ROOT.parents[1]/'paper_experiments/five_task_completion_20261113/T10_M7_impact_recovery'
        space=json.loads((archive/'FAMILY_SPACE.json').read_text());generation=json.loads((archive/'TASK_FIXED_HARDWARE_GENERATION.json').read_text())['generation']
        generation.update(family_space_identity=digest(space),control_weights=dict(holding_tip_speed_weight=.5,terminal_tip_speed_weight=0.));generation.pop('controller_recipe',None)
        cfg,_,_=family_configuration(cfg,space,generation,cfg['run_id'])
        from extensions.tendon_family.native_feedback import resolve_control
        from extensions.tendon_family.backends import physics_for
        from schemas.platform import SessionInput
        identities=[]
        for original in load('T10').cases:
            variant=deepcopy(cfg);variant['run_id']=uuid4().hex;variant['task']=deepcopy(original.task)
            variant['task']['acceptance']=plain(original.acceptance);variant['task']['environment']['data']['physical_environment']=plain(original.environment_extension)
            inp=SessionInput.model_validate(variant);identities.append(resolve_control(inp,physics_for(inp))['identity'])
        self.assertEqual(len(set(identities)),1)
        from extensions.tendon_family.gvs_profile import mathematical_numerical
        from schemas.platform import SessionInput
        view=mathematical_numerical(SessionInput.model_validate(cfg));self.assertEqual(view['coordinate_space'],'native_named_hinges')
        self.assertEqual(len(view['measured_initial_state']),2*len(view['coordinate_order']));self.assertIsNotNone(numerical_binding(cfg,{}))
        cfg['policy']['budget'].update(model_calls=0,backend_solves=1,worker_calls=0,tool_calls=6,wall_s=None)
        for name in ['simulation.run','evaluation.run','control.profile_report']:
            cfg['policy']['tool_bindings'][name]='1.0.0'
            if name not in cfg['policy']['allowed_tools']:cfg['policy']['allowed_tools'].append(name)
            cfg['policy'].setdefault('operation_allowances',{})[name]=dict(timeout_s=None,reserve_s=None)
        schema=registry().get('controller.native_state_feedback','1.0.0','controller').input_schema.model_json_schema()
        self.assertIn('NativeFeedbackRecipe',schema['$defs'])
        folder=ROOT/'.offline-home'/('native-feedback-'+uuid4().hex);io_path(folder).mkdir(parents=True)
        try:
            h=Host(folder,cfg['run_id'],actor='targeted-interface-test')
            h.store.create(ProjectConfig(project_id=cfg['run_id'],grant_id='feedback-'+uuid4().hex,authorization_source='User-requested representative native feedback interface test; one native simulation, no Provider.',budget=cfg['policy']['budget']))
            h.create(cfg)
            sim=h.invoke(dict(request_id='native-simulation',tool_id='simulation.run',arguments=dict(candidate_id='representative',changes={}),reason='Representative executable registered native state feedback',cache='new'))
            self.assertEqual(sim['execution_status'],'completed',sim.get('error'))
            result=h.store.artifact(sim['output']);self.assertEqual(result['solver_status'],'completed')
            evaluation=h.invoke(dict(request_id='native-evaluation',tool_id='evaluation.run',arguments=dict(result=sim['output'],execution_id=sim['execution_id']),reason='Original full independent evaluator',cache='new'))
            self.assertEqual(evaluation['execution_status'],'completed',evaluation.get('error'))
            report=h.invoke(dict(request_id='native-profile',tool_id='control.profile_report',arguments=dict(simulation_request_id='native-simulation',evaluation_request_id='native-evaluation'),reason='Sealed evidence and original control profile',cache='new'))
            self.assertEqual(report['execution_status'],'completed',report.get('error'))
            detail=h.store.artifact(report['output'])['detail'];self.assertEqual(detail['controller_class'],'native_state_feedback')
            self.assertEqual(detail['actual_feedback_updates'],100);self.assertEqual(detail['actual_solver_calls'],0)
            self.assertTrue(detail['complete']);self.assertFalse(detail['real_time_demonstrated'])
            prep=h.store.artifact(detail['native_feedback_preparation']);self.assertEqual(prep['physics_steps'],0)
            self.assertEqual(len(prep['equilibrium_diagnostics']),2);self.assertTrue(np.isfinite(prep['K']).all())
            from tools.research.feedback import solution_identity
            from tools.research.design import full_science
            identity=solution_identity(h,{},dict(configuration=cfg,scientific_configuration=full_science(cfg)))
            self.assertEqual(identity['controller']['algorithm'],'native_state_feedback')
            self.assertIn('bank_stroke_weight',identity['controller']['configuration']['parameters']['data']['recipe'])
        finally:
            gc.collect();folder.resolve().relative_to((ROOT/'.offline-home').resolve());shutil.rmtree(io_path(folder))

    def test_required_passes_and_failed_controls_remain_separate(self):
        from unittest.mock import patch
        from types import SimpleNamespace
        from tools.research.conditions import joint_view
        refs=[{'artifact_id':str(i),'media_type':'application/json'} for i in range(5)]
        def row(i):
            return dict(solution_identity={'id':i},complete=True,passed=i<3,task_gap=dict(normalized_gap=0 if i<3 else 1,components={},valid_complete=True,dominant_constraints=[]),failed_metrics=[] if i<3 else [{'metric':'final_hold_speed'}],controller={'route':'nmpc'},fresh_current_study=True,costs={})
        rows=[row(i) for i in range(5)];value=dict(candidate=refs[0],condition_results=refs,required_condition_results=refs[:3],control_condition_results=refs[3:],condition_roles={str(i):'required' if i<3 else 'control' for i in range(5)},aggregation=dict(version='1.0.0',all_scheduled_accepted=True,schedule=[{'case_id':str(i)} for i in range(3)]),costs={})
        host=SimpleNamespace(store=SimpleNamespace(artifact=lambda ref:value))
        with patch('tools.research.feedback.result_view',side_effect=lambda host,ref:deepcopy(rows[int(ref['artifact_id'])])):
            result=joint_view(host,refs[0]);self.assertTrue(result['passed']);self.assertEqual(len(result['control_outcomes']),2)
            self.assertTrue(all(r['original_task_passed'] is False for r in result['control_outcomes']));self.assertFalse(result['controls_counted_as_required_passes'])
            rows[-1]['complete']=False;self.assertFalse(joint_view(host,refs[0])['passed'])

if __name__=='__main__':unittest.main()
