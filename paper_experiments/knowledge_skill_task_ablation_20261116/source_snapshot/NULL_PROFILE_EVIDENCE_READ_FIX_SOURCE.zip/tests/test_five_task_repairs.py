"""Targeted interface and physical-assembly checks; no integration or Provider."""
from copy import deepcopy
from io import BytesIO
import json,os,unittest
from contextlib import contextmanager
from uuid import uuid4
import gc,shutil
from pathlib import Path
import numpy as np
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('SOFTROBOT_AGENT_HOME',str(ROOT/'.offline-home'))
REF=ROOT.parent/'showcase-ten-task-reference-20261112'
ARCHIVE=ROOT.parents[1]/'paper_experiments/five_task_completion_20261113'
from tools.platform_store import plain
from tools.state_io import digest
from extensions.tendon_family.family_space import FamilySpaceV2
from extensions.tendon_family.contracts import Design
from extensions.tendon_family.generated_serial import generate_family
from extensions.tendon_family.mjcf import compile_xml,load_model
from extensions.tendon_family.scene import assemble_physical
from schemas.platform import SessionInput

def read(p):return json.loads(p.read_text(encoding='utf8'))

@contextmanager
def fixture_directory():
    folder=ROOT/'.offline-home'/('five-'+uuid4().hex);folder.mkdir(parents=True)
    try:yield str(folder)
    finally:
        gc.collect();folder.resolve().relative_to((ROOT/'.offline-home').resolve());shutil.rmtree(folder)

class FiveTaskRepairs(unittest.TestCase):
    def test_legacy_design_and_space_identity(self):
        d=read(REF/'M2_loaded_hold/zero/configuration.json')['robot']['structure']['data']
        self.assertEqual(digest(d),digest(plain(Design.model_validate(d))))
        s=read(ARCHIVE/'T09_spring_button/FAMILY_SPACE.json')
        self.assertEqual(digest(s),digest(plain(FamilySpaceV2.model_validate(s))))

    def test_twenty_guides_match_reference_and_native_inertia(self):
        import mujoco
        mechanics=read(REF/'spring_button_press/v1_2/candidates/C009/mechanics.json')
        space=read(ARCHIVE/'T09_spring_button/FAMILY_SPACE.json');space['guide_standard']={}
        space=plain(FamilySpaceV2.model_validate(space));request=deepcopy(mechanics['request']);request['family_space_identity']=digest(space)
        with patch.object(mujoco,'mj_step',side_effect=AssertionError('NO_INTEGRATION')):
            design,mesh,p=generate_family(dict(space=space,request=request))
            new=[c for c in design['components'] if c.get('eye_spoke')]
            self.assertEqual(len(new),20)
            for old in mechanics['guides']:
                i=int(old['tendon'][1:]);c=next(c for c in new if c['id']==f"guide_eye_{old['group']}_{i}")
                for key in ('mass_kg','com_local_m','inertia_com_local_kg_m2'):
                    np.testing.assert_allclose(c[key],old[key],rtol=1e-10,atol=1e-17)
            cfg=read(REF/'C1_four_tendons/M1_A/configuration.json');cfg['robot']['structure']['data']=design;cfg['policy']['discretization']['data']=mesh
            from tools.task_protocols import load
            case=load('T09').cases[0];cfg['task']=deepcopy(case.task)
            cfg['task']['environment']['data']['physical_environment']=plain(case.environment_extension)
            inp=SessionInput.model_validate(cfg);scene=assemble_physical(inp,p);scene['control']={'tension_execution_mode':'ideal_tension'}
            xml=BytesIO();compile_xml(p,scene,None,xml);model=load_model(xml=xml.getvalue().decode())
            data=mujoco.MjData(model);mujoco.mj_forward(model,data)
            from extensions.tendon_family.geometry import geometry
            rest=geometry(p,np.zeros(len(p['dofs'])))
            for c in new:
                b=model.body(c['id']);self.assertAlmostEqual(float(b.mass[0]),c['mass_kg'],places=14)
                np.testing.assert_allclose(b.ipos,c['com_local_m'],atol=1e-14)
                r=np.empty(9);mujoco.mju_quat2Mat(r,b.iquat);r=r.reshape(3,3)
                np.testing.assert_allclose(r@np.diag(b.inertia)@r.T,c['inertia_com_local_kg_m2'],rtol=1e-9,atol=1e-17)
                index=next(i for i,part in enumerate(p['parts']) if part['entity']==c['id'])
                np.testing.assert_allclose(data.xpos[b.id],np.asarray(scene['mount_position'])+np.asarray(scene['mount_rotation'])@rest['bodies'][index]['p'],atol=1e-13)
                for suffix in ('_eye','_spoke'):self.assertEqual(int(model.geom(c['id']+suffix).contype[0]),0)
            self.assertAlmostEqual(sum(c['mass_kg'] for c in new),mechanics['added_guide_mass_kg'],places=13)
            from extensions.tendon_family.gvs import _topology,_mass_descriptors
            from extensions.tendon_family.gvs_basis import resolve_basis
            resolved=resolve_basis(design)
            self.assertEqual(len(resolved.segments),2)
            descriptors=_mass_descriptors(_topology(design),3)
            rigid={d['component']:d for d in descriptors if d['kind']=='rigid'}
            for c in new:
                self.assertEqual(rigid[c['id']]['mass'],c['mass_kg'])
                np.testing.assert_allclose(rigid[c['id']]['inertia'],c['inertia_com_local_kg_m2'])
            from tools.research.config import family_bootstrap
            execution=read(ARCHIVE/'T09_spring_button/STUDY_CONFIG.json')['family_execution']
            robot,bootstrap=family_bootstrap(space,execution)
            self.assertEqual(len([c for c in robot['robot']['structure']['data']['components'] if c.get('eye_spoke')]),20)

    def test_main_registry_schemas(self):
        from tools.platform_registry import registry
        reg=registry();entry=reg.get('task.initial_state.construct','1.0.0','tool')
        schema=entry.input_schema.model_json_schema()
        self.assertIn('configuration',schema['required'])
        self.assertIn('max_iterations',schema['properties'])
        self.assertIn('reference_times_s',schema['properties'])
        from tools.research.contracts import ControlSeedRequest
        self.assertIn('tension_knots',ControlSeedRequest.model_json_schema()['properties'])
        self.assertIn('guide_standard',FamilySpaceV2.model_json_schema()['properties'])

    def test_native_construction_enters_host_and_separate_qualification(self):
        import mujoco
        from tools.platform_host import Host
        from tools.research.protocol_tools import freeze_registry_tools
        from schemas.platform import ProjectConfig
        cfg=read(REF/'C1_four_tendons/M1_A/configuration.json');cfg['run_id']='representative-initial-'+uuid4().hex
        cfg['policy']['backend']['version']='1.5.0';cfg['policy']['controller']['version']='12.0.0'
        cfg['policy']['budget'].update(model_calls=0,backend_solves=0,worker_calls=0,tool_calls=6,wall_s=None)
        freeze_registry_tools(cfg,dict.fromkeys(['task.initial_state.construct','task.initial_state.qualify'],'1.0.0'))
        (ROOT/'.offline-home').mkdir(exist_ok=True)
        with fixture_directory() as folder,patch.object(mujoco,'mj_step',side_effect=AssertionError('NO_INTEGRATION')):
            h=Host(folder,cfg['run_id'],actor='targeted-interface-test')
            h.store.create(ProjectConfig(project_id=cfg['run_id'],grant_id='native-static-'+uuid4().hex,authorization_source='User-requested representative static interface test; no integration or Provider.',budget=cfg['policy']['budget']))
            h.create(cfg)
            with h.store.transaction() as db:ref=plain(h.store.put(db,cfg))
            receipt=h.invoke(dict(request_id='construct',tool_id='task.initial_state.construct',arguments=dict(configuration=ref,max_iterations=200),reason='Representative formal static construction',cache='new'))
            self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
            value=h.store.artifact(receipt['output'])['data']
            self.assertGreater(value['cost']['forward_evaluations'],0);self.assertEqual(value['physics_steps'],0)
            self.assertLessEqual(value['static_balance_inf_nm'],1e-7)
            receipt=h.invoke(dict(request_id='qualify',tool_id='task.initial_state.qualify',arguments=dict(configuration=ref,qpos_rad=value['qpos_rad'],tensions_n=value['tensions_n']),reason='Separate original qualification gate',cache='new'))
            self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
            self.assertTrue(h.store.artifact(receipt['output'])['data']['qualified'])
            receipt=h.invoke(dict(request_id='bank',tool_id='task.initial_state.construct',arguments=dict(
                configuration=ref,max_iterations=200,reference_times_s=[0.,.25,.5],
                qpos_seed_rad=value['qpos_rad'],tensions_seed_n=value['tensions_n'],
                tension_reference_n=dict.fromkeys(value['tensions_n'],4.),tension_interior_margin_n=.01),reason='Representative formal frozen-reference continuation bank',cache='new'))
            self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
            bank=h.store.artifact(receipt['output'])['data']
            self.assertEqual(len(bank['reference_bank']),3);self.assertEqual(bank['optimization_calls'],3)
            self.assertEqual(bank['physics_steps'],0);self.assertFalse(bank['qualified'])
            self.assertLessEqual(bank['maximum_static_balance_inf_nm'],1e-7)
            self.assertGreaterEqual(min(min(u) for u in bank['tension_knots']['tensions_n']),.21-1e-12)
            self.assertEqual(bank['qpos_rad'],bank['reference_bank'][0]['qpos_rad'])
            self.assertNotEqual(bank['reference_bank'][0]['target_position_m'],bank['reference_bank'][-1]['target_position_m'])
            from tools.research.contracts import TensionKnots
            from tools.research.physical_replay import expand_tension_knots
            knots=TensionKnots.model_validate(bank['tension_knots'])
            expanded=expand_tension_knots(knots,.01,50,len(bank['tendon_order']))
            np.testing.assert_allclose(expanded[0],[bank['tensions_n'][t] for t in bank['tendon_order']])
            np.testing.assert_allclose(expanded[25],knots.tensions_n[1])
            np.testing.assert_allclose(expanded[12],np.asarray(knots.tensions_n[0])*.52+np.asarray(knots.tensions_n[1])*.48)
            with self.assertRaisesRegex(ValueError,'SPAN_FROZEN_TASK'):
                expand_tension_knots(knots,.01,51,len(bank['tendon_order']))

if __name__=='__main__':unittest.main()
