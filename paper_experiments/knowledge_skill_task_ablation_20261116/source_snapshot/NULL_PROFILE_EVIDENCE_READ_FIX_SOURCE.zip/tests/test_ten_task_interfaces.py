"""Offline only: integration and network execution are prohibited test fixtures."""
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
from contextlib import contextmanager
import shutil
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from uuid import uuid4

ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('SOFTROBOT_AGENT_HOME',str(ROOT/'.offline-home'))
REFERENCE=Path(os.environ.get('SOFTROBOT_SHOWCASE_REFERENCE',str(ROOT.parent/'showcase-ten-task-reference-20261112')))
import numpy as np
import mujoco
COUNTERS=dict(physics_steps=0,provider_requests=0,worker_launches=0,optimization_calls=0,native_forward_evaluations=0)
from schemas.platform import TaskDefinition,SessionInput,ProjectConfig,Payload
from schemas.task_protocol import ReferenceGenerator,PhysicalEnvironment
from tools.platform_registry import registry
from tools.platform_host import Host
from tools.platform_store import plain
from tools.platform_tasks import check_definition
from tools.state_io import digest
from tools.task_protocols import load,bind_configuration,aggregate
from extensions.reference.generators import sample
from extensions.reference.protocol_evaluation import evaluate


def read(path):return json.loads((REFERENCE/path).read_text(encoding='utf8'))


@contextmanager
def offline_directory():
    base=(ROOT/'.offline-home').resolve();base.mkdir(exist_ok=True)
    path=base/('fixture-'+uuid4().hex);path.mkdir()
    try:yield str(path)
    finally:
        import gc
        gc.collect()  # Historical Store read contexts can await cyclic collection.
        resolved=path.resolve();resolved.relative_to(base)
        shutil.rmtree(resolved)


def source_configuration(task_id='T01',condition='central_high'):
    folders={'T01':'M1_reach_hold','T02':'M2_loaded_hold','T03':'M3_fast_reach','T05':'M5_tool_axis','T06':'M6_loaded_scan'}
    if task_id in folders:path=f'{folders[task_id]}/{condition}/configuration.json'
    elif task_id=='T10':path='M2_loaded_hold/zero/configuration.json'
    elif task_id=='T07':path=f'C1_four_tendons/{condition}/configuration.json'
    elif task_id in ('T04','T09'):path='C1_four_tendons/M1_A/configuration.json'
    else:path='M1_reach_hold/central_high/configuration.json'
    cfg=deepcopy(read(path));cfg['policy']['backend']['version']='1.5.0';cfg['policy']['controller']['version']='12.0.0'
    return cfg


class OfflineOnly(unittest.TestCase):
    def setUp(self):
        self.step_guard=patch.object(mujoco,'mj_step',side_effect=AssertionError('PHYSICS_INTEGRATION_FORBIDDEN'))
        self.step_guard.start();self.addCleanup(self.step_guard.stop)
        import httpx
        self.net_guard=patch.object(httpx.Client,'send',side_effect=AssertionError('PROVIDER_NETWORK_FORBIDDEN'))
        self.net_guard.start();self.addCleanup(self.net_guard.stop)
        self.async_net_guard=patch.object(httpx.AsyncClient,'send',side_effect=AssertionError('PROVIDER_NETWORK_FORBIDDEN'))
        self.async_net_guard.start();self.addCleanup(self.async_net_guard.stop)
        original_forward=mujoco.mj_forward
        def forward(*args,**kwargs):
            COUNTERS['native_forward_evaluations']+=1
            return original_forward(*args,**kwargs)
        forward_guard=patch.object(mujoco,'mj_forward',side_effect=forward)
        forward_guard.start();self.addCleanup(forward_guard.stop)
        import scipy.optimize
        for name in ('minimize','least_squares','root','differential_evolution'):
            guard=patch.object(scipy.optimize,name,side_effect=AssertionError('OPTIMIZATION_FORBIDDEN'))
            guard.start();self.addCleanup(guard.stop)
        guard=patch('tools.service_execution._run_contained',side_effect=AssertionError('REAL_WORKER_LAUNCH_FORBIDDEN'))
        guard.start();self.addCleanup(guard.stop)


class ProtocolTests(OfflineOnly):
    def test_formal_study_resolver_accepts_explicit_registry_tool_grants(self):
        from tools.research.config import resolve
        from tools.paths import resource_path
        example=resource_path('examples/study-reach.json')
        raw=json.loads(example.read_text(encoding='utf8'))
        raw['study_id']='offline-formal-'+uuid4().hex
        raw.update(control='control.json',runtime='runtime.json',
            registry_tools={'research.math':'1.0.0','trace.decision':'1.0.0','research.dispatch':'1.0.0'})
        with offline_directory() as directory:
            for source in example.parent.glob('*.json'):shutil.copyfile(source,Path(directory)/source.name)
            path=Path(directory)/'study.json';path.write_text(json.dumps(raw),encoding='utf8')
            result=resolve(path)
            from tools.research.core import prepare,bind
            from tools.paths import implementation_status
            status={**implementation_status(),'worktree_dirty':False}
            # Explicit offline fixture: bind the currently tested source view,
            # then exercise the actual Registry -> Plan -> generator boundary.
            # No simulation, optimizer, Worker or Provider is permitted.
            with patch('tools.research.core.implementation_status',return_value=status):
                host=prepare(path,directory=Path(directory)/'mock-study');bind(host)
            plan=dict(action='generate',hypothesis='Check formal cold generation admission.',
                expected_observation='A new mock-owned candidate without physics.',weakening_observation='A configuration or permission error.',
                fixed_conditions='Frozen generic example only.',stopping_condition='One generation.',interpretation='Offline interface fixture.',
                generation=dict(version='serial_family_generation_v2',family_space_identity=result['family_space_identity'],segment_count=2,tendon_count=4))
            receipt=host.invoke(dict(request_id='offline-formal-generation',tool_id='research.dispatch',arguments=plan,reason='Offline complete formal-entry regression.'))
            self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
            self.assertEqual(host.store.artifact(receipt['output'])['data']['result']['status'],'generated')
        self.assertEqual(result['configuration']['policy']['tool_bindings']['research.math'],'1.0.0')
        self.assertEqual(result['registry_tools'],raw['registry_tools'])

    def test_all_existing_active_case_configurations_bind(self):
        for task_id in ('T01','T02','T03','T05','T06','T07','T10'):
            for case in load(task_id).cases:
                with self.subTest(task=task_id,condition=case.condition_id):
                    cfg=source_configuration(task_id,case.condition_id)
                    bound=bind_configuration(load(task_id),case.condition_id,cfg)
                    self.assertEqual(bound.task.acceptance.task_id,task_id)

    def test_existing_nmpc_transcription_exposes_task_tension_lower_bound(self):
        from extensions.tendon_family.gvs_trajectory import trajectory_authorization
        cfg=source_configuration('T07','M1_A');cfg=SessionInput.model_validate(cfg)
        parameters=cfg.policy.controller.parameters.data['recipe'];parameters={**parameters,'minimum_tension_n':.2}
        variables=trajectory_authorization(cfg.robot,{},parameters)
        for key,value in variables.items():
            if key.startswith(('u/','previous_u/')):self.assertEqual(value['bounds'][0],.2)

    def test_all_frozen_definitions_and_packaged_assets(self):
        r=registry()
        for i in range(1,11):
            p=load(f'T{i:02}')
            with self.subTest(task=p.task_id):
                body=(ROOT/'TASK_PROTOCOLS'/f'{p.task_id}.json').read_bytes()
                self.assertEqual(body,(ROOT/'tools/assets/TASK_PROTOCOLS'/f'{p.task_id}.json').read_bytes())
                for case in p.cases:
                    check_definition(case.task,r)
                    value=deepcopy(case.task);value['acceptance']=plain(case.acceptance)
                    check_definition(value,r)
                    for source in [*case.acceptance.source_files,*case.structure_sources]:
                        self.assertEqual(hashlib.sha256((REFERENCE/source.path).read_bytes()).hexdigest(),source.sha256)
                    self.assertTrue(r.get(case.task['family'],kind='task').resolve())
                    self.assertTrue(r.get(case.task['evaluator']['extension_id'],case.task['evaluator']['version'],'evaluator').resolve())

    def test_legacy_task_serialization_unchanged(self):
        raw=read('M1_reach_hold/central_high/task.json')['definition']
        self.assertEqual(TaskDefinition.model_validate(raw).model_dump(mode='json'),raw)

    def test_four_independent_channels_bind_and_reject_aliases(self):
        cfg=source_configuration('T07','M1_A');bound=bind_configuration(load('T07'),'M1_A',cfg)
        self.assertEqual(len(bound.robot.structure.data['actuators']),4)
        bad=deepcopy(cfg);channels=bad['robot']['structure']['data']['actuators']
        channels[1]['transmission']=deepcopy(channels[0]['transmission'])
        with self.assertRaisesRegex(ValueError,'INDEPENDENT_CHANNEL_MAP'):
            bind_configuration(load('T07'),'M1_A',bad)

    def test_required_cases_and_controls_aggregate_separately(self):
        p=load('T10');results={c.condition_id:dict(task_success=c.role=='required',design_identity='same',controller_identity='same-controller') for c in p.cases}
        self.assertTrue(aggregate(p,results)['task_success'])
        results['negative_y']['design_identity']='other'
        self.assertIsNone(aggregate(p,results)['task_success'])

    def test_m7_rejects_any_original_m2_structure_change(self):
        cfg=source_configuration('T10','positive_y')
        component=next(c for c in cfg['robot']['structure']['data']['components'] if c['kind']=='flexible_segment')
        component['length_m']*=1.01
        with self.assertRaisesRegex(ValueError,'UNCHANGED_ORIGINAL_M2'):
            bind_configuration(load('T10'),'positive_y',cfg)

    def test_passive_no_active_channels_or_status_upgrade(self):
        p=load('T08');t=TaskDefinition.model_validate(p.cases[0].task)
        self.assertEqual(p.source_status,'development_not_registered_SELECT');self.assertEqual(t.actuator_channels,[])
        self.assertEqual(t.family,'task.passive_response')
        self.assertEqual(t.goal.data['load_conditions'],['plus_x','minus_x'])
        for program in t.goal.data['programs'].values():
            self.assertEqual([s['name'] for s in program],['unloaded','low','middle','high','recovery'])
        self.assertEqual(t.goal.data['protocol_source']['artifact_id'],digest(read('P3_progressive_stiffness/task.json')))

    def test_bind_reach_and_adapter_frozen_windows(self):
        from tools.research_tasks import task_adapter
        cfg=bind_configuration(load('T01'),'central_high',source_configuration())
        adapter=task_adapter(cfg)
        self.assertEqual(adapter.holding_start_s(),.54)
        self.assertEqual(adapter.execution_requirements()['protocol_template_id'],'offline_frozen_task_v1')
        self.assertIn('frozen_acceptance',adapter.describe())

    def test_registry_tools_have_complete_main_schemas(self):
        import jsonschema
        from tools.research.protocol_tools import PUBLIC,freeze_registry_tools,native_tools
        from tools.research.agent import tool_directory
        r=registry();cfg=source_configuration()
        selected={name:'1.0.0' for name in PUBLIC}
        freeze_registry_tools(cfg,selected)
        class FakeHost:
            reg=r
            run_id='mock'
            store=SimpleNamespace(session=lambda run:dict(snapshot=dict(input=cfg)))
        class FakeTool:
            def __init__(self,name,spec,handler):self.name=name;self.tool_spec=spec;self.handler=handler
        tools=native_tools(FakeHost(),FakeTool)
        for tool in tools:jsonschema.Draft202012Validator.check_schema(tool.tool_spec['inputSchema']['json'])
        directory=tool_directory(FakeHost(),{t.name:t for t in tools})
        self.assertEqual({t.name for t in tools},{d['tool'] for d in directory})


class ReferenceTests(OfflineOnly):
    def test_frozen_phase_equals_original_source(self):
        source=ast.parse((REFERENCE/'scripts/solve_figure_eight.py').read_text(encoding='utf8'))
        node=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='phase')
        namespace={'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),'original_phase','exec'),namespace)
        spec=load('T04').reference;t=np.linspace(0,22,22001)
        generated=sample(spec,t)
        np.testing.assert_allclose(generated['phase_rad'],namespace['phase'](t),rtol=0,atol=2e-15)
        self.assertAlmostEqual(generated['phase_rad'][-1],4*np.pi)
        np.testing.assert_allclose(generated['velocity_m_s'][[0,-1]],0,atol=1e-15)

    def test_reference_velocity_and_prediction_tail(self):
        spec=load('T04').reference;times=np.array([.5,2.,6.,20.,21.])
        h=1e-5;finite=(sample(spec,times+h)['position_m']-sample(spec,times-h)['position_m'])/(2*h)
        np.testing.assert_allclose(finite,sample(spec,times)['velocity_m_s'],rtol=1e-7,atol=1e-10)
        with self.assertRaisesRegex(ValueError,'HORIZON'):sample(spec,[22.1])
        tail=sample(spec,[22.,23.],prediction=True)
        np.testing.assert_allclose(tail['position_m'][0],tail['position_m'][1]);np.testing.assert_array_equal(tail['velocity_m_s'][1],0)

    def test_reference_schema_rejects_callbacks_and_wrong_cycle_duration(self):
        spec=plain(load('T04').reference)
        with self.assertRaises(ValueError):ReferenceGenerator.model_validate({**spec,'callback':'os.system'})
        with self.assertRaisesRegex(ValueError,'CYCLE_MISMATCH'):ReferenceGenerator.model_validate({**spec,'duration_s':20})

    def test_quintic_nodes_freeze_positions_and_velocity(self):
        spec=dict(kind='quintic_nodes',center_m=[0,0,0],duration_s=2,times_s=[0,1,2],positions_m=[[0,0,0],[1,2,3],[0,0,0]])
        result=sample(spec,[0,1,2]);np.testing.assert_allclose(result['position_m'],spec['positions_m'])
        np.testing.assert_array_equal(result['velocity_m_s'],0)


class EnvironmentTests(OfflineOnly):
    def test_passive_dense_trace_preserves_actual_material_and_constraint_state(self):
        from extensions.tendon_family.passive_trace import COLUMNS,values,semantics
        native=SimpleNamespace(physics={'parts':[dict(dofs=['q'],length_m=.1)]},
            point=lambda data,binding:(np.array([.01,.02,.03]),np.eye(3),0))
        data=SimpleNamespace(qvel=np.array([1.,2.,3.]),solver_niter=np.array([3]),qacc_warmstart=np.array([.1,.2,.3]))
        mechanism=dict(constraint_states=[[],[1,2]],constraint_residuals_m=[[],[.0001,.0002]],
            constraint_classification=['slack','taut'])
        row=dict(zip(COLUMNS,values(native,data,mechanism,.7,[0,0,0],dict(status='legal_at_checked_poses',checked_poses=8))))
        self.assertEqual(json.loads(row['constraint_states_json']),[[],[1,2]])
        self.assertEqual(row['velocity_y_m_s'],2.)
        self.assertEqual(row['displacement_from_initial_z_m'],.03)
        self.assertEqual(semantics(.7)['material_s'],.7)

    def test_recovered_passive_history_retains_legacy_evidence_boundary(self):
        from tools.research.passive_history import recover
        root=ROOT.parent/'passive-progressive-stiffness'
        if not (root/'runs/passive-progressive-stiffness-v1/store/platform.sqlite').exists():self.skipTest('Read-only historical P3 Store is not available')
        result=recover(root,'ef9a8a7636a651ee2d3e00bbd0aaf7e21545898f2edf1ee2779fb9705c2b4ca2')
        self.assertEqual(result['rows'],1600000)
        self.assertEqual(result['current_core_metric_regression'],'COMPLETE')
        self.assertEqual(result['current_core_full_evidence_regression'],'PARTIAL')
        self.assertEqual(result['new_study_result'],'NOT_RUN')

    def test_m7_complete_controller_views_are_identical_across_conditions(self):
        from extensions.tendon_family.backends import physics_for
        from extensions.tendon_family.scene import assemble
        from extensions.tendon_family.environment import controller_reference_clock
        views=[]
        for case in load('T10').cases:
            cfg=bind_configuration(load('T10'),case.condition_id,source_configuration('T10'))
            views.append(assemble(cfg,physics_for(cfg))['control'])
            self.assertEqual(controller_reference_clock(cfg.task,.8),.3)
        for view in views[1:]:self.assertEqual(view,views[0])
        self.assertEqual(views[0]['task']['task_id'],'blind-fixed-target-stabilization')
        self.assertNotIn('positive_y',json.dumps(views[0]))
        self.assertNotIn('negative_y',json.dumps(views[0]))

    def test_frozen_input_is_executor_owned_and_holds_actual_input(self):
        from extensions.tendon_family.environment import frozen_input,controller_task
        c=load('T10').cases[-1];extension=plain(c.environment_extension)
        self.assertIsNone(frozen_input(.49,[1,2],extension))
        np.testing.assert_array_equal(frozen_input(.5,[1,2],extension),[1,2])
        raw=deepcopy(c.task);raw['environment']['data']['physical_environment']=extension
        self.assertIsNone(controller_task(TaskDefinition.model_validate(raw))['environment']['data']['physical_environment']['input_freeze_after_s'])

    def test_half_sine_world_com_wrench_and_impulse(self):
        from extensions.tendon_family.environment import wrench_at
        spec=plain(load('T10').cases[0].environment_extension.wrenches[0])
        np.testing.assert_allclose(wrench_at(spec,.525),[0,.04,0,0,0,0],atol=1e-15)
        np.testing.assert_array_equal(wrench_at(spec,.55),0)
        np.testing.assert_array_equal(wrench_at(spec,.49),0)
        impulse=sum((wrench_at(spec,k*.0005)[:3]*.0005 for k in range(1000,1100)),np.zeros(3))
        self.assertAlmostEqual(impulse[1],.04*.05*2/np.pi,delta=2e-7)

    def test_actual_static_wrench_is_world_force_at_payload_com(self):
        from extensions.tendon_family.backends import _bind_mujoco_forces,_apply_mujoco_forces
        xml='<mujoco><option gravity="0 0 0" timestep="0.0005"/><worldbody><body name="payload" pos="1 2 3"><freejoint/><inertial pos="0.007 0.001 0" mass="0.02" diaginertia="0.000002 0.000002 0.000002"/><site name="tip_site" pos="0.014 0 0"/></body></worldbody></mujoco>'
        from extensions.tendon_family.mjcf import load_model
        model=load_model(xml=xml);data=mujoco.MjData(model);data.time=.525
        scene=dict(forces=[],assembly=dict(physical_environment=plain(load('T10').cases[0].environment_extension)))
        forces=_bind_mujoco_forces(model,scene);_apply_mujoco_forces(model,data,forces);mujoco.mj_forward(model,data)
        bid=model.body('payload').id
        np.testing.assert_allclose(data.xfrc_applied[bid],[0,.04,0,0,0,0],atol=1e-14)
        self.assertFalse(np.allclose(data.xipos[bid],data.site_xpos[model.site('tip_site').id]))
        self.assertAlmostEqual(data.time,.525)

    def test_disturbance_is_not_in_controller_task(self):
        from extensions.tendon_family.environment import controller_task
        c=load('T10').cases[0];raw=deepcopy(c.task);raw['acceptance']=plain(c.acceptance)
        raw['environment']['data']['physical_environment']=plain(c.environment_extension)
        task=TaskDefinition.model_validate(raw);public=controller_task(task)
        self.assertNotIn('acceptance',public);self.assertEqual(public['environment']['data']['physical_environment']['wrenches'],[])
        self.assertTrue(task.environment.data['physical_environment']['wrenches'])

    def test_contact_observation_uses_true_native_force(self):
        from extensions.tendon_family.environment import observe
        env=load('T09').cases[0].environment_extension
        fake_model=SimpleNamespace(geom=lambda i:SimpleNamespace(name=['probe','button_cap'][i]),
            joint=lambda name:SimpleNamespace(id=0),jnt_qposadr=[0],jnt_dofadr=[0])
        fake_data=SimpleNamespace(contact=[SimpleNamespace(geom1=0,geom2=1,dist=-.001)],qpos=[.002],qvel=[0.],qacc=[0.])
        def contact_force(model,data,index,out):out[0]=.123
        with patch.object(mujoco,'mj_contactForce',side_effect=contact_force):result=observe(fake_model,fake_data,env)
        self.assertEqual(result['contact_pairs'][0]['normal_force_n'],.123)
        self.assertNotEqual(result['contact_pairs'][0]['normal_force_n'],50*.002)

    def test_contact_xml_compiles_with_full_inertia_and_slide(self):
        from extensions.tendon_family.compiler import resolve
        from extensions.tendon_family.scene import assemble_physical
        from extensions.tendon_family.mjcf import compile_xml,load_model
        case=load('T09').cases[0];cfg=source_configuration('T09');design=cfg['robot']['structure']['data']
        rigid=case.acceptance.parameters['rigid_tool'];payload=next(c for c in design['components'] if c['id']=='payload')
        for k in ('mass_kg','com_local_m','inertia_com_local_kg_m2'):payload[k]=deepcopy(rigid[k])
        design['tip']['position_m']=[.014,.021,0.]
        # Task-owned tool data must be frozen in the generation source as well
        # as its compiled design; preserve the original source-binding gate.
        from extensions.tendon_family.generated_serial import generate_family
        build=cfg['policy']['candidate_builder']['parameters']['data'];space=build['space']
        prototype=next(c for c in space['assembly']['components'] if c['id']=='payload')
        for k in ('mass_kg','com_local_m','inertia_com_local_kg_m2'):prototype[k]=deepcopy(rigid[k])
        space['assembly']['tip']['position_m']=[.014,.021,0.]
        build['request']['family_space_identity']=digest(space)
        new_design,mesh,_=generate_family(build);cfg['robot']['structure']['data']=new_design;cfg['policy']['discretization']['data']=mesh
        cfg['policy']['controller']['parameters']['data']['recipe']['reference_mode']='timed'
        control=cfg['policy']['controller']['parameters']['data'];control['settling']=None
        for name in ('holding_tip_speed_weight','terminal_tip_speed_weight','velocity_weight','terminal_velocity_weight'):
            control['recipe'][name]=0.
        bound=bind_configuration(load('T09'),'default',cfg)
        physics=resolve(bound.robot.structure.data,bound.policy.discretization.data)
        scene=assemble_physical(bound,physics);scene['control']=dict(tension_execution_mode='ideal_tension')
        with offline_directory() as directory:
            xml=compile_xml(physics,scene,registry().parse(bound.policy.backend.parameters),Path(directory)/'model.xml')
            model=load_model(path=xml);data=mujoco.MjData(model);mujoco.mj_forward(model,data)
            from extensions.tendon_family.task_observations import Recorder
            tids=[model.tendon(t['entity']).id for t in physics['tendons']];aids=[model.actuator(t['entity']+'_direct_tension').id for t in physics['tendons']]
            recorder=Recorder(model,bound.task,tids,aids,[],binding=dict(design_identity=physics['design_identity'],physics_identity=physics['identity'],model_xml_sha256=hashlib.sha256(xml.read_bytes()).hexdigest()))
            recorder.capture(data);evidence=recorder.export()
            self.assertEqual(evidence['physics_steps'],0)
            self.assertEqual(evidence['signal_definitions']['contact_force_n']['source'],'mj_contactForce normal component')
            self.assertEqual(evidence['signal_definitions']['tip_rotation_world']['dimension'],9)
            self.assertEqual(evidence['signal_definitions']['external_force_max_n']['units'],'N')
            self.assertEqual(evidence['signal_definitions']['external_torque_max_nm']['units'],'N.m')
        self.assertEqual(model.nu,4);self.assertEqual(model.nq,len(physics['dofs'])+1)
        slide=model.joint('button_slide').id;self.assertEqual(model.jnt_type[slide],mujoco.mjtJoint.mjJNT_SLIDE)
        self.assertEqual(model.jnt_stiffness[slide],50.)
        body=model.body('payload').id;rotation=np.empty(9);mujoco.mju_quat2Mat(rotation,model.body_iquat[body]);R=rotation.reshape(3,3)
        np.testing.assert_allclose(R@np.diag(model.body_inertia[body])@R.T,rigid['inertia_com_local_kg_m2'],rtol=0,atol=1e-12)
        self.assertEqual(model.body_mass[model.body('button_slider').id],.005)
        self.assertEqual(data.ncon,0)


class EvaluatorTests(OfflineOnly):
    def active_arrays(self,task_id='T01'):
        c=load(task_id).cases[0];n=round(c.task['timing']['duration_s']/c.task['timing']['timestep_s'])+1;ch=c.independent_channels
        a={k:np.zeros(n) for k in c.acceptance.required_signals}
        a.update(time_s=np.arange(n)*c.task['timing']['timestep_s'],tip_m=np.tile(c.task['goal']['data']['target_m'],(n,1)),
            qpos=np.zeros((n,2)),qvel=np.zeros((n,2)),tension_n=np.zeros((n,ch)),
            tendon_length_m=np.ones((n,ch))*.2,tendon_speed_m_s=np.zeros((n,ch)))
        if task_id=='T01':a['tip_velocity_m_s']=np.zeros((n,3))
        else:a['tool_axis_world']=np.tile(c.task['goal']['data']['target_axis_world'],(n,1))
        return c,a

    def test_source_owned_actuator_limits_all_six_protocols(self):
        for task_id in ('T01','T02','T03','T05','T06','T07'):
            for c in load(task_id).cases:
                p=c.acceptance.parameters['geometric_actuator_limits']
                self.assertEqual(p['stroke_from_initial_bounds_m'],[-.015,.015]);self.assertEqual(p['max_tendon_speed_m_s'],.025)
                self.assertIn('tendon_length_m',c.acceptance.required_signals);self.assertIn('tendon_speed_m_s',c.acceptance.required_signals)

    def test_dense_actuator_counterexample_and_missing_signal(self):
        for task_id in ('T01','T05'):
            c,a=self.active_arrays(task_id);self.assertTrue(evaluate(c.acceptance,c.task,a)['task_success'])
            a['tendon_speed_m_s'][11,0]=.337
            r=evaluate(c.acceptance,c.task,a);self.assertFalse(r['task_success']);self.assertFalse(r['checks']['geometric_tendon_speed'])
            a['tendon_speed_m_s'][11,0]=.025;self.assertTrue(evaluate(c.acceptance,c.task,a)['task_success'])
            a['tendon_length_m'][13,1]+=.016;self.assertFalse(evaluate(c.acceptance,c.task,a)['checks']['geometric_stroke_max'])
            del a['tendon_speed_m_s'];self.assertEqual(evaluate(c.acceptance,c.task,a)['validity'],'incomplete')

    def test_existing_control_norm_interface_includes_dense_envelope(self):
        from tools.research.control_correction import task_measure,constraint_vectors
        outputs=dict(times_s=[0,.6],tip_positions_m=[[0,0,0],[0,0,0]],tip_velocities_m_s=[[0,0,0],[0,0,0]],
            actuator_extrema=dict(initial_lengths_m=[.2],minimum_lengths_m=[.2],maximum_lengths_m=[.2],maximum_abs_speed_m_s=[.05],observed_physics_states=601,complete_from_initial=True))
        options=dict(target=[0,0,0],holding_start=.54,position_limit=.01,speed_limit=.03,
            actuator_limits=dict(stroke_from_initial_bounds_m=[-.015,.015],max_tendon_speed_m_s=.025))
        result=task_measure(outputs,**options);self.assertEqual(result['signed_maximum_excess'],1.)
        self.assertEqual(result['worst_constraint']['kind'],'geometric_tendon_speed')
        self.assertEqual(np.linalg.norm(constraint_vectors(outputs,**options),axis=1).max(),2.)
        self.assertLessEqual(result['returned_array_gap_interval'][0],1.);self.assertGreaterEqual(result['returned_array_gap_interval'][1],1.)
        outputs['actuator_extrema']['complete_from_initial']=False
        with self.assertRaisesRegex(ValueError,'DENSE_COMPLETE'):task_measure(outputs,**options)

    def test_native_envelope_observes_between_control_samples_without_real_integration(self):
        from extensions.tendon_family.mujoco_analysis import NativeModel
        native=object.__new__(NativeModel);native.model=SimpleNamespace(opt=SimpleNamespace(timestep=.001));native.aids=[0];native.tids=[0]
        native.forces=[];native.tool_axis_local=None;native.cost=dict(rollouts=0,physics_step_attempts=0,physics_steps=0)
        native.safety=SimpleNamespace(call=lambda d,fn,*args:fn(native.model,d))
        native.apply=lambda d,u:np.asarray(u);native.check_supported=lambda d,t:None
        def forward(d):
            d.ten_length=np.array([.201 if abs(d.time-.001)<1e-12 else .2]);d.ten_velocity=np.array([.05 if abs(d.time-.001)<1e-12 else 0.])
        native.forward=forward;native.motion=lambda d:(dict(time_s=d.time,tip_position_m=[0,0,0],tip_velocity_m_s=[0,0,0]),None)
        start=SimpleNamespace(time=0.);fake=SimpleNamespace(time=0.)
        def step(m,d):d.time+=.001
        with patch.object(mujoco,'MjData',return_value=fake),patch.object(mujoco,'mj_copyData'),patch.object(mujoco,'mj_step',side_effect=step),\
            patch('extensions.tendon_family.mujoco_analysis._apply_mujoco_forces'),patch('extensions.tendon_family.mujoco_analysis._mujoco_state_failed',return_value=False):
            result=native.rollout_sequence(start,[0.,.002],[[0.]],capture_actuator_extrema=True)
        self.assertEqual(result['actuator_extrema']['observed_physics_states'],3)
        self.assertEqual(result['actuator_extrema']['maximum_abs_speed_m_s'],[.05])
        self.assertEqual(result['actuator_extrema']['maximum_lengths_m'],[.201])

    def test_failed_zero_limit_is_reported_before_passing_constraints(self):
        from tools.development.offline_regression import read_case
        p=load('T09');c=p.cases[0];arrays,_,_,_,_=read_case(REFERENCE,'T09',c)
        arrays['warnings']=np.ones_like(arrays['warnings'])
        result=evaluate(c.acceptance,c.task,arrays)
        self.assertFalse(result['task_success'])
        self.assertEqual(result['worst_constraint'],'finite_no_warning')
        self.assertEqual(set(result['checks']),set(result['constraints']))
        self.assertEqual(result['constraints']['finite_no_warning']['margin'],-1.)

    def test_historical_prepared_equilibrium_static_qualification_only(self):
        from tools.research.prepared_initial import qualify
        from extensions.tendon_family.compiler import resolve
        cfg=source_configuration('T04');design=read('figure_eight_tracking/design.json')
        cfg['robot']['structure']['data']=design;cfg['policy']['discretization']['data']=dict(cells=dict(segment_0=12))
        physics=resolve(design,cfg['policy']['discretization']['data'])
        with np.load(REFERENCE/'figure_eight_tracking/trajectory_full.npz',allow_pickle=False) as data:
            q=dict(zip(physics['dofs'],data['qpos'][0].tolist()));u=dict(zip([t['id'] for t in design['tendons']],data['tension_n'][0].tolist()))
        with offline_directory() as folder:result=qualify(cfg,q,u,Path(folder)/'initial.xml')
        self.assertTrue(result['qualified'],result);self.assertEqual(result['physics_steps'],0);self.assertEqual(result['optimization_calls'],0)
        self.assertEqual(result['native_forward_evaluations'],1)

    def test_wrong_tendon_dimension_is_invalid(self):
        from tools.development.offline_regression import read_case
        p=load('T09');c=p.cases[0];a,_,_,_,_=read_case(REFERENCE,'T09',c)
        a['tension_n']=a['tension_n'][:,:1]
        result=evaluate(c.acceptance,c.task,a)
        self.assertEqual(result['validity'],'invalid')

    def test_historical_twenty_cases_regress_without_integration(self):
        from tools.development.offline_regression import run
        result=run(REFERENCE)
        self.assertEqual(result['counts'],dict(PASS=20,FAIL=0,PARTIAL=1));self.assertEqual(result['physics_steps'],0)

    def test_original_spring_evaluator_matches(self):
        from tools.development.offline_regression import read_case
        p=load('T09');c=p.cases[0];arrays,_,_,_,_=read_case(REFERENCE,'T09',c)
        spec=importlib.util.spec_from_file_location('original_button_evaluator',REFERENCE/'spring_button_press/evaluator.py')
        import sys
        previous=sys.dont_write_bytecode;sys.dont_write_bytecode=True
        try:
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        finally:sys.dont_write_bytecode=previous
        original=module.evaluate(arrays,None,0.)
        outcome=evaluate(c.acceptance,c.task,arrays)
        self.assertEqual(original['status']=='PASS',outcome['task_success'])
        for name,value in outcome['metrics'].items():
            self.assertAlmostEqual(value,original['metrics'][name],delta=1e-12)

    def test_original_m7_evaluator_function_matches_every_case(self):
        from tools.development.offline_regression import read_case
        tree=ast.parse((REFERENCE/'M7_external_impact_active_recovery/run.py').read_text(encoding='utf8'))
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='evaluate')
        namespace={'np':np};exec(compile(ast.Module(body=[node],type_ignores=[]),'original_m7_evaluator','exec'),namespace)
        protocol=load('T10');original_task=read('M7_external_impact_active_recovery/task.json')
        for case in protocol.cases:
            with self.subTest(condition=case.condition_id):
                arrays,_,_,_,_=read_case(REFERENCE,'T10',case)
                original=namespace['evaluate'](arrays,original_task);actual=evaluate(case.acceptance,case.task,arrays)
                self.assertEqual(original['status']=='PASS',actual['task_success'])
                for name,value in actual['metrics'].items():
                    if value is not None:self.assertAlmostEqual(value,original['metrics'][name],delta=1e-12)

    def test_missing_or_nonfinite_or_wrong_shape_is_not_success(self):
        from tools.development.offline_regression import read_case
        p=load('T09');c=p.cases[0];arrays,_,_,_,_=read_case(REFERENCE,'T09',c)
        del arrays['contact_force_n'];self.assertIsNone(evaluate(c.acceptance,c.task,arrays)['task_success'])
        arrays['contact_force_n']=np.full(len(arrays['time_s']),np.nan)
        self.assertEqual(evaluate(c.acceptance,c.task,arrays)['validity'],'invalid')

    def test_contact_force_cannot_be_replaced_by_spring_force(self):
        from tools.development.offline_regression import read_case
        p=load('T09');c=p.cases[0];arrays,_,_,_,_=read_case(REFERENCE,'T09',c)
        arrays['contact_force_n']=np.zeros_like(arrays['contact_force_n'])
        result=evaluate(c.acceptance,c.task,arrays)
        self.assertFalse(result['task_success']);self.assertFalse(result['checks']['depth_and_force_hold_0p4s'])

    def test_spring_release_strict_force_boundary(self):
        from tools.development.offline_regression import read_case
        p=load('T09');c=p.cases[0];a,_,_,_,_=read_case(REFERENCE,'T09',c)
        a['contact_force_n'][1800]=.01
        result=evaluate(c.acceptance,c.task,a)
        self.assertFalse(result['checks']['release_1p8_force']);self.assertFalse(result['task_success'])

    def test_axis_direction_boundary_and_bad_norm(self):
        from tools.development.offline_regression import read_case
        c,a=self.active_arrays('T05')
        a['tool_axis_world']*=2
        self.assertEqual(evaluate(c.acceptance,c.task,a)['validity'],'invalid')

    def test_continuous_window_includes_both_endpoints(self):
        from extensions.reference.protocol_evaluation import longest_interval
        t=np.arange(501)*.001
        self.assertAlmostEqual(longest_interval(t,np.ones(501,dtype=bool)),.5)
        valid=np.ones(501,dtype=bool);valid[250]=False
        self.assertAlmostEqual(longest_interval(t,valid),.249)


class HostTraceTests(OfflineOnly):
    def test_native_trace_preserves_original_before_compilation_mutates_input(self):
        from tools.research.replay_export import native_entry,export
        h=self.host();arguments=dict(action='diagnose',value=dict(original=1))
        with native_entry(h,'research.dispatch',dict(type='object'),arguments,'native-1',entrypoint='mock'):
            arguments['value']['original']=2
        result=export(h)
        self.assertEqual(result['native_tool_calls'][0]['original_arguments']['value']['original'],1)

    def host(self,tool_calls=8):
        (ROOT/'.offline-home').mkdir(exist_ok=True)
        folder=offline_directory();directory=folder.__enter__();self.addCleanup(folder.__exit__,None,None,None)
        cfg=source_configuration();cfg['run_id']='offline-mock-'+uuid4().hex
        cfg['policy']['budget'].update(model_calls=0,backend_solves=0,worker_calls=0,tool_calls=tool_calls,wall_s=None)
        from tools.research.protocol_tools import freeze_registry_tools
        freeze_registry_tools(cfg,{k:'1.0.0' for k in ['task.protocol.inspect','task.protocol.bind','task.protocol.evaluate','task.protocol.aggregate','reference.generate','trace.decision','trace.replay_export']})
        h=Host(directory,cfg['run_id'],actor='offline-test')
        h.store.create(ProjectConfig(project_id=cfg['run_id'],grant_id='offline-'+uuid4().hex,authorization_source='Offline unit tests only; zero Provider, physics and optimization budget.',budget=cfg['policy']['budget']))
        h.create(cfg)
        return h

    def test_host_permissions_receipts_exact_replay_and_accounting(self):
        from tools.research.replay_export import export
        h=self.host();request=dict(request_id='inspect-1',tool_id='task.protocol.inspect',arguments=dict(task_id='T04'),reason='Offline schema inspection',cache='new')
        receipt=h.invoke(request);self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
        self.assertEqual(receipt['charged']['tool_calls'],1);self.assertEqual(receipt['charged']['backend_solves'],0)
        self.assertEqual(h.invoke(request),receipt)
        bundle=export(h);self.assertEqual(len(bundle['tool_calls']),1)
        self.assertEqual(bundle['tool_calls'][0]['request'],request)
        self.assertEqual(bundle['tool_calls'][0]['input_schema'],registry().get('task.protocol.inspect').input_schema.model_json_schema())
        self.assertTrue(bundle['completeness']['exact_requests_available']);json.dumps(bundle,allow_nan=False)
        self.assertEqual(h.store.remaining(h.run_id)['used']['model_calls'],0)

    def test_rejected_call_and_budget_exhaustion_are_recorded(self):
        h=self.host(tool_calls=1)
        receipt=h.invoke(dict(request_id='inspect-1',tool_id='task.protocol.inspect',arguments=dict(task_id='T01'),reason='Offline inspect'))
        self.assertEqual(receipt['execution_status'],'completed')
        rejected=h.invoke(dict(request_id='inspect-2',tool_id='task.protocol.inspect',arguments=dict(task_id='T02'),reason='Exhausted offline budget'))
        self.assertEqual(rejected['execution_status'],'rejected')
        self.assertEqual(h.store.remaining(h.run_id)['used']['tool_calls'],1)
        from tools.research.replay_export import export
        self.assertEqual(len(export(h)['tool_calls']),2)

    def test_decision_summary_is_persisted(self):
        h=self.host();args=dict(research_question='Is the frozen reference available?',rationale_summary='Inspect the protocol before selecting an experiment.',selected_tool='task.protocol.inspect',next_operation='Read T04')
        receipt=h.invoke(dict(request_id='decision-1',tool_id='trace.decision',arguments=args,reason='Record public decision summary'))
        self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
        from tools.research.replay_export import export
        self.assertEqual(export(h)['decision_events'][0]['rationale_summary'],args['rationale_summary'])

    def test_usage_roles_and_missing_values_are_not_estimated(self):
        from tools.research.replay_export import normalize_usage
        a=normalize_usage('a',dict(purpose='main',model='model',provider='mock'),dict(usage=dict(input_tokens=11,output_tokens=3,total_tokens=14)), 'time')
        b=normalize_usage('b',dict(purpose='reporter'),dict(usage={}), 'time')
        self.assertEqual(a['input_tokens'],11);self.assertEqual(a['cached_input_tokens'],'unavailable')
        self.assertEqual(b['total_tokens'],'unavailable');self.assertEqual(b['role'],'reporter')

    def test_registry_math_delegates_original_guard_and_request(self):
        from tools.research.registry_bridge import mathematics,plan_preflight
        from tools.research.state import guard
        value=dict(operation='equilibrium');args=SimpleNamespace(model_dump=lambda **kw:value)
        ctx=SimpleNamespace(host=object(),request=SimpleNamespace(request_id='mock'))
        with patch('tools.research.analysis.dispatch',return_value=dict(status='mocked')) as dispatch:
            outcome=mathematics(ctx,args)
        self.assertEqual(dispatch.call_args.args,(ctx.host,value,'mock-math'))
        self.assertIs(dispatch.call_args.kwargs['guard'],guard);self.assertEqual(outcome.data['status'],'mocked')
        self.assertEqual(plan_preflight(None,None,None)['cost']['tool_calls'],0)

    def test_store_historical_evidence_evaluator_reporter_and_aggregate(self):
        from tools.development.offline_regression import read_case
        from tools.research.evidence_views import result_card
        h=self.host();p=load('T09');case=p.cases[0];arrays,_,_,_,_=read_case(REFERENCE,'T09',case)
        raw=dict(protocol_hash=digest(plain(p)),condition_id='default',origin='historical',design_identity='historical-fixture',
            arrays={k:arrays[k].tolist() for k in case.acceptance.required_signals})
        with h.store.transaction() as db:evidence=h.store.put(db,raw)
        receipt=h.invoke(dict(request_id='evaluate-1',tool_id='task.protocol.evaluate',
            arguments=dict(task_id='T09',condition_id='default',evidence=plain(evidence)),reason='Read-only historical evaluator regression'))
        self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'));value=h.store.artifact(receipt['output'])
        self.assertTrue(value['task_success']);self.assertEqual(value['diagnostics']['origin'],'historical')
        with patch('tools.research.evidence_views.read_evidence',return_value=value):card=result_card(h,receipt['output'])
        self.assertEqual(card.evidence_summary.verification_status,'historical_offline_regression')
        self.assertFalse(card.authoritative_scientific_evidence);self.assertTrue(card.metrics)
        combined=h.invoke(dict(request_id='aggregate-1',tool_id='task.protocol.aggregate',arguments=dict(task_id='T09',results=dict(default=receipt['output'])),reason='Aggregate historical fixture only'))
        self.assertEqual(combined['execution_status'],'completed',combined.get('error'))
        self.assertTrue(h.store.artifact(combined['output'])['data']['task_success'])

    def bound_candidate_host(self):
        from tools.research.design import full_science,verify_candidate
        h=self.host();cfg=h.store.session(h.run_id)['snapshot']['input']
        cfg=plain(bind_configuration(load('T01'),'central_high',cfg));profile=dict(identity='offline-fixture-profile',version='fixture')
        science=full_science(cfg);identity=digest(dict(parameters={},configuration= science,evaluation_profile=profile))
        with h.store.transaction() as db:
            configuration=h.store.put(db,cfg)
            parent=dict(identity=identity,candidate_id='core-'+identity,parameters={},resolved_parameters={},configuration=cfg,
                configuration_reference=plain(configuration),scientific_configuration=science,task_identity=digest(cfg['task']),
                source_identity=digest(cfg),profile_identity=profile['identity'],evaluation_version='fixture')
            reference=h.store.put(db,parent);state=h.store.session(h.run_id,db)['state']
            state.update(profile=profile,spec=dict(nominal_source='offline fixture'),nominal_configuration=cfg,candidates={identity:plain(reference)})
            h.store.update_state(db,h.run_id,state)
        receipt=h.invoke(dict(request_id='bind-owned',tool_id='task.protocol.bind',arguments=dict(task_id='T01',condition_id='central_high',configuration=plain(configuration),candidate=plain(reference)),reason='Mock Main candidate interface test; no science'))
        self.assertEqual(receipt['execution_status'],'completed',receipt.get('error'))
        value=h.store.artifact(receipt['output']);candidate=value['data']['candidate']
        verified=verify_candidate(h,candidate)
        self.assertEqual(verified['protocol_binding']['parent'],plain(reference));self.assertFalse(value['data']['execution_started'])
        return h,candidate

    def test_task_binding_adopts_and_verifies_owned_mock_main_candidate(self):
        self.bound_candidate_host()

    def condition_host(self):
        h,parent=self.bound_candidate_host();cfg=h.store.artifact(parent)['configuration']
        conditions=[]
        for case in load('T01').cases:
            bound=plain(bind_configuration(load('T01'),case.condition_id,cfg))
            conditions.append(dict(condition_id=case.condition_id,task=bound['task'],seed=bound['seed'],
                execution=dict(controller=bound['policy']['controller'])))
        with h.store.transaction() as db:
            state=h.store.session(h.run_id,db)['state']
            state['spec'].update(task_conditions=conditions,family_space_identity='offline-space',canonical_task_identity=digest(cfg['task']))
            h.store.update_state(db,h.run_id,state)
        return h,parent

    def test_frozen_condition_alias_has_its_own_proof_after_exact_protocol_bind(self):
        from tools.research.conditions import condition_candidate
        from tools.research.design import verify_candidate,full_science
        h,parent=self.condition_host();original=h.store.artifact(parent)
        alias=condition_candidate(h,parent,'negative_low');verified=verify_candidate(h,alias)
        self.assertNotIn('protocol_binding',verified)
        self.assertEqual(verified['condition_id'],'negative_low')
        self.assertEqual(verified['structure_candidate'],parent)
        self.assertEqual(h.store.artifact(parent),original)
        self.assertEqual(condition_candidate(h,parent,'negative_low',create=False),alias)
        bad=deepcopy(verified);bad['configuration']['task']['goal']['data']['target_m'][0]+=.001
        with h.store.transaction() as db:
            bad['scientific_configuration']=full_science(bad['configuration'])
            bad['configuration_reference']=plain(h.store.put(db,bad['configuration']))
            invalid=h.store.put(db,bad);state=h.store.session(h.run_id,db)['state']
            state['candidates'][bad['identity']]=plain(invalid);h.store.update_state(db,h.run_id,state)
        with self.assertRaisesRegex(ValueError,'FROZEN_CONDITION_CANDIDATE_IDENTITY_MISMATCH'):
            verify_candidate(h,invalid)

    def test_legacy_inherited_protocol_alias_is_replaced_without_losing_artifact(self):
        from tools.research.conditions import condition_candidate
        from tools.research.design import verify_candidate
        h,parent=self.condition_host();alias=condition_candidate(h,parent,'negative_low')
        legacy=deepcopy(h.store.artifact(alias));legacy['protocol_binding']=h.store.artifact(parent)['protocol_binding']
        with h.store.transaction() as db:
            previous=plain(h.store.put(db,legacy));state=h.store.session(h.run_id,db)['state']
            state['candidates'][legacy['identity']]=previous;h.store.update_state(db,h.run_id,state)
        self.assertIsNone(condition_candidate(h,parent,'negative_low',create=False))
        self.assertEqual(h.store.session(h.run_id)['state']['candidates'][legacy['identity']],previous)
        with self.assertRaisesRegex(ValueError,'TASK_ADAPTER_CANDIDATE_BINDING_MISMATCH'):
            verify_candidate(h,previous)
        repaired=condition_candidate(h,parent,'negative_low');verified=verify_candidate(h,repaired)
        self.assertEqual(verified['provenance']['replaces_legacy_condition_alias'],previous)
        self.assertEqual(h.store.artifact(previous),legacy)


class FrozenInputProfileTests(OfflineOnly):
    def profile_fixture(self):
        task=TaskDefinition.model_validate(load('T10').cases[3].task)
        target=task.goal.data['target_m']
        rows=[dict(time_s=t,tip_m=target,tension_n=[.2]*6) for t in (0.,1.)]
        motion=[dict(time_s=t,tip_error_m=0.,tip_speed_m_s=0.,contacts=0,
            rate_projection_residual_rad_m_s=0.) for t in (0.,1.)]
        active=dict(time_s=0.,fresh_solve=True,plan_accepted=True,optimization_nonconverged=False,
            solver_failed=False,failure_response_used=False,deadline_missed=False,graph_construction_s=0.)
        cached={**active,'time_s':.25,'fresh_solve':False,'plan_source':'cached_feasible_plan'}
        frozen=dict(time_s=.5,fresh_solve=False,feedback_enabled=False,
            plan_source='environment_frozen_actual_input',solver_outcome='not_called',
            solver_failed=False,update_wall_s=0.,deadline_missed=False)
        result=dict(solver_status='completed',data=dict(data=dict(timings_s={})))
        evaluation=dict(validity='valid',task_success=False)
        return task,result,evaluation,rows,[active,cached,frozen],motion,[8.]*6

    def test_environment_frozen_input_is_neither_solver_fallback_nor_cached_plan(self):
        from extensions.tendon_family.gvs_reporting import summarize
        report=summarize(*self.profile_fixture())
        self.assertEqual(report['updates'],3)
        self.assertEqual(report['actual_solver_calls'],1)
        self.assertEqual(report['cached_control_intervals'],1)
        self.assertEqual(report['frozen_input_intervals'],1)
        self.assertEqual(report['hold_last_responses'],0)
        self.assertEqual(report['solver_failure_flags'],0)

    def test_ordinary_controller_records_still_require_failure_response_field(self):
        from extensions.tendon_family.gvs_reporting import summarize
        args=list(self.profile_fixture());args[4][0].pop('failure_response_used')
        with self.assertRaisesRegex(KeyError,'failure_response_used'):summarize(*args)

    def test_incomplete_profile_has_ineligible_evidence_instead_of_null_error(self):
        from tools.research.feedback import eligibility
        # Load modules with their real imports before patching the shared state
        # function; otherwise a first import can retain a fixture's mock.
        from tools.research import design
        reference=dict(artifact_id='1'*64,media_type='application/json')
        candidate=dict(artifact_id='2'*64,media_type='application/json')
        state=dict(spec=dict(confirmation=dict(fresh_independent_repetitions=0)),results=[reference],
            profile=dict(identity='fixture'),research_status='ready',selected=None)
        raw=dict(candidate=candidate,acceptance=None,profile=None,profile_identity='fixture',scientific_configuration={})
        host=SimpleNamespace(store=SimpleNamespace(artifact=lambda _:raw))
        view=dict(fresh_current_study=True,passed=False,controller_route='nmpc',solution_identity={})
        owned=dict(configuration=dict(task=dict(goal=dict(data={}))),scientific_configuration={})
        progress=dict(required_total=0,remaining=0,failures=0,invalid_executions=0,current_study_confirmations=0)
        with patch('tools.research.state.state',return_value=state),patch('tools.research.feedback.result_view',return_value=view),\
                patch('tools.research.design.verify_candidate',return_value=owned),patch('tools.research.feedback.confirmation_progress',return_value=progress):
            result=eligibility(host,reference,evidence_only=True)
        self.assertFalse(result['eligible'])
        self.assertIn('result did not pass complete original task evaluation',result['reasons'])

    def test_report_card_accepts_a_recorded_null_profile(self):
        from tools.research import reporter
        card=object();host=SimpleNamespace(store=SimpleNamespace(artifact=lambda *a,**k:dict(profile=None)))
        with patch('tools.research.reporter.result_card',return_value=card),patch('tools.research.reporter.state',return_value={}):
            self.assertIs(reporter._card(host,dict(artifact_id='3'*64,media_type='application/json')),card)


if __name__=='__main__':unittest.main(verbosity=2)
