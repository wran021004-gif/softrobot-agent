"""Focused reference and constraint-projection regression checks."""
import os,unittest
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];os.environ.setdefault('SOFTROBOT_AGENT_HOME',str(ROOT/'.offline-home'))
from extensions.tendon_family.contracts import GVSTrajectoryParameters,ReachApproachProfile
from extensions.tendon_family.approach_reference import sample
from tools.research.control_correction import task_measure,constraint_vectors

class ControlReferenceRepairs(unittest.TestCase):
    def test_profile_endpoints_velocity_and_derivative(self):
        p=ReachApproachProfile(end_s=.27,ramp_s=.04);origin=np.array([.284,0.,.15]);target=np.array([.29,-.035,.19])
        times=np.array([0.,.02,.04,.1,.23,.25,.27,1.]);position,velocity=sample(origin,target,times,p)
        np.testing.assert_array_equal(position[0],origin);np.testing.assert_array_equal(position[-1],target)
        np.testing.assert_array_equal(velocity[[0,-2,-1]],0.)
        h=1e-6;plus,_=sample(origin,target,times[1:-2]+h,p);minus,_=sample(origin,target,times[1:-2]-h,p)
        np.testing.assert_allclose((plus-minus)/(2*h),velocity[1:-2],atol=1e-9)
        with self.assertRaises(ValueError):ReachApproachProfile(end_s=.07,ramp_s=.04)

    def test_default_serialization_and_main_controller_schema(self):
        p=GVSTrajectoryParameters().model_dump(mode='json')
        for key in ('reach_approach','tendon_speed_weight','tendon_speed_scale_m_s'):self.assertNotIn(key,p)
        from tools.platform_registry import registry
        schema=registry().get('controller.gvs_nmpc','12.0.0','controller').input_schema.model_json_schema()
        self.assertIn('ReachApproachProfile',schema['$defs'])
        self.assertIn('reach_approach',schema['$defs']['GVSTrajectoryParameters']['properties'])

    def test_prehold_and_actuator_failure_not_hidden_by_good_final_hold(self):
        times=[0.,.3,.4,.5,.6,.9,1.];p=np.zeros((7,3));v=np.zeros((7,3));v[2,0]=.032;v[4,0]=1.
        outputs=dict(times_s=times,tip_positions_m=p,tip_velocities_m_s=v,actuator_extrema=dict(
            initial_lengths_m=[.2],minimum_lengths_m=[.199],maximum_lengths_m=[.201],maximum_abs_speed_m_s=[.026],observed_physics_states=1001,complete_from_initial=True))
        options=dict(target=[0.,0.,0.],holding_start=.3,position_limit=.01,speed_limit=.02,
            holding_windows_s=[[.3,.5],[.9,1.]],actuator_limits=dict(stroke_from_initial_bounds_m=[-.015,.015],max_tendon_speed_m_s=.025))
        result=task_measure(outputs,**options);self.assertAlmostEqual(result['signed_maximum_excess'],.6)
        self.assertAlmostEqual(max(np.linalg.norm(constraint_vectors(outputs,**options),axis=1))-1,.6)
        self.assertAlmostEqual(result['actuator_component_signed_excess']['geometric_tendon_speed'],.04)
        self.assertEqual(result['holding_max_speed_m_s'],.032)
        from tools.research_tasks import task_adapter
        import json
        from tools.task_protocols import load
        case=load('T10').cases[0];task=dict(case.task);task['acceptance']=case.acceptance.model_dump(mode='json')
        cfg=json.loads((ROOT.parent/'showcase-ten-task-reference-20261112/M2_loaded_hold/zero/configuration.json').read_text(encoding='utf8'))
        cfg['task']=task;cfg['policy']['controller']['parameters']['data']['settling']=dict(window_s=.1,position_limit_m=.01,speed_limit_m_s=.02)
        actual=task_adapter(cfg).control_search_options()
        self.assertEqual(actual['holding_windows_s'],[[.3,.5],[.9,1.]])
        self.assertEqual(actual['actuator_limits']['max_tendon_speed_m_s'],.025)

    def test_parametric_reference_report_reads_native_motion(self):
        import json,mujoco
        from io import BytesIO
        from unittest.mock import patch
        from schemas.platform import SessionInput
        from extensions.tendon_family.backends import physics_for
        from extensions.tendon_family.scene import assemble_physical
        from extensions.tendon_family.mjcf import compile_xml
        from extensions.tendon_family.geometry import geometry
        from extensions.tendon_family.gvs_basis import resolve_basis
        from extensions.tendon_family.gvs_reporting import reconstruct_motion
        cfg=json.loads((ROOT.parent/'showcase-ten-task-reference-20261112/C1_four_tendons/M1_A/configuration.json').read_text(encoding='utf8'))
        inp=SessionInput.model_validate(cfg);p=physics_for(inp);scene=assemble_physical(inp,p);scene['control']=dict(tension_execution_mode='ideal_tension')
        xml=BytesIO();compile_xml(p,scene,None,xml)
        tip=np.asarray(scene['mount_position'])+np.asarray(scene['mount_rotation'])@geometry(p,np.zeros(len(p['dofs'])))['tip']
        row=dict(time_s=0.,qpos_rad=[0.]*len(p['dofs']),qvel_rad_s=[0.]*len(p['dofs']),tip_m=tip.tolist())
        files={'robot.xml':xml.getvalue(),'resolved_physics.json':json.dumps(p).encode(),
            'control_spec.json':json.dumps(dict(projector=dict(resolved_basis=resolve_basis(cfg['robot']['structure']['data']).model_dump(mode='json')))).encode()}
        target=dict(reference=dict(kind='figure_eight',center_m=tip.tolist(),amplitude_y_m=.02,amplitude_z_m=.008,frequency_hz=.1,cycles=2,start_ramp_s=2,stop_ramp_s=2,duration_s=22),time_requirement='timed')
        with patch.object(mujoco,'mj_step',side_effect=AssertionError('NO_INTEGRATION')):motion,_=reconstruct_motion(files,[row],target)
        self.assertAlmostEqual(motion[0]['tip_error_m'],0.)

    def test_representative_registered_transcription_with_shaping_and_tendon_cost(self):
        import json
        from copy import deepcopy
        from schemas.platform import RobotDescription,TaskDefinition
        from tools.task_protocols import load
        from extensions.tendon_family.gvs_trajectory import TrajectoryWorkspace
        cfg=json.loads((ROOT.parent/'showcase-ten-task-reference-20261112/C1_four_tendons/M1_A/configuration.json').read_text(encoding='utf8'))
        robot=deepcopy(cfg['robot']);design=robot['structure']['data'];segment=deepcopy(design['components'][0]);segment['connection']['part']='fixed_base'
        tendon=deepcopy(design['tendons'][0]);tendon['points']=[deepcopy(tendon['points'][0]),deepcopy(tendon['points'][-1])]
        tendon['points'][-1].update(hole=None,role='anchor');tendon['points'][-1]['attachment'].update(part=segment['id'],s=1.,position_m=[0.,.0141,0.])
        design.update(components=[segment],tendons=[tendon],actuators=[design['actuators'][0]],tip=dict(part=segment['id'],s=1.,position_m=[0.,0.,0.]))
        robot=RobotDescription.model_validate(robot);task=TaskDefinition.model_validate(load('T10').cases[0].task)
        parameters=dict(horizon=1,max_iterations=1,reach_approach=dict(end_s=.27,ramp_s=.04),tendon_speed_weight=.1)
        workspace=TrajectoryWorkspace(task,robot,parameters,[0.]*8,[.2])
        view=workspace._set_reference(np.zeros(8),0.)
        self.assertEqual(len(view['positions_m']),1)
        self.assertIn('reference/1/0',workspace.problem.variables)
        self.assertAlmostEqual(workspace.problem.variables['reference/1/0']['bounds'][0],view['positions_m'][0][0])

if __name__=='__main__':unittest.main()
