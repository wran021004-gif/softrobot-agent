"""Original complete-grid evaluator handles an omitted declared phase default."""
from copy import deepcopy
import unittest
import numpy as np
from tools.task_protocols import load
from extensions.reference.generators import sample
from extensions.reference.protocol_evaluation import evaluate

class PhaseDefault(unittest.TestCase):
    def test_omitted_and_explicit_zero_have_identical_original_acceptance(self):
        case=load('T04').cases[0];task=deepcopy(case.task)
        reference=deepcopy(task['goal']['data']['reference']);reference.pop('phase_rad',None)
        t=np.arange(round(task['timing']['duration_s']/task['timing']['timestep_s'])+1)*task['timing']['timestep_s']
        arrays=dict(time_s=t,tip_m=sample(reference,t)['position_m'],qpos=np.zeros((len(t),2)),qvel=np.zeros((len(t),2)),
            tension_n=np.full((len(t),4),4.),tendon_length_m=np.ones((len(t),4)),contacts=np.zeros(len(t)),warnings=np.zeros(len(t)))
        left=evaluate(case.acceptance,task,arrays,reference=reference)
        right=evaluate(case.acceptance,task,arrays,reference=dict(reference,phase_rad=0.))
        self.assertEqual(left,right);self.assertTrue(left['task_success']);self.assertEqual(left['constraints']['cycle_count_error']['observed'],0.)

if __name__=='__main__':unittest.main()
