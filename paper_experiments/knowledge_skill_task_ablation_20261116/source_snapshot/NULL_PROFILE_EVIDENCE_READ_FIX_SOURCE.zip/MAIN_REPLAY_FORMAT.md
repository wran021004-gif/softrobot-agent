# Main replay export format

Use the registered `trace.replay_export` tool for inspection during a later authorized Study. After the Store is settled, use the formal CLI to produce the final file:

```powershell
python -m tools.research replay-export --store '<actual Store>' --run-id '<actual Study>' --output MAIN_REPLAY_INPUT.json
```

The ordinary `python -m tools.research export ...` also writes `MAIN_REPLAY_INPUT.json` beside its immutable artifact archive. Export reads real Store/Trace records and does not call a Provider, execute a tool, spend a simulation allowance or start Main replay.

Required top-level fields in `main_replay_input_v1`:

| Field | Meaning |
|---|---|
| core_commit / core_worktree_dirty | Identity frozen when the actual session was created |
| task_protocol_hash / bound_task_identity | Frozen catalog definition and effective task including initialization |
| frozen_input / session_snapshots / dependency_identity | Original configurations, child sessions and implementation/schema identities |
| tool_sequence | Actual Host and native entrypoint invocation order |
| tool_calls | Full ToolRequest, original schema, parameter types, receipt, expected output type and actual output/reference |
| native_tool_calls | Original Plan/analysis arguments before compilation, entrypoint, schema and receipt/error |
| worker_requests | Exact sealed launch inputs; dependencies, not additional public research decisions |
| candidate_dependencies / evidence_dependencies | Actual immutable lineage and source references |
| provider_usage / provider_usage_by_role | Raw reported usage and role-separated totals; missing values remain unavailable |
| cost | Budget receipts, scoped resource records, actual source measurements and original counters |
| final_acceptance | Actual saved acceptance/selection gate and separate latest evaluation |
| completeness | Missing reconstruction material; never silently filled |

Future Codex research should issue ordinary Registry/Host requests, record concise research intent with `trace.decision`, retain every failed/incomplete call and use independent Core evaluation before claiming a task pass. Main replay must use the recorded complete request parameters, candidate dependencies and evidence, together with the exact Core commit/protocol. A tool name or approximate parameter summary is insufficient.

The export is replay **input material**, not an automatic execution grant. Original policy, budgets, frozen bindings and unknown-call recovery rules still apply. Replaying an uncertain execution requires an explicit new safe decision; it is never automatically repeated. No real Main replay or successful task replay input was created in this interface-development phase.
