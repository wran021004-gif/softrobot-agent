"""Independent, offline task evaluation from recorded SI observations.

Acceptance thresholds come from the frozen protocol. No dynamics, search,
controller, model reconstruction, callbacks or historical answer selection.
"""
import numpy as np
from schemas.task_protocol import Acceptance


def longest_interval(t,valid):
    best=0.;start=None
    for i,v in enumerate(valid):
        if v and start is None:start=i
        if start is not None and (not v or i==len(valid)-1):
            end=i if v else i-1;best=max(best,float(t[end]-t[start]));start=None
    return best


def evaluate(spec,task,arrays,*,reference=None):
    spec=Acceptance.model_validate(spec);a={k:np.asarray(v) for k,v in arrays.items()}
    p=spec.parameters;checks={};metrics={};details={}
    def bound(name,value,limit,units,*,lower=False,strict=False,tolerance=0.):
        value=float(value);limit=float(limit);margin=value-limit if lower else limit-value
        passed=(margin>0 if strict else margin>=-tolerance)
        checks[name]=bool(passed);details[name]=dict(observed=value,limit=limit,units=units,
            direction='minimum' if lower else 'maximum',strict=strict,tolerance=tolerance,margin=margin)
        return bool(passed)
    def finish():
        # Composite predicates retain a dimensionless satisfaction margin;
        # dimensional subconditions below retain their physical SI margins.
        for name,passed in checks.items():
            if name not in details:
                details[name]=dict(observed=float(passed),limit=1.,units='predicate (1=true, 0=false)',
                    direction='minimum',strict=False,tolerance=0.,margin=float(passed)-1.)
        failed=[k for k,v in checks.items() if not v]
        exact_failures=[k for k in failed if details[k]['limit']==0]
        comparable=[(k,details[k]) for k in (failed or checks) if details[k]['limit']!=0]
        worst=(exact_failures[0] if exact_failures else
            min(comparable,key=lambda row:row[1]['margin']/abs(row[1]['limit']))[0] if comparable else next(iter(checks),None))
        return dict(validity='valid',task_success=not failed,checks=checks,metrics=metrics,constraints=details,
            failed_checks=failed,worst_constraint=worst,
            worst_constraint_basis='Failed checks first; first failed zero-limit check, otherwise smallest margin/abs(limit). Predicate margins are dimensionless.',
            reason=None if not failed else 'HARD_CONSTRAINT_FAILURE')
    missing=set(spec.required_signals)-a.keys()
    if missing:return dict(validity='incomplete',task_success=None,reason='MISSING_SIGNALS: '+','.join(sorted(missing)))
    t=a.get('time_s',np.array([]));dt=task['timing']['timestep_s' if spec.grid=='physics_including_initial' else 'sample_period_s']
    first=0 if spec.grid=='physics_including_initial' else 1;duration=task['timing']['duration_s']
    expected=np.arange(first,round(duration/dt)+1)*dt
    if t.shape!=expected.shape or not np.allclose(t,expected,rtol=0,atol=1e-9):
        return dict(validity='incomplete',task_success=None,reason='COMPLETE_FROZEN_TIME_GRID_REQUIRED')
    for name in spec.required_signals:
        v=a[name]
        if v.ndim<1 or len(v)!=len(t) or not np.issubdtype(v.dtype,np.number) or not np.isfinite(v).all():
            return dict(validity='invalid',task_success=None,reason='NONFINITE_OR_MALFORMED_SIGNAL: '+name)
    for name in ('tip_m','tip_velocity_m_s','tool_axis_world','reference_m','force_n'):
        if name in a and a[name].shape!=(len(t),3):
            return dict(validity='invalid',task_success=None,reason='VECTOR_SIGNAL_SHAPE: '+name)
    channels=p.get('independent_channels')
    if channels:
        for name in ('tension_n','control_n','tendon_length_m','tendon_speed_m_s','tendon_velocity_m_s'):
            if name in a and a[name].shape!=(len(t),channels):
                return dict(validity='invalid',task_success=None,reason='INDEPENDENT_TENDON_CHANNEL_SHAPE: '+name)
    for name in ('contacts','warnings','contact_pairs','unexpected_contact_count','solver_errors'):
        if name in a and (np.any(a[name]<0) or np.any(a[name]!=np.rint(a[name]))):
            return dict(validity='invalid',task_success=None,reason='NONNEGATIVE_INTEGER_COUNT_REQUIRED: '+name)
    def window(lo,hi):
        mask=(t>=lo-1e-9)&(t<=hi+1e-9)
        if not mask.any():raise ValueError('EMPTY_EVALUATION_WINDOW')
        return mask
    if spec.evaluator in ('reach_hold','tool_axis','oriented_tracking'):
        goal=task['goal']['data'];parameters=task['evaluator']['parameters']['data']
        period=task['timing']['sample_period_s']
        formal=np.isclose(t/period,np.rint(t/period),rtol=0,atol=1e-8)&(t>1e-12)
        mask=window(*(p.get('holding_window_s') or task['sampling']['window_s']))&formal
        if spec.evaluator=='oriented_tracking':
            from extensions.reference.contracts import OrientedTrackingGoal
            g=OrientedTrackingGoal.model_validate(goal)
            ref=np.array([g.at_time(min(float(v),g.times_s[-1]))[0] for v in t])
        else:ref=np.asarray(goal['target_m'])
        errors=np.linalg.norm(a['tip_m']-ref,axis=1)
        if spec.evaluator=='reach_hold':
            bound('terminal_position',errors[-1],parameters['tolerance_m'],'m')
            bound('holding_position',max(errors[mask]),p['position_limit_m'],'m')
            bound('holding_speed',max(np.linalg.norm(a['tip_velocity_m_s'][mask],axis=1)),p['speed_limit_m_s'],'m/s')
            metrics.update(terminal_error_m=float(errors[-1]),holding_max_error_m=float(max(errors[mask])),
                holding_max_speed_m_s=float(max(np.linalg.norm(a['tip_velocity_m_s'][mask],axis=1))))
        else:
            limit=parameters.get('position_tolerance_m',parameters.get('max_error_m'))
            bound('tool_position' if spec.evaluator=='tool_axis' else 'tracking_max_error',max(errors[mask]),limit,'m')
            axes=a['tool_axis_world'];norms=np.linalg.norm(axes,axis=1)
            if not np.allclose(norms,1,rtol=0,atol=1e-8):return dict(validity='invalid',task_success=None,reason='UNIT_TOOL_AXIS_REQUIRED')
            refs=(np.array([g.axis_at_time(min(float(v),g.times_s[-1])) for v in t]) if spec.evaluator=='oriented_tracking' else np.asarray(goal['target_axis_world']))
            angles=np.arccos(np.clip(np.sum(axes*refs,axis=1),-1,1))
            bound('tool_axis_direction',max(angles[mask]),parameters['angle_tolerance_rad'],'rad')
            metrics.update(max_position_error=float(max(errors[mask])),max_tool_axis_angle_error=float(max(angles[mask])))
        lo,hi=p['tension_bounds_n'];bound('tension_min',a['tension_n'].min(),lo,'N',lower=True,tolerance=1e-8)
        bound('tension_max',a['tension_n'].max(),hi,'N',tolerance=1e-8)
        if 'geometric_actuator_limits' in p:
            limits=p['geometric_actuator_limits'];lengths=a['tendon_length_m']
            stroke=lengths-lengths[0];lower,upper=limits['stroke_from_initial_bounds_m']
            bound('geometric_stroke_min',stroke.min(),lower,'m',lower=True)
            bound('geometric_stroke_max',stroke.max(),upper,'m')
            bound('geometric_tendon_speed',abs(a['tendon_speed_m_s']).max(),limits['max_tendon_speed_m_s'],'m/s')
            metrics.update(geometric_stroke_min_m=float(stroke.min()),geometric_stroke_max_m=float(stroke.max()),
                geometric_tendon_speed_max_m_s=float(abs(a['tendon_speed_m_s']).max()))
        if p.get('prohibit_contact',False):bound('no_environment_contact',a['contacts'].max(),0,'count')
        bound('solver_errors',a['solver_errors'].max(),0,'count')
    elif spec.evaluator=='figure_eight':
        from extensions.reference.generators import sample
        from schemas.task_protocol import ReferenceGenerator
        initial_phase=ReferenceGenerator.model_validate(reference).phase_rad
        r=sample(reference,t);phase=r['phase_rad'];tip=a['tip_m'];tension=a['tension_n'];lengths=a['tendon_length_m']
        errors=np.linalg.norm(tip-r['position_m'],axis=1);speed=np.gradient(lengths,t,axis=0);stroke=np.ptp(lengths,axis=0)
        first_cycle=(phase>1e-6)&(phase<2*np.pi-1e-6)
        if not first_cycle.any():return dict(validity='incomplete',task_success=None,reason='PHASE_MATCHED_CYCLE_MISSING')
        other=np.column_stack([np.interp(phase[first_cycle]+2*np.pi,phase,tip[:,j]) for j in range(3)])
        drift=float(np.linalg.norm(tip[first_cycle]-other,axis=1).max())
        rmse=float(np.sqrt(np.mean(errors**2)));maximum=float(errors.max())
        bound('tracking_rmse',rmse,p['tracking_rmse_m'],'m',strict=True)
        bound('tracking_max',maximum,p['tracking_max_m'],'m',strict=True)
        bound('stroke',stroke.max(),p['stroke_m'],'m',strict=True)
        bound('speed',abs(speed).max(),p['speed_m_s'],'m/s',strict=True)
        bound('cycle_drift',drift,p['cycle_drift_m'],'m',strict=True)
        bound('cycle_count_error',abs((phase[-1]-initial_phase)/(2*np.pi)-reference['cycles']),1e-6,'cycles',strict=True)
        lower,upper=p['tension_n']
        bound('no_saturation',min(tension.min()-(lower+.0001),(upper-.0001)-tension.max()),0,'N',lower=True,strict=True)
        bound('contacts',a['contacts'].max(),0,'count');bound('warnings',a['warnings'].max(),0,'count')
        lobes=[]
        for cycle,(start,end) in enumerate(p['cycle_windows_s']):
            xyz=tip[(t>=start)&(t<end)];mn=xyz.min(axis=0);mx=xyz.max(axis=0)
            lobes.append(bool(mn[1]<p['lobe_y_min_m'] and mx[1]>p['lobe_y_max_m'] and mn[2]<p['lobe_z_min_m'] and mx[2]>p['lobe_z_max_m']))
            bound(f'cycle_{cycle+1}_lobe_clearance',min(p['lobe_y_min_m']-mn[1],mx[1]-p['lobe_y_max_m'],
                p['lobe_z_min_m']-mn[2],mx[2]-p['lobe_z_max_m']),0,'m',lower=True,strict=True)
        checks['actual_two_lobes_each_cycle']=all(lobes)
        metrics.update(tracking_rmse_m=rmse,max_error_m=maximum,cycle_phase_matched_max_difference_m=drift,
            terminal_speed_m_s=float(np.linalg.norm((tip[-1]-tip[-2])/dt)))
    elif spec.evaluator=='contact_press':
        q=a['button_q_m'];f=a['contact_force_n'];pairs=a['contact_pairs'];h=window(*p['hold_window_s'])
        near=window(*p['contact_time_window_s']);loq,hiq=p['hold_depth_m'];lof,hif=p['hold_normal_contact_force_n']
        valid=h&(q>=loq)&(q<=hiq)&(f>=lof)&(f<=hif)&(a['lateral_error_m']<=p['lateral_xz_error_max_m'])&(pairs>0)
        continuous=longest_interval(t,valid);stroke=a['tendon_length_m']-a['tendon_length_m'][0]
        bound('real_contact_established',max(q[pairs>0],default=0.),.0001,'m',lower=True,strict=True)
        bound('contact_near_approach_end',max(pairs[near],default=0),1,'count',lower=True)
        bound('depth_and_force_hold_0p4s',continuous,p['required_continuous_hold_s'],'s',lower=True,tolerance=1e-9)
        bound('button_travel_max',q.max(),p['max_button_travel_m'],'m',tolerance=1e-9)
        bound('button_travel_min',q.min(),-p['button_negative_tolerance_m'],'m',lower=True)
        lo,hi=p['actuator_tension_n'];bound('tension_min',a['tension_n'].min(),lo,'N',lower=True,tolerance=1e-9)
        bound('tension_max',a['tension_n'].max(),hi,'N',tolerance=1e-9)
        lo,hi=p['actuator_stroke_from_initial_m'];bound('stroke_min',stroke.min(),lo,'m',lower=True,tolerance=1e-9)
        bound('stroke_max',stroke.max(),hi,'m',tolerance=1e-9)
        bound('speed_limit',abs(a['tendon_speed_m_s']).max(),p['rope_speed_limit_m_s'],'m/s',tolerance=1e-9)
        for time in p['release_check_times_s']:
            i=round(time/dt);name='release_'+str(time).replace('.','p')
            bound(name+'_depth',abs(q[i]),p['release_residual_travel_max_m'],'m')
            bound(name+'_force',f[i],p['release_normal_force_max_n'],'N',strict=True)
            bound(name+'_speed',a['tip_speed_m_s'][i],p['release_probe_speed_max_m_s'],'m/s')
        bound('no_unexpected_collision',a['unexpected_contact_count'].max(),0,'count')
        bound('finite_no_warning',a['warnings'].max(),0,'count')
        bound('no_external_force',a['external_force_max'].max(),0,'zero-only wrench diagnostic: force N / torque N.m')
        metrics.update(max_hold_contact_force_error_n=float(abs(f[h]-.1).max()),max_hold_depth_error_m=float(abs(q[h]-.002).max()),
            hold_valid_continuous_s=continuous,max_tension_n=float(a['tension_n'].max()),max_rope_speed_m_s=float(abs(a['tendon_speed_m_s']).max()),max_stroke_m=float(abs(stroke).max()))
    elif spec.evaluator=='impact_recovery':
        error=np.linalg.norm(a['tip_m']-p['target_m'],axis=1);speed=np.linalg.norm(a['tip_velocity_m_s'],axis=1)
        limits=p['acceptance'];windows=p['windows_s'];end=windows['impact'][1]
        valid=(error<=limits['position_error_m']+1e-12)&(speed<=limits['tip_speed_m_s']+1e-12)
        pre=window(*windows['pre_impact_hold']);final=window(*windows['final_hold']);post=t>=end-1e-12
        checks['pre_impact_hold_all_timesteps']=bool(valid[pre].all());checks['final_hold_all_timesteps']=bool(valid[final].all())
        for name,mask in [('pre_impact_hold',pre),('final_hold',final)]:
            bound(name+'_position',error[mask].max(),limits['position_error_m'],'m',tolerance=1e-12)
            bound(name+'_speed',speed[mask].max(),limits['tip_speed_m_s'],'m/s',tolerance=1e-12)
        need=round(limits['continuous_hold_s']/dt);start=None;enter=None;longest=0.
        for k in np.flatnonzero(post):
            if valid[k]:
                if start is None:start=k
                longest=max(longest,float(t[k]-t[start]))
                if k-start>=need and enter is None:enter=float(t[start])
            else:start=None
        checks['recovery_within_0p35s_with_100ms_hold']=bool(enter is not None and enter<=end+limits['recovery_deadline_s_after_pulse']+1e-12)
        lo,hi=limits['tension_bounds_n'];bound('tension_min',a['tension_n'].min(),lo,'N',lower=True,tolerance=1e-9)
        bound('tension_max',a['tension_n'].max(),hi,'N',tolerance=1e-9)
        bound('stroke_limit',abs(a['tendon_length_m']-a['tendon_length_m'][0]).max(),limits['geometric_tendon_stroke_m'],'m',tolerance=1e-9)
        bound('actual_speed_limit',abs(a['tendon_velocity_m_s']).max(),limits['actual_tendon_speed_m_s'],'m/s',tolerance=1e-9)
        bound('no_unexpected_collision',a['contacts'].max(),0,'count');bound('finite_no_warning',a['warnings'].max(),0,'count')
        bound('force_off_after_pulse',abs(a['force_n'][post]).max(),1e-12,'N',strict=True)
        metrics.update(pre_hold_max_error_m=float(error[pre].max()),pre_hold_max_speed_m_s=float(speed[pre].max()),
            recovery_time_after_pulse_s=None if enter is None else max(0,enter-end),continuous_post_pulse_valid_s=longest,
            final_hold_max_error_m=float(error[final].max()),final_hold_max_speed_m_s=float(speed[final].max()),
            max_tendon_speed_m_s=float(abs(a['tendon_velocity_m_s']).max()),max_tendon_stroke_m=float(abs(a['tendon_length_m']-a['tendon_length_m'][0]).max()))
    else:
        return dict(validity='unsupported',task_success=None,reason='PASSIVE_PROGRAM_REQUIRES_REGISTERED_V2_EVIDENCE; display replay cannot certify stability or route validity')
    return finish()


def as_platform(outcome,source,evaluator,identity):
    from schemas.platform import EvaluationResult,Metric,ConstraintResult
    valid=outcome['validity']=='valid'
    return EvaluationResult(validity=outcome['validity'],task_success=outcome['task_success'],source=source,
        evaluator=evaluator,comparison_identity=identity,reason=outcome.get('reason'),diagnostics=outcome,
        metrics=[Metric(name='hard_constraints_passed',value=sum(outcome.get('checks',{}).values()),units='count')] if valid else [],
        constraints=[ConstraintResult(name=k,satisfied=outcome['checks'][k],observed=v['observed'],limit=v['limit'],units=v['units']) for k,v in outcome.get('constraints',{}).items()])
