"""Safe analytical references, including the frozen integrated speed-ramp phase."""
import numpy as np
from schemas.task_protocol import ReferenceGenerator
from schemas.common import Contract
from typing import Literal


class ParametricTrackingGoal(Contract):
    reference: ReferenceGenerator
    time_requirement: Literal['timed'] = 'timed'
    frame: Literal['world'] = 'world'
    units: Literal['m'] = 'm'

    @property
    def times_s(self):return [0.,self.reference.duration_s]

    def at_time(self,time_s):
        r=sample(self.reference,time_s,prediction=True)
        return r['position_m'].tolist(),r['velocity_m_s'].tolist()


def sample(spec, times, *, prediction=False):
    p=ReferenceGenerator.model_validate(spec)
    t=np.asarray(times,dtype=float)
    if not np.isfinite(t).all() or np.any(t<0) or (not prediction and np.any(t>p.duration_s+1e-10)):
        raise ValueError('REFERENCE_TIME_OUTSIDE_FROZEN_HORIZON')
    tail=t>p.duration_s
    t=np.minimum(t,p.duration_s)
    position=np.broadcast_to(p.center_m,t.shape+(3,)).copy();velocity=np.zeros_like(position)
    phase=np.zeros(t.shape)+p.phase_rad
    if p.kind=='figure_eight':
        smooth=lambda x:10*x**3-15*x**4+6*x**5
        integral=lambda x:2.5*x**4-3*x**5+x**6
        clock=t.copy();rate=np.ones_like(t)
        if p.start_ramp_s:
            u=np.clip(t/p.start_ramp_s,0,1)
            clock=np.where(t<p.start_ramp_s,p.start_ramp_s*integral(u),t-p.start_ramp_s/2)
            rate=np.where(t<p.start_ramp_s,smooth(u),rate)
        if p.stop_ramp_s:
            onset=p.duration_s-p.stop_ramp_s;u=np.clip((t-onset)/p.stop_ramp_s,0,1)
            clock=np.where(t>=onset,onset-p.start_ramp_s/2+p.stop_ramp_s*(u-integral(u)),clock)
            rate=np.where(t>=onset,1-smooth(u),rate)
        omega=2*np.pi*p.frequency_hz;phase=p.phase_rad+omega*clock
        position[...,1]+=p.amplitude_y_m*np.sin(phase)
        position[...,2]+=p.amplitude_z_m*np.sin(2*phase)
        velocity[...,1]=p.amplitude_y_m*np.cos(phase)*omega*rate
        velocity[...,2]=2*p.amplitude_z_m*np.cos(2*phase)*omega*rate
    elif p.kind=='quintic_nodes':
        index=np.clip(np.searchsorted(p.times_s,t,side='right')-1,0,len(p.times_s)-2)
        nodes=np.asarray(p.positions_m);clocks=np.asarray(p.times_s);h=clocks[index+1]-clocks[index]
        u=(t-clocks[index])/h;s=10*u**3-15*u**4+6*u**5;ds=(30*u**2-60*u**3+30*u**4)/h
        delta=nodes[index+1]-nodes[index]
        position=nodes[index]+s[...,None]*delta;velocity=ds[...,None]*delta
    velocity=np.where(tail[...,None],0,velocity)
    return dict(position_m=position,velocity_m_s=velocity,phase_rad=phase)


def generate(ctx,args):
    from schemas.platform import Payload
    result=sample(args.reference,args.times_s,prediction=args.prediction)
    return Payload(contract='reference.generated_samples',data={k:v.tolist() for k,v in result.items()})
