from tools.platform_registry import Extension
from tools.paths import ROOT
from schemas.platform import Payload, EvaluationResult, TaskDefinition
from schemas.task_protocol import TaskProtocol,TaskEvidence
from tools.task_protocols import ProtocolQuery,BindProtocol,EvaluateProtocol,AggregateProtocol,GenerateReference
from extensions.reference.generators import ParametricTrackingGoal

SOURCES=('schemas/task_protocol.py','tools/task_protocols.py','extensions/reference/generators.py',
    'tools/research/replay_export.py',
    'tools/research/prepared_initial.py','tools/research/protocol_adapter.py','tools/research/protocol_tools.py','tools/research/registry_bridge.py',
    'extensions/reference/protocol_evaluation.py','extensions/tendon_family/environment.py',
    'extensions/tendon_family/task_observations.py','extensions/task_protocol/manifest.py')
ASSETS=tuple('TASK_PROTOCOLS/T%02d.json'%i for i in range(1,11))+('TASK_PROTOCOLS/T08_SOURCE.json',)
CONTRACTS=[('task.protocol','1.0.0',TaskProtocol),('reference.parametric_tracking_goal','1.0.0',ParametricTrackingGoal),('task.observations','1.0.0',TaskEvidence)]
EXTENSIONS=[Extension(name,'tool','1.0.0',inp,out,binding,description,sources=SOURCES,assets=ASSETS,
    capabilities={'category':'evaluation_comparison','role':'public_tool','backend_solves':0},side_effects='artifact_store')
    for name,inp,out,binding,description in (
        ('task.protocol.inspect',ProtocolQuery,Payload,'tools.task_protocols:inspect','Read one frozen ten-task protocol and all condition bindings; no engine or Provider.'),
        ('task.protocol.bind',BindProtocol,Payload,'tools.task_protocols:bind','Validate an owned candidate configuration against a frozen protocol case; no research execution.'),
        ('task.protocol.evaluate',EvaluateProtocol,EvaluationResult,'tools.task_protocols:evaluate','Independently evaluate saved complete task observations; return every hard constraint, margin and failure. Historical regression never becomes new Study success.'),
        ('task.protocol.aggregate',AggregateProtocol,Payload,'tools.task_protocols:aggregate_tool','Aggregate required protocol cases on one design; preserve each subtask and report frozen-input controls separately. No acceptance transfer.'),
        ('reference.generate',GenerateReference,Payload,'extensions.reference.generators:generate','Sample a safe versioned analytical position/velocity reference, including integrated quintic speed ramps. No callbacks.'))]
EXTENSIONS.append(Extension('evaluate.task_protocol','evaluator','1.0.0',TaskDefinition,EvaluationResult,
    'tools.task_protocols:evaluate_backend','Independent complete frozen protocol acceptance over actual Core evidence.',sources=SOURCES,assets=ASSETS))
from tools.research.replay_export import Decision,ReplayRequest
from tools.research.prepared_initial import QualifyInitial
from tools.research.construct_initial import ConstructInitial
from tools.research.contracts import AnalysisRequest,Plan
from tools.research.passive_history import HistoryAudit
EXTENSIONS.extend([
    Extension('task.initial_state.construct','tool','1.0.0',ConstructInitial,Payload,'tools.research.construct_initial:run',
        'Construct a native force-balanced initial state at t=0 of the frozen parametric reference using existing SLSQP. No integration. Separate qualification remains mandatory.',
        sources=(*SOURCES,'tools/research/construct_initial.py'),assets=ASSETS,dependencies=('mujoco','numpy','scipy'),side_effects='artifact_store'),
    Extension('evidence.passive_history.audit','tool','1.0.0',HistoryAudit,Payload,'tools.research.passive_history:run',
        'Read-only hash-verified recovery of legacy passive Store/CSV evidence and evaluator regression. No candidate transfer, integration or new Study acceptance.',
        sources=(*SOURCES,'tools/research/passive_history.py'),assets=ASSETS,dependencies=('numpy',),side_effects='artifact_store'),
    Extension('task.initial_state.qualify','tool','1.0.0',QualifyInitial,Payload,'tools.research.prepared_initial:run',
        'Statically qualify a supplied candidate equilibrium with one mj_forward and frozen balance tolerance. No optimization, search or integration; saves named state and actual preload evidence.',
        sources=(*SOURCES,'tools/research/prepared_initial.py'),assets=ASSETS,dependencies=('mujoco','numpy'),side_effects='artifact_store'),
    Extension('trace.decision','tool','1.0.0',Decision,Payload,'tools.research.replay_export:record_decision',
        'Record a concise auditable research intent and decision summary; no private reasoning.',sources=SOURCES,side_effects='artifact_store'),
    Extension('trace.replay_export','tool','1.0.0',ReplayRequest,Payload,'tools.research.replay_export:export_tool',
        'Export exact Store-derived requests, schemas, outputs, evidence dependencies and separate costs; never execute Replay.',sources=SOURCES,side_effects='artifact_store')])
_RESEARCH_SOURCES=tuple(dict.fromkeys((*SOURCES,'tools/research/registry_bridge.py',
    *(p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'tools/research').glob('*.py'))))))
EXTENSIONS.extend([
    Extension('research.dispatch','tool','1.0.0',Plan,Payload,'tools.research.registry_bridge:plan',
        'Invoke the existing Core Plan dispatcher. Original candidate ownership, method authorization, budgets, Workers, independent evaluation and delivery gates all apply.',
        sources=_RESEARCH_SOURCES,capabilities={'preflight':'tools.research.registry_bridge:plan_preflight','delegated_execution':True},side_effects='existing_research_dispatcher'),
    Extension('research.math','tool','1.0.0',AnalysisRequest,Payload,'tools.research.registry_bridge:mathematics',
        'Invoke the existing candidate-bound mathematical dispatcher and its registered method catalog. No new optimization algorithm; original method grants, budgets, model applicability and evidence apply.',
        sources=_RESEARCH_SOURCES,capabilities={'preflight':'tools.research.registry_bridge:math_preflight','delegated_execution':True},side_effects='existing_research_worker')])

# One existing physical lifecycle for all active protocols. Orientation continues
# through the registered native-sequence path; no position-only NMPC pose claim.
from dataclasses import replace
from extensions.tendon_family.manifest import EXTENSIONS as FAMILY_EXTENSIONS
from extensions.tendon_family.manifest import PLATFORM_SOURCES,PHYSICAL_SOURCES
EXTENSIONS=[replace(e,sources=tuple(dict.fromkeys((*e.sources,*PLATFORM_SOURCES,*PHYSICAL_SOURCES,
    'extensions/tendon_family/mujoco_analysis.py')))) if e.extension_id=='task.initial_state.construct' else e for e in EXTENSIONS]
_backend=next(d for d in FAMILY_EXTENSIONS if d.extension_id=='backend.family_mujoco' and d.version=='1.2.0')
EXTENSIONS.append(replace(_backend,version='1.5.0',binding='extensions.tendon_family.backends:NativeSequenceMujocoBackend',
    sources=tuple(dict.fromkeys((*_backend.sources,*SOURCES,'extensions/tendon_family/native_feedback.py'))),assets=ASSETS,
    capabilities={**_backend.capabilities,'families':['task.reach','task.tracking','task.position_tool_axis','task.oriented_tracking'],
        'controllers':[*_backend.capabilities['controllers'],'controller.native_state_feedback'],
        'signals':[*_backend.capabilities['signals'],'tip_tool_axis'],
        'environment_extensions':['world_com_wrench_v1','physical_environment_v1'],
        'controller_information_flow':'environment injection schedules removed before controller construction',
        'orientation_control':'existing native sequence optimization plus physical Replay; orientation NMPC remains unsupported',
        'dense_protocol_evidence':'Data.task_evidence; every physics step and initial state; true native contact force'}))
