"""Shared task protocol extensions; no task-specific solvers."""
