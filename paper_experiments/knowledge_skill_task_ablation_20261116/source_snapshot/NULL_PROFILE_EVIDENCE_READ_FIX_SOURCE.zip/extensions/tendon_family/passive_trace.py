"""Dense passive observations appended to the existing physical-step CSV."""
import json
import numpy as np
from .passive import material_point

COLUMNS=['point_x_m','point_y_m','point_z_m','velocity_x_m_s','velocity_y_m_s','velocity_z_m_s',
    'displacement_from_initial_x_m','displacement_from_initial_y_m','displacement_from_initial_z_m',
    'constraint_states_json','constraint_residuals_m_json','constraint_classification_json',
    'route_status','route_checked_poses','solver_iterations','qacc_warmstart_json']


def values(native,data,mechanism,material_s,initial_point,route):
    point,jacobian,_=native.point(data,material_point(native.physics,material_s))
    encode=lambda value:json.dumps(value,separators=(',',':'),allow_nan=False)
    return [*point,*(jacobian@data.qvel),*(point-np.asarray(initial_point)),
        encode(mechanism['constraint_states']),encode(mechanism['constraint_residuals_m']),
        encode(mechanism['constraint_classification']),route['status'],route['checked_poses'],
        int(np.max(data.solver_niter)),encode(data.qacc_warmstart.tolist())]


def semantics(material_s):
    return dict(version='passive_dense_trace_v3',material_s=material_s,position_units='m',velocity_units='m/s',
        frame='world',displacement_reference='episode initial material-point position; acceptance still uses qualified unloaded tail mean',
        state_phase='post-step forward',force_phase='actual force held over the preceding integration interval',
        constraint_source='actual native tendon-limit rows; JSON preserves all rows and absent-row empty lists',
        route_source='cumulative actual route check through this post-step pose',rows='one per successful mj_step; initial state retained separately')
