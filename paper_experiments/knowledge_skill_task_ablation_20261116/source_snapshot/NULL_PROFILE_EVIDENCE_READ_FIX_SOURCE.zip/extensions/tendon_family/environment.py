"""Generic native MuJoCo environment composition and measured observations.

No stepping, controller, force surrogate or task-specific runner lives here.
"""
import xml.etree.ElementTree as ET
import numpy as np
from schemas.task_protocol import PhysicalEnvironment, Wrench


def wrench_at(value,time_s):
    p=Wrench.model_validate(value)
    alpha=(time_s-p.start_s)/(p.end_s-p.start_s)
    scale=0.
    if 0<=alpha<1:
        scale={'constant':lambda:1.,'half_sine':lambda:np.sin(np.pi*alpha),
            'linear':lambda:alpha,'smoothstep':lambda:alpha*alpha*(3-2*alpha)}[p.waveform]()
    return np.r_[p.force_n,p.torque_nm]*scale


def emit(root,value):
    from .mjcf import fmt
    p=PhysicalEnvironment.model_validate(value)
    world=root.find('worldbody');bodies={b.get('name'):b for b in world.iter('body')};bodies['world']=world
    if p.robot_hinge_range_rad:
        for joint in world.iter('joint'):
            joint.attrib.update(limited='true',range=fmt(p.robot_hinge_range_rad))
    if p.actuator_min_tension_n is not None:
        for actuator in root.find('actuator'):
            upper=float(actuator.get('ctrlrange').split()[1])
            if p.actuator_min_tension_n>=upper:raise ValueError('ENVIRONMENT_ACTUATOR_BOUND_CONFLICT')
            actuator.set('ctrlrange',fmt([p.actuator_min_tension_n,upper]))
    if p.solver_iterations:root.find('option').set('iterations',str(p.solver_iterations))
    if p.solver_tolerance:root.find('option').set('tolerance',str(p.solver_tolerance))
    if p.collision_policy=='self_environment_frictionless':
        for geom in root.iter('geom'):
            geom.attrib.update(condim='1',friction='0 0 0',solref='.003 1',solimp='.98 .995 .0001')
            # Explicitly noncolliding physical accessories remain noncolliding;
            # environment policy must not turn guide eyes/spokes into obstacles.
            if not (geom.get('contype')=='0' and geom.get('conaffinity')=='0'):
                geom.attrib.update(contype='8' if geom.get('type')=='plane' else '1',conaffinity='1' if geom.get('type')=='plane' else '13')
    for name in p.replace_robot_geometries:
        matches=[(body,g) for body in world.iter() for g in list(body) if g.tag=='geom' and g.get('name')==name]
        if len(matches)!=1:raise ValueError('REPLACED_GEOMETRY_NOT_FOUND: '+name)
        matches[0][0].remove(matches[0][1])
    for b in p.bodies:
        if b.name in bodies:raise ValueError('ENVIRONMENT_BODY_NAME_CONFLICT')
        body=ET.SubElement(world,'body',name=b.name,pos=fmt(b.position_m),quat=fmt(b.quaternion_wxyz));bodies[b.name]=body
        I=np.asarray(b.inertia_com_local_kg_m2)
        ET.SubElement(body,'inertial',mass=str(b.mass_kg),pos=fmt(b.com_local_m),
            fullinertia=fmt([I[0,0],I[1,1],I[2,2],I[0,1],I[0,2],I[1,2]]))
        ET.SubElement(body,'joint',name=b.joint_name,type=b.joint_kind,axis=fmt(b.axis_local),limited='true',
            range=fmt(b.joint_range),stiffness=str(b.stiffness),damping=str(b.damping),springref=str(b.spring_reference))
        if p.collision_policy=='self_environment_frictionless':
            body.find('joint').attrib.update(solreflimit='.003 1',solimplimit='.98 .995 .0001')
    names={g.get('name') for g in root.iter('geom')}
    for g in p.geometries:
        if g.body not in bodies or g.name in names:raise ValueError('GEOMETRY_BODY_OR_NAME_INVALID: '+g.name)
        names.add(g.name)
        attrs=dict(density='0')
        if p.collision_policy=='self_environment_frictionless':attrs.update(friction='0 0 0',condim='1',solref='.003 1',solimp='.98 .995 .0001')
        ET.SubElement(bodies[g.body],'geom',name=g.name,type=g.kind,pos=fmt(g.position_m),
            quat=fmt(g.quaternion_wxyz),size=fmt(g.size_m),contype=str(g.contype),conaffinity=str(g.conaffinity),
            **attrs)
    for site in p.sites:
        if site.body not in bodies or any(s.get('name')==site.name for s in root.iter('site')):raise ValueError('OBSERVATION_SITE_NAME_OR_BODY_INVALID')
        ET.SubElement(bodies[site.body],'site',name=site.name,pos=fmt(site.position_m),size='.0008')
    if p.contact_pairs:
        contact=root.find('contact')
        if contact is None:contact=ET.SubElement(root,'contact')
        for pair in p.contact_pairs:
            if {pair.geom1,pair.geom2}-names:raise ValueError('CONTACT_PAIR_GEOMETRY_NOT_FOUND')
            ET.SubElement(contact,'pair',geom1=pair.geom1,geom2=pair.geom2,condim=str(pair.condim),
                friction=fmt(pair.friction),solref=fmt(pair.solref),solimp=fmt(pair.solimp))


def initialize(model,data,value):
    for b in PhysicalEnvironment.model_validate(value).bodies:
        j=model.joint(b.joint_name).id
        data.qpos[model.jnt_qposadr[j]]=b.initial_position
        data.qvel[model.jnt_dofadr[j]]=b.initial_velocity


def observe(model,data,value):
    import mujoco
    p=PhysicalEnvironment.model_validate(value)
    pairs={frozenset((pair.geom1,pair.geom2)):dict(geometries=[pair.geom1,pair.geom2],normal_force_n=0.,count=0) for pair in p.contact_pairs}
    unexpected=[]
    for i,c in enumerate(data.contact):
        names=frozenset((model.geom(int(c.geom1)).name,model.geom(int(c.geom2)).name))
        if names in pairs:
            f=np.zeros(6);mujoco.mj_contactForce(model,data,i,f)
            pairs[names]['normal_force_n']+=max(0.,float(f[0]));pairs[names]['count']+=1
        elif c.dist<=0:unexpected.append(sorted(names))
    joints={}
    for body in p.bodies:
        j=model.joint(body.joint_name).id;q=model.jnt_qposadr[j];v=model.jnt_dofadr[j]
        joints[body.joint_name]=dict(position=float(data.qpos[q]),velocity=float(data.qvel[v]),acceleration=float(data.qacc[v]),
            position_units='m' if body.joint_kind=='slide' else 'rad',velocity_units='m/s' if body.joint_kind=='slide' else 'rad/s')
    return dict(contact_pairs=list(pairs.values()),joints=joints,unexpected_contacts=unexpected,
        contact_force_source='mj_contactForce normal component; separate from spring and damper',phase='post_step_forward')


def controller_task(task):
    """Remove environment injection schedules before constructing any controller."""
    from copy import deepcopy
    value=deepcopy(task.model_dump(mode='json'));value.pop('acceptance',None)
    if task.acceptance and task.acceptance.evaluator=='impact_recovery':
        value.update(task_id='blind-fixed-target-stabilization',name='Fixed target stabilization',
            source='Controller receives normal robot state and fixed reference; environment condition identifiers and schedules are withheld.')
    env=value['environment']['data'];env['external_forces']=[]
    if env.get('physical_environment'):
        env['physical_environment']['wrenches']=[]
        env['physical_environment']['input_freeze_after_s']=None
    return value


def frozen_input(time_s,current_input,environment):
    after=(environment or {}).get('input_freeze_after_s')
    return np.asarray(current_input).copy() if after is not None and time_s>=after-1e-12 else None


def controller_reference_clock(task,time_s):
    """The M7 normal task clock is available for approach reference only."""
    if task.acceptance and task.acceptance.evaluator=='impact_recovery':
        return min(float(time_s),task.acceptance.parameters['windows_s']['approach'][1])
    return float(time_s)
