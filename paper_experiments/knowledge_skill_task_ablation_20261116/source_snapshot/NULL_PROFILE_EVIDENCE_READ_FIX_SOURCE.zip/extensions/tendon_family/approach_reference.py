"""Optional controller-owned approach; the frozen task reference is unchanged."""
import numpy as np

def sample(origin,target,times,profile):
    t=np.asarray(times,dtype=float);duration=profile.end_s;ramp=profile.ramp_s
    x=np.clip(t,0,duration);vmax=1/(duration-ramp)
    up=x<ramp;down=x>duration-ramp
    progress=vmax*(x-ramp/2);rate=np.full_like(x,vmax)
    progress=np.where(up,.5*vmax*(x-ramp/np.pi*np.sin(np.pi*x/ramp)),progress)
    rate=np.where(up,.5*vmax*(1-np.cos(np.pi*x/ramp)),rate)
    remaining=duration-x
    progress=np.where(down,1-.5*vmax*(remaining-ramp/np.pi*np.sin(np.pi*remaining/ramp)),progress)
    rate=np.where(down,.5*vmax*(1-np.cos(np.pi*remaining/ramp)),rate)
    progress=np.where(t>=duration,1.,np.where(t<=0,0.,progress));rate=np.where((t<=0)|(t>=duration),0.,rate)
    delta=np.asarray(target)-np.asarray(origin)
    return np.asarray(origin)+progress[...,None]*delta,rate[...,None]*delta
