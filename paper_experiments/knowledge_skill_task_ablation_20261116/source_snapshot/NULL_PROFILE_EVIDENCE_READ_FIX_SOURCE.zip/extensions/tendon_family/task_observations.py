"""Dense actual engine observations for independent frozen-protocol evaluation."""
import numpy as np
from tools.state_io import digest


class Recorder:
    def __init__(self,model,task,tendon_ids,actuator_ids,robot_qpos_indices,*,binding=None):
        self.model=model;self.task=task;self.tids=tendon_ids;self.aids=actuator_ids;self.qi=robot_qpos_indices
        self.extension=task.environment.data.get('physical_environment');self.rows=[];self.impulse=np.zeros(3)
        self.binding=binding or {}
        self.site=model.site(task.acceptance.parameters.get('observation_site','tip_site')).id

    def capture(self,data,*,preceding_wrench=None,preceding_points=None):
        import mujoco
        from .environment import observe
        m=self.model;J=np.zeros((3,m.nv));Jr=np.zeros_like(J);mujoco.mj_jacSite(m,data,J,Jr,self.site)
        velocity=J@data.qvel;force=np.zeros(3) if preceding_wrench is None else np.asarray(preceding_wrench)[:3]
        if self.rows:self.impulse+=force*m.opt.timestep
        row=dict(time_s=float(data.time),qpos=data.qpos.tolist(),qvel=data.qvel.tolist(),
            tip_m=data.site_xpos[self.site].tolist(),tip_velocity_m_s=velocity.tolist(),tip_speed_m_s=float(np.linalg.norm(velocity)),
            tool_axis_world=(data.site_xmat[self.site].reshape(3,3)@np.asarray(self.task.goal.data.get('axis_local',[1.,0.,0.]))).tolist(),
            tip_rotation_world=data.site_xmat[self.site].tolist(),
            tension_n=(-data.actuator_force[self.aids]).tolist(),control_n=data.ctrl[self.aids].tolist(),
            tendon_length_m=data.ten_length[self.tids].tolist(),tendon_speed_m_s=data.ten_velocity[self.tids].tolist(),
            tendon_velocity_m_s=data.ten_velocity[self.tids].tolist(),contacts=int(data.ncon),
            warnings=max((int(w.number) for w in data.warning),default=0),
            force_n=np.sum(data.xfrc_applied[:,:3],axis=0).tolist(),previous_step_force_n=force.tolist(),
            impulse_ns=self.impulse.tolist(),external_force_max=float(abs(data.xfrc_applied).max()),
            external_force_max_n=float(abs(data.xfrc_applied[:,:3]).max()),
            external_torque_max_nm=float(abs(data.xfrc_applied[:,3:]).max()))
        if self.extension and self.extension.get('wrenches'):
            from .environment import wrench_at
            row['force_n']=sum((wrench_at(w,float(data.time))[:3] for w in self.extension['wrenches']),np.zeros(3)).tolist()
            row['applied_wrenches']=[dict(entity=w['entity'],frame='world',point='center_of_mass',
                application_point_world_m=data.xipos[m.body(w['entity']).id].tolist(),
                preceding_step_application_point_world_m=(preceding_points or {}).get(w['entity']),
                current_sample_wrench=wrench_at(w,float(data.time)).tolist(),preceding_step_wrench=data.xfrc_applied[m.body(w['entity']).id].tolist()) for w in self.extension['wrenches']]
        if self.extension:
            observed=observe(m,data,self.extension);row['environment_observation']=observed
            row['unexpected_contact_count']=len(observed['unexpected_contacts'])
            if observed['contact_pairs']:
                pair=observed['contact_pairs'][0];row.update(contact_force_n=pair['normal_force_n'],contact_pairs=pair['count'])
            if 'button_slide' in observed['joints']:
                joint=observed['joints']['button_slide'];row.update(button_q_m=joint['position'],button_qdot_m_s=joint['velocity'],button_qacc_m_s2=joint['acceleration'])
                center=self.task.acceptance.parameters.get('button_center_unpressed_m')
                if center:row['lateral_error_m']=float(np.linalg.norm(data.site_xpos[self.site][[0,2]]-np.asarray(center)[[0,2]]))
        self.rows.append(row)

    def export(self):
        keys=set.intersection(*(set(r) for r in self.rows)) if self.rows else set()
        arrays={k:[r[k] for r in self.rows] for k in sorted(keys) if k not in ('environment_observation','applied_wrenches')}
        definitions={}
        for key,values in arrays.items():
            units=('s' if key=='time_s' else 'm/s^2' if key.endswith('qacc_m_s2') else
                'm/s' if key.endswith(('m_s','velocity_m_s')) else 'm' if key.endswith('_m') else
                'N.s' if key=='impulse_ns' else 'N.m' if key.endswith('_nm') else
                'mixed wrench components: force N, torque N.m; zero-only diagnostic' if key=='external_force_max' else 'N' if key.endswith('_n') else
                'per-joint: hinge rad, slide m; joint_layout' if key=='qpos' else
                'per-joint: hinge rad/s, slide m/s; joint_layout' if key=='qvel' else '1')
            frame='world' if key in ('tip_m','tip_velocity_m_s','tool_axis_world','tip_rotation_world','force_n','previous_step_force_n','impulse_ns') else 'named_tendon_path' if key.startswith(('tendon_','tension','control')) else 'named_environment_joint' if key.startswith('button_') else 'engine_state'
            phase='preceding_interval_start' if key=='previous_step_force_n' else 'post_step_forward_including_initial'
            source='mj_contactForce normal component' if key=='contact_force_n' else 'analytical MuJoCo tendon velocity' if key in ('tendon_speed_m_s','tendon_velocity_m_s') else 'sampled environment waveform' if key=='force_n' else 'measured engine state or recorded execution counter'
            definitions[key]=dict(dimension=len(values[0]) if values and isinstance(values[0],list) else 1,units=units,frame=frame,phase=phase,source=source)
        from schemas.task_protocol import TaskEvidence
        return TaskEvidence.model_validate(dict(version='core_task_evidence_v1',task_identity=digest(self.task.model_dump(mode='json')),
            **self.binding,tendon_order=[self.model.tendon(i).name for i in self.tids],
            joint_layout=[dict(name=self.model.joint(j).name,kind=int(self.model.jnt_type[j]),qpos_address=int(self.model.jnt_qposadr[j]),dof_address=int(self.model.jnt_dofadr[j])) for j in range(self.model.njnt)],
            origin='core_execution',arrays=arrays,signal_definitions=definitions,
            applied_wrench_history=[r.get('applied_wrenches',[]) for r in self.rows],
            environment_states=[r.get('environment_observation') for r in self.rows],
            timing=dict(state='post_step_forward',force='interval_start; previous_step_force_n drove the preceding step',
                impulse='left_rectangle sum of actual preceding-step world forces times physical timestep'),
            physics_steps=max(0,len(self.rows)-1))).model_dump(mode='json')
