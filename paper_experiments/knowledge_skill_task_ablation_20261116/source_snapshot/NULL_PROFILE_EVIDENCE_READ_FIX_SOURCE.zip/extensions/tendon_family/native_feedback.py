"""Native equilibrium/tangent feedback exposed through the existing control runtime.

Uses the historical full-state LQR procedure with current native mechanics.
The controller receives ordinary joint state and a fixed target, never the
environment's impulse schedule or frozen-input condition.
"""
import time
import numpy as np
from pydantic import Field,FiniteFloat
from schemas.common import Contract
from tools.platform_store import plain
from tools.state_io import digest
from .gvs_profile import SampledSettling


class NativeFeedbackRecipe(Contract):
    reach_end_s: FiniteFloat = Field(default=.27,gt=0)
    reference_ramp_s: FiniteFloat = Field(default=.04,gt=0)
    startup_s: FiniteFloat = Field(default=.02,gt=0)
    startup_feedback_s: FiniteFloat = Field(default=.13,gt=0)
    position_scale_m: FiniteFloat = Field(default=.02,gt=0)
    joint_weight: FiniteFloat = Field(default=.01,gt=0)
    holding_tip_speed_weight: FiniteFloat = Field(default=.5,ge=0,description='Global tip-velocity state penalty in this fixed-target feedback controller.')
    terminal_tip_speed_weight: FiniteFloat = Field(default=0.,ge=0,description='Additional tip-velocity state penalty; summed with holding_tip_speed_weight.')
    joint_velocity_weight: FiniteFloat = Field(default=.0001,gt=0)
    tendon_velocity_weight: FiniteFloat = Field(default=2.,ge=0)
    tension_weight: FiniteFloat = Field(default=1.,gt=0)
    tension_rate_n_s: FiniteFloat = Field(default=200.,gt=0)
    input_change_weight: FiniteFloat = Field(default=.01,ge=0)
    bank_stroke_weight: FiniteFloat = Field(default=200.,ge=0)
    bank_tension_weight: FiniteFloat = Field(default=.02,ge=0)
    bank_max_evaluations: int = Field(default=120,ge=1,le=500)
    tangent_step_rad: FiniteFloat = Field(default=1e-5,gt=0)


class NativeFeedbackControl(Contract):
    numerical_source: str = 'initial_state_pretension'
    recipe: NativeFeedbackRecipe = Field(default_factory=NativeFeedbackRecipe)
    settling: SampledSettling = Field(default_factory=SampledSettling)


def checked_control(inp):
    control=NativeFeedbackControl.model_validate(inp.policy.controller.parameters.data)
    t=inp.task.timing
    if (inp.task.family!='task.reach' or inp.policy.backend.extension_id!='backend.family_mujoco'
            or inp.policy.backend.version!='1.5.0' or control.numerical_source!='initial_state_pretension'):
        raise ValueError('NATIVE_FEEDBACK_REQUIRES_NATIVE_REACH_EXECUTION')
    if (2*control.recipe.reference_ramp_s>control.recipe.reach_end_s
            or control.recipe.reach_end_s>t.duration_s or t.sample_period_s!=t.control_period_s
            or any(abs(v-round(v))>1e-8 for v in (t.control_period_s/t.timestep_s,t.duration_s/t.control_period_s))):
        raise ValueError('NATIVE_FEEDBACK_TIMING_MISMATCH')
    return control


def resolve_control(inp,physics):
    from .environment import controller_task
    from .gvs_basis import resolve_basis
    from .gvs_projection import description
    control=checked_control(inp)
    plan=dict(mode='native_state_feedback',tension_execution_mode='ideal_tension',
        robot=plain(inp.robot),task=controller_task(inp.task),
        configuration={**plain(inp),'task':controller_task(inp.task)},
        parameters=plain(control),reference=dict(u0=[inp.task.initializer.parameters.data.get('tensions_n',{}).get(t['entity'],
            inp.task.acceptance.parameters.get('initial_tension_n',t['pretension_n']) if inp.task.acceptance else t['pretension_n']) for t in physics['tendons']]),
        projector=description(physics,resolve_basis(inp.robot.structure.data,dict(strategy='first_order'))),
        input_interpolation='linear_control_interval_v1',
        observation_space='native_named_joint_position_velocity',
        mathematical_scope='Two algebraic equilibrium nodes, native centered force tangent, exact held-input linear discretization, discrete LQR; local feedback only. No nonlinear stability or global optimality claim.')
    plan['identity']=digest({k:v for k,v in plan.items() if k!='configuration'});return plan


def prepare(native,target,recipe,period):
    import mujoco
    from scipy.optimize import least_squares
    from scipy.linalg import expm
    m=native.model;d=mujoco.MjData(m);n=len(native.order);nu=len(native.tendons)
    if m.nv!=n or m.nq!=n:raise ValueError('NATIVE_FEEDBACK_REQUIRES_ONLY_NAMED_HINGE_STATES')
    if np.any(native.limits[:,0]!=0.) or np.any(native.limits[:,1]<7.5):
        raise ValueError('NATIVE_FEEDBACK_EQUILIBRIUM_SEARCH_REQUIRES_ZERO_TO_7P5_N_BOX')
    native.forward(d);origin=d.site_xpos[native.tip].copy();lengths=d.ten_length[native.tids].copy()
    lower=np.r_[np.full(n,-.4),np.full(nu,.001)];upper=np.r_[np.full(n,.4),np.full(nu,7.5)]
    for k,name in enumerate(native.order):
        j=m.joint(name).id
        if m.jnt_limited[j]:lower[k]=max(lower[k],m.jnt_range[j,0]);upper[k]=min(upper[k],m.jnt_range[j,1])
    seed=np.r_[np.zeros(n),np.ones(nu)];nodes=[];records=[]
    for point in [origin,np.asarray(target)]:
        def residual(x):
            d.qpos[native.qi]=x[:n];d.qvel[:]=0;d.ctrl[native.aids]=x[n:];native.forward(d)
            stroke=recipe.bank_stroke_weight*(d.ten_length[native.tids]-lengths)
            return np.r_[(d.qfrc_passive+d.qfrc_actuator-d.qfrc_bias)[native.vi]*1000,
                (d.site_xpos[native.tip]-point)*1500,recipe.bank_tension_weight*x[n:],np.sign(stroke)*abs(stroke)**2]
        sol=least_squares(residual,seed,bounds=(lower,upper),max_nfev=recipe.bank_max_evaluations,ftol=1e-11,xtol=1e-11,gtol=1e-9)
        seed=sol.x.copy();value=residual(seed);nodes.append(seed)
        records.append(dict(target_m=point.tolist(),tip_m=d.site_xpos[native.tip].tolist(),
            static_residual_inf_nm=float(max(abs(value[:n]))/1000),cost=float(sol.cost),nfev=int(sol.nfev),success=bool(sol.success),message=str(sol.message)))
    eq=nodes[-1];d.qpos[native.qi]=eq[:n];d.ctrl[native.aids]=eq[n:];native.forward(d)
    J=np.zeros((3,n));mujoco.mj_jacSite(m,d,J,None,native.tip)
    moment=np.zeros((nu,n));mujoco.mju_sparse2dense(moment,d.actuator_moment,d.moment_rownnz,d.moment_rowadr,d.moment_colind)
    B=-moment.T;M=np.empty((n,n));mujoco.mj_fullM(m,d,M);K=np.zeros((n,n));h=recipe.tangent_step_rad
    def force(q):
        d.qpos[native.qi]=q;native.forward(d);return (d.qfrc_passive+d.qfrc_actuator-d.qfrc_bias)[native.vi].copy()
    for j in range(n):
        delta=np.zeros(n);delta[j]=h;K[:,j]=-(force(eq[:n]+delta)-force(eq[:n]-delta))/(2*h)
    D=np.diag(m.dof_damping);A=np.block([[np.zeros((n,n)),np.eye(n)],[-np.linalg.solve(M,K),-np.linalg.solve(M,D)]])
    U=np.vstack([np.zeros((n,nu)),np.linalg.solve(M,B)])
    aug=np.zeros((2*n+nu,2*n+nu));aug[:2*n,:2*n]=A;aug[:2*n,2*n:]=U;disc=expm(aug*period)
    d.qpos[native.qi]=eq[:n];native.forward(d);T=np.zeros((m.ntendon,n));mujoco.mju_sparse2dense(T,d.ten_J,m.ten_J_rownnz,m.ten_J_rowadr,m.ten_J_colind)
    return dict(nodes=np.asarray(nodes),A=disc[:2*n,:2*n],B=disc[:2*n,2*n:],J=J,T=T[native.tids],records=records,cost=dict(native.cost))


class NativeFeedbackController:
    def __init__(self,parameters,period_s):
        self.control=NativeFeedbackControl.model_validate(parameters);self.parameters=self.control.recipe;self.period_s=period_s

    def configure(self,physics,plan):
        from scipy.linalg import solve_discrete_are
        from .mujoco_analysis import NativeModel
        self.physics=physics;self.plan=plan;started=time.perf_counter();native=NativeModel(plan['configuration']);p=self.parameters
        self.bank=prepare(native,plan['task']['goal']['data']['target_m'],p,self.period_s)
        n=len(native.order);nu=len(native.tendons);b=self.bank
        Q=np.zeros((2*n,2*n));Q[:n,:n]=b['J'].T@b['J']/p.position_scale_m**2+np.eye(n)*p.joint_weight
        Q[n:,n:]=(p.holding_tip_speed_weight+p.terminal_tip_speed_weight)*b['J'].T@b['J']/.02**2+np.eye(n)*p.joint_velocity_weight+p.tendon_velocity_weight*b['T'].T@b['T']/.025**2
        R=np.eye(nu)*p.tension_weight;P=solve_discrete_are(b['A'],b['B'],Q,R)
        self.K=np.linalg.solve(R+b['B'].T@P@b['B'],b['B'].T@P@b['A'])
        self.limits=np.asarray([t['force_limit_n'] for t in physics['tendons']]);self.previous=np.asarray(plan['reference']['u0'],float)
        self.observations=[];self.control_snapshots=[];self.stop_requested=False;self.construction_s=time.perf_counter()-started
        self.native_feedback_preparation=dict(version='native_feedback_preparation_v1',physics_identity=physics['identity'],
            native_model_identity=native.model_identity,coordinate_order=native.order,tendon_order=native.tendons,
            equilibrium_nodes=b['nodes'].tolist(),equilibrium_diagnostics=b['records'],
            A=b['A'].tolist(),B=b['B'].tolist(),Q=Q.tolist(),R=R.tolist(),K=self.K.tolist(),
            position_jacobian=b['J'].tolist(),tendon_jacobian=b['T'].tolist(),native_cost=b['cost'],
            construction_wall_s=self.construction_s,physics_steps=0,
            method='native algebraic least squares; centered full-force tangent; exact linear held-input discretization; scipy.linalg.solve_discrete_are',
            scope='Local feedback construction and numerical residuals. No nonlinear stability or task acceptance claim.')

    def command(self,t,geometry,q,v):
        from .control import execute_ideal_tension
        from .approach_reference import sample
        from types import SimpleNamespace
        started=time.perf_counter();p=self.parameters;n=len(q)
        # The shared smooth approach helper supplies a scalar path fraction.
        a,b=sample([0.],[1.],[float(t)],SimpleNamespace(end_s=p.reach_end_s,ramp_s=p.reference_ramp_s));alpha=float(a[0,0]);rate=float(b[0,0])
        start,end=self.bank['nodes'];qref=(1-alpha)*start[:n]+alpha*end[:n];vref=rate*(end[:n]-start[:n]);uff=(1-alpha)*start[n:]+alpha*end[n:]
        gain=np.clip((t+self.period_s)/p.startup_feedback_s,0,1)
        desired=uff-gain*self.K@np.r_[q-qref,v-vref]
        ramp=np.clip((t+self.period_s)/p.startup_s,0,1);desired=.2+ramp*(desired-.2)
        lower=np.maximum(0,self.previous-p.tension_rate_n_s*self.period_s);upper=np.minimum(self.limits,self.previous+p.tension_rate_n_s*self.period_s)
        # Exact solution of the historical strictly convex, box-only quadratic allocation.
        allocated=np.clip((desired+p.input_change_weight*self.previous)/(1+p.input_change_weight),lower,upper)
        command,bridge=execute_ideal_tension(self.physics,allocated);self.previous=command.copy();elapsed=time.perf_counter()-started
        self.last=dict(**bridge,fresh_solve=False,feedback_enabled=True,feedback_update=True,
            plan_source='native_lqr_bounded_state_feedback',solver_outcome='closed_form_box_allocation',solver_failed=False,
            failure_response_used=False,optimization_nonconverged=False,graph_construction_s=self.construction_s if not self.observations else 0.,
            update_wall_s=elapsed,deadline_missed=elapsed>self.period_s,unbounded_feedback_command_n=desired.tolist(),
            measured_qpos_rad=q.tolist(),measured_qvel_rad_s=v.tolist(),reference_qpos_rad=qref.tolist(),reference_qvel_rad_s=vref.tolist(),
            input_interpolation='linear_control_interval_v1',stop_requested=False)
        self.observations.append(dict(time_s=float(t),phase='interval_start_pre_step',**self.last))
        return command
