"""Frozen five-station guide hardware, derived from the actual rest routing.

Every annular eye and spoke is a real rigid component shared by all backends.
No added collision geometry or replacement of the original frictionless route.
"""
from copy import deepcopy
import numpy as np
from .geometry import geometry


def eye_spoke(p,standard):
    p=np.asarray(p,dtype=float);ri=standard.hole_diameter_m/2;ro=standard.outer_diameter_m/2
    h=standard.thickness_m;sr=standard.spoke_radius_m;rho=standard.density_kg_m3
    if not ri<ro:raise ValueError('GUIDE_INNER_RADIUS_MUST_BE_SMALLER')
    radius=np.linalg.norm(p[1:])
    if radius<=standard.hub_radius_m+ro:raise ValueError('GUIDE_REQUIRES_POSITIVE_RADIAL_SPOKE')
    unit=np.r_[0.,p[1:]/radius]
    start=np.array([p[0],0.,0.])+unit*standard.hub_radius_m;end=p-unit*ro
    length=max(.0005,float(np.linalg.norm(end-start)));center=(start+end)/2
    me=rho*np.pi*(ro*ro-ri*ri)*h;ms=rho*np.pi*sr*sr*length
    ie=np.diag([me*(ri*ri+ro*ro)/2,*([me*(3*(ri*ri+ro*ro)+h*h)/12]*2)])
    parallel=ms*sr*sr/2;perp=ms*(3*sr*sr+length*length)/12
    isp=perp*np.eye(3)+(parallel-perp)*np.outer(unit,unit)
    mass=me+ms;com=(me*p+ms*center)/mass;inertia=np.zeros((3,3))
    for m,c,i in ((me,p,ie),(ms,center,isp)):
        delta=c-com;inertia+=i+m*(delta@delta*np.eye(3)-np.outer(delta,delta))
    return dict(mass_kg=float(mass),com_local_m=com.tolist(),inertia_com_local_kg_m2=inertia.tolist(),
        envelope_halfsize_m=(np.maximum(abs(p),np.maximum(abs(start),abs(end)))+max(ro,h)).tolist(),
        eye_spoke=dict(eye_center_m=p.tolist(),spoke_start_m=start.tolist(),spoke_end_m=end.tolist(),
            inner_radius_m=ri,outer_radius_m=ro,thickness_m=h,spoke_radius_m=sr),collision_geometry=False)


def add_guides(design,physics,standard):
    d=deepcopy(design);parts=physics['parts'];g=geometry(physics,np.zeros(len(physics['dofs'])))
    flex=[c for c in d['components'] if c['kind']=='flexible_segment']
    routes=physics['tendons']
    if len(flex)!=2 or len(routes)!=4 or [len(t['points']) for t in routes]!=[3,3,5,5]:
        raise ValueError('GUIDE_STANDARD_REQUIRES_TWO_SEGMENTS_FOUR_BASE_TENDONS_AND_MIDPOINT_ROUTES')
    groups=[('base',[(i,0) for i in range(4)]),('segment0_mid',[(i,1) for i in range(4)]),
        ('junction',[(i,2) for i in range(2)]+[(i,2) for i in (2,3)]),
        ('segment1_mid',[(i,3) for i in (2,3)]),('segment1_end',[(i,4) for i in (2,3)])]
    # Short tendons terminate on the segment end; long ones pass through guide_1.
    # Both eye sets belong to guide_1 at the junction, as in the frozen hardware.
    for name,indices in groups:
        body=(-1 if name=='base' else next(i for i,p in enumerate(parts) if p['entity']=='guide_1')
            if name=='junction' else routes[indices[0][0]]['points'][indices[0][1]]['body'])
        b=dict(R=np.eye(3),p=np.zeros(3)) if body<0 else g['bodies'][body]
        centers={i:b['R'].T@(g['routes'][i][j]-b['p']) for i,j in indices}
        xp=float(np.mean([v[0] for v in centers.values()]));radius=float(np.mean([np.linalg.norm(v[1:]) for v in centers.values()]))
        for i in range(4):
            if i not in centers:
                direction=g['routes'][i][0][1:];direction=direction/np.linalg.norm(direction)
                centers[i]=np.array([xp,0.,0.])+b['R'].T@np.r_[0.,direction*radius]
        if body<0:connection=dict(part='fixed_base')
        elif not parts[body]['dofs']:connection=dict(part=parts[body]['component'])
        else:
            part=parts[body];cells=[p for p in parts if p['component']==part['component']]
            cell=next(i for i,p in enumerate(cells) if p['entity']==part['entity']);phi=part['section_axis_rad']
            connection=dict(part=part['component'],s=cell/len(cells),quaternion_wxyz=[float(np.cos(phi/2)),float(np.sin(phi/2)),0.,0.])
        for i,p in centers.items():
            d['components'].append(dict(id=f'guide_eye_{name}_{i}',kind='guide',connection=deepcopy(connection),**eye_spoke(p,standard)))
    guide=next(c for c in d['components'] if c['id']=='guide_1')
    guide.update(visual_halfsize_m=[.002,standard.hub_radius_m,standard.hub_radius_m],collision_geometry=False)
    return d
