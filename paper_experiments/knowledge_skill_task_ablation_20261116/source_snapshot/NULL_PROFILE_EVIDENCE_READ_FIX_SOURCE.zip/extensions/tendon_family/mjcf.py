"""Named bodies, full COM tensors, explicit tendon sites and tendon actuators."""
import xml.etree.ElementTree as ET
import os
import threading
from concurrent.futures import Future
import numpy as np
from scipy.spatial.transform import Rotation
from .compiler import rx


# Windows' main-thread stack can overflow inside MuJoCo's recursive XML compiler
# for a legal 216-DoF chain. Only compilation moves threads; physics is unchanged.
MODEL_LOADER = 'mujoco_xml_loader_v1/' + ('windows_8MiB_compile_thread' if os.name=='nt' else 'calling_thread')
_compile_stack_lock = threading.Lock()


def load_model(*, xml=None, path=None):
    import mujoco
    if (xml is None)==(path is None):raise ValueError('EXACTLY_ONE_MUJOCO_XML_SOURCE_REQUIRED')
    def compile_model():
        return mujoco.MjModel.from_xml_string(xml) if xml is not None else mujoco.MjModel.from_xml_path(str(path))
    if os.name!='nt':return compile_model()
    result=Future()
    def run():
        try:result.set_result(compile_model())
        except BaseException as exc:result.set_exception(exc)
    with _compile_stack_lock:
        previous=threading.stack_size(8*1024*1024)
        try:
            worker=threading.Thread(target=run,name='mujoco-xml-compile')
            worker.start()
        finally:threading.stack_size(previous)
    worker.join()
    return result.result()


def fmt(x):
    return ' '.join(format(float(v),'.17g') for v in np.asarray(x).ravel())


def quaternion(R):
    x,y,z,w = Rotation.from_matrix(R).as_quat()
    return fmt([w,x,y,z])


def compile_xml(physics, scene, config, path):
    p=physics
    root=ET.Element('mujoco',model='serial_tendon_family')
    ET.SubElement(root,'compiler',angle='radian',autolimits='true')
    integrator=getattr(config,'integrator','implicitfast') if config is not None else 'implicitfast'
    friction=getattr(config,'friction',(0.,0.,0.)) if config is not None else (0.,0.,0.)
    ET.SubElement(root,'option',timestep=str(scene['timestep_s']),gravity=fmt(scene['gravity']),integrator=integrator)
    default=ET.SubElement(root,'default')
    ET.SubElement(default,'joint',limited='false')
    # Explicit opt-in: condim=3 with zero coefficients is NOT frictionless in
    # MuJoCo (minimum friction and pyramidal rows remain). Retain legacy XML.
    contact = {'condim':'1'} if getattr(config,'contact_model',None)=='mujoco_frictionless_normal_v1' else {}
    ET.SubElement(default,'geom',contype='1',conaffinity='2',friction=fmt(friction),**contact)
    assets=ET.SubElement(root,'asset'); world=ET.SubElement(root,'worldbody')
    ET.SubElement(world,'light',pos='0 -0.3 1',dir='0 0 -1')
    ET.SubElement(world,'geom',name=scene['floor_id'],type='plane',pos=fmt([0,0,scene['floor_z_m']]),size='1 1 .01',contype='2',conaffinity='1',rgba='.6 .6 .6 1')
    if scene.get('target_world_m') is not None:ET.SubElement(world,'site',name='task_target',pos=fmt(scene['target_world_m']),size='.004',rgba='1 0 0 1')
    base=ET.SubElement(world,'body',name='fixed_base',pos=fmt(scene['mount_position']),quat=quaternion(scene['mount_rotation']))
    bodies=[]
    for i,part in enumerate(p['parts']):
        parent=base if part['parent']<0 else bodies[part['parent']]
        body=ET.SubElement(parent,'body',name=part['entity'],pos=fmt(part['position_m']),quat=quaternion(part['rotation']))
        bodies.append(body)
        I=np.array(part['inertia_com_local_kg_m2'])
        ET.SubElement(body,'inertial',pos=fmt(part['com_local_m']),mass=str(part['mass_kg']),fullinertia=fmt([I[0,0],I[1,1],I[2,2],I[0,1],I[0,2],I[1,2]]))
        for j,k in enumerate(part['dofs']):
            ET.SubElement(body,'joint',name=p['dofs'][k],type='hinge',axis='0 1 0' if j==0 else '0 0 1',
                stiffness=str(part['stiffness_nm_rad'][j]),damping=str(part['damping_nm_s_rad'][j]),springref=str(part['natural_rad'][j]))
        prop=part['section_properties']
        if prop:
            vertices,faces=[],[]
            for ring in [prop['outer_yz_m'],*prop['holes_yz_m']]:
                ring=np.array(ring)@rx(-part['section_axis_rad'])[1:,1:].T
                offset=len(vertices); m=len(ring)
                vertices.extend(np.c_[np.zeros(m),ring].tolist()); vertices.extend(np.c_[np.full(m,part['length_m']),ring].tolist())
                for j in range(m):
                    a,b=offset+j,offset+(j+1)%m
                    faces.extend([[a,b,b+m],[a,b+m,a+m]])
            # Open-ended section wall mesh preserves all contours in rendering.
            # MuJoCo convexifies this same mesh for collision (explicitly recorded).
            mesh=part['entity']+'_section'
            ET.SubElement(assets,'mesh',name=mesh,vertex=fmt(vertices),face=' '.join(str(x) for face in faces for x in face))
            ET.SubElement(body,'geom',name=part['entity']+'_shape',type='mesh',mesh=mesh,rgba='.25 .55 .8 1')
        elif part.get('eye_spoke'):
            shape=part['eye_spoke'];vertices=[];faces=[];count=32
            for x in (-shape['thickness_m']/2,shape['thickness_m']/2):
                for r in (shape['inner_radius_m'],shape['outer_radius_m']):
                    vertices.extend([[x,r*np.cos(2*np.pi*k/count),r*np.sin(2*np.pi*k/count)] for k in range(count)])
            for a,b in ((0,count),(2*count,3*count),(0,2*count),(count,3*count)):
                for k in range(count):
                    j=(k+1)%count;faces.extend([[a+k,a+j,b+j],[a+k,b+j,b+k]])
            mesh=part['entity']+'_annulus'
            ET.SubElement(assets,'mesh',name=mesh,vertex=fmt(vertices),face=' '.join(str(v) for f in faces for v in f))
            ET.SubElement(body,'geom',name=part['entity']+'_eye',type='mesh',mesh=mesh,pos=fmt(shape['eye_center_m']),density='0',contype='0',conaffinity='0',rgba='.7 .55 .25 1')
            ET.SubElement(body,'geom',name=part['entity']+'_spoke',type='cylinder',fromto=fmt([shape['spoke_start_m'],shape['spoke_end_m']]),size=str(shape['spoke_radius_m']),density='0',contype='0',conaffinity='0',rgba='.7 .55 .25 1')
            ET.SubElement(body,'site',name=part['entity']+'_hole_center',pos=fmt(shape['eye_center_m']),size=str(shape['inner_radius_m']))
        else:
            collision={} if part.get('collision_geometry',True) else dict(contype='0',conaffinity='0')
            ET.SubElement(body,'geom',name=part['entity']+'_shape',type='box',size=fmt(part.get('visual_halfsize_m',part['envelope_halfsize_m'])),rgba='.7 .55 .25 1',**collision)
    tip=p['tip']; parent=base if tip['body']<0 else bodies[tip['body']]
    ET.SubElement(parent,'site',name='tip_site',pos=fmt(tip['position_m']),size='.002',rgba='0 1 0 1',
        **({'quat':quaternion(tip['rotation'])} if tip.get('rotation') is not None else {}))
    tendons=ET.SubElement(root,'tendon'); actuators=ET.SubElement(root,'actuator')
    execution_mode=scene['control'].get('tension_execution_mode','actuator_realistic')
    if execution_mode not in ('ideal_tension','actuator_realistic','passive_fixed_payout_v1'):
        raise ValueError('UNSUPPORTED_TENDON_FORCE_MODEL')
    payout=p.get('fixed_payout_lengths_m')
    if (payout is not None)!=(execution_mode=='passive_fixed_payout_v1'):
        raise ValueError('COMPILED_DESIGN_AND_SCENE_FORCE_MODE_MISMATCH')
    for t in p['tendons']:
        route=ET.SubElement(tendons,'spatial',name=t['entity'],width=str(t['diameter_m']/2),rgba='.8 .15 .15 1')
        for j,point in enumerate(t['points']):
            parent=base if point['body']<0 else bodies[point['body']]
            name=f"{t['entity']}_point_{j}"
            ET.SubElement(parent,'site',name=name,pos=fmt(point['position_m']),size=str(t['diameter_m']/2),rgba='.8 .15 .15 1')
            ET.SubElement(route,'site',site=name)
        if execution_mode=='passive_fixed_payout_v1':
            route.set('limited','true');route.set('range',fmt([0.,payout[t['entity']]]))
            route.set('solreflimit','.002 1');route.set('solimplimit','.99 .999 .0001')
            for name in ('solreflimit','solimplimit'):
                if name in scene['control']:route.set(name,fmt(scene['control'][name]))
        elif execution_mode=='ideal_tension':
            # Positive controller tension maps to MuJoCo's negative tendon force.
            ET.SubElement(actuators,'general',name=t['entity']+'_direct_tension',tendon=t['entity'],
                gainprm='-1',ctrllimited='true',ctrlrange=fmt([0,t['force_limit_n']]),
                forcelimited='true',forcerange=fmt([-t['force_limit_n'],0]))
        else:
            # These are tendon force elements, not independent motor descriptions.
            # The shared actuator matrix is applied once per control interval.
            ET.SubElement(actuators,'general',name=t['entity']+'_length_servo',tendon=t['entity'],
                gainprm=str(t['kp_n_m']),biastype='affine',biasprm=fmt([0,-t['kp_n_m'],0]),
                forcelimited='true',forcerange=fmt([-t['force_limit_n'],0]))
    extension=scene.get('assembly',{}).get('physical_environment')
    if extension:
        from .environment import emit
        emit(root,extension)
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
    return path
def parameter_effect_semantics(path, execution_mode, *, input_source='operation_selected_input'):
    """Describe this emitter's force law; this does not grant method admission."""
    key=path.rsplit('.',1)[-1]
    effects=(['geometry','mass','backbone_stiffness'] if '.sections.' in path or key=='length_m' else
        ['backbone_stiffness'] if key=='young_pa' else ['mass'] if key=='density_kg_m3' else
        ['backbone_damping'] if key.startswith('viscosity_') else
        ['rest_geometry','passive_force'] if key.startswith('curvature_') else
        ['section_geometry','backbone_stiffness'] if key=='section_angle_rad' else
        ['numerical_discretization'] if key=='cells' else
        ['constraint_activation'] if path.startswith(('payout_lengths_m.','payout_offsets_m.')) else
        ['routing_geometry','drive_mapping'] if path.startswith(('spans.','route_overrides.','guide_hole_positions_m.')) else
        ['topology','geometry','mass','drive_mapping'] if key in ('segment_count','tendon_count','spans') else [])
    result=dict(version='execution_parameter_effect_v1',execution_mode=execution_mode,
        parameter_id=path,effect_channels=effects,input_source=input_source,
        scope='Current compiler/emitter and selected input only; other actuator models require their own semantics.',
        source_functions=['extensions/tendon_family/compiler.py:resolve','extensions/tendon_family/mjcf.py:compile_xml'])
    if key=='diameter_m':
        result.update(effect_channels=['visual_geometry','clearance_legality'],
            motion_effect_at_fixed_legal_geometry=False,
            excluded_effects=['tendon_elastic_stiffness','tendon_mass','tendon_friction'],
            explanation='Compiler checks guide-hole clearance; generator also checks section/pairwise clearance. XML width/site size do not change route coordinates or the tendon force law. No tendon elasticity is emitted.')
    elif key=='pretension_n':
        result.update(effect_channels=['default_input','legality'],
            overridden_by=['native.tensions_n','saved_state.u','complete absolute-tension schedule'],
            fixed_absolute_input_effect=False,
            explanation='Used when preparing default input, not added to an explicit absolute input. Fixed-input comparison holds state and absolute input fixed; changing a default alone cannot change that response. Reinitializing controls may change inputs and is a different experiment.')
    elif key=='force_limit_n':
        result.update(effect_channels=['input_bounds','legality'],
            explanation='Changes saturation and admissible input set; not a fixed-input stiffness parameter.')
    elif key=='length_servo_gain_n_m':
        result.update(effect_channels=['drive'] if execution_mode=='actuator_realistic' else [],
            motion_effect_at_fixed_legal_geometry=execution_mode=='actuator_realistic',
            explanation='Affine length-servo gain in actuator_realistic; bypassed by ideal_tension and passive payout constraints.')
    if execution_mode!='ideal_tension':
        result.pop('fixed_absolute_input_effect',None)
        if key=='pretension_n':
            result.pop('overridden_by',None)
            result['explanation']='Default pretension is consumed by actuator/controller preparation; determine the actual selected input binding before making a response claim.'
        # No universal prohibition inferred from the Native ideal-tension model.
        result['identification']='Check selected actuator/controller input binding and operating point; Native ideal-tension conclusions do not establish this mode response.'
    else:result['identification']='Native methods use absolute nonnegative tensions in N, with force=-tension. Instantaneous derivatives identify local effects only; fixed-input response is not reoptimized task capability.'
    return result
