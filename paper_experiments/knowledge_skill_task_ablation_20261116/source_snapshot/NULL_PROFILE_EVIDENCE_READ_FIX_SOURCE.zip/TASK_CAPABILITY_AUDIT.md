# Original Core capability audit

This audit distinguishes the frozen baseline from the new interfaces. It traces execution, rather than matching function names. The baseline and branch inventories are in `BASELINE_AUDIT.json`; statuses below describe commit `2c83f8b7bd654328dd7648f844295c54a7c15223` before edits.

## Workspace and source identity

The original Core checkout was clean on main at the required base. Work proceeds in the isolated branch `codex/ten-task-core-interfaces-20261112`; main was not edited/reset. Baseline Registry: 38 declarations. The original Showcase checkout was clean at `d6a1d49ed7301e48df9ae8a601d3d7c39e64f4fa`, and did not contain the requested reference objects. The exact reference and protected C009 commit were fetched into a separate reference clone. The original Showcase was not checked out, edited or used as a Store.

The C009 result bytes at both `bd4fe89f13b286f127f1fc336a860318be109119` and the frozen reference have SHA-256 `9928d7f71233ee931005bfe1f8b4cc5d34cdf61fd315d91b217e65686f5c7c0f`.

## Actual baseline execution paths

- Definition: `TaskDefinition -> Registry.parse/bind -> platform_tasks.check_definition -> task family validator`. Goal, environment, initializer, clocks and evaluator are frozen in the SessionInput.
- Active generation/control: `FamilySpaceV2 -> generated_serial.generate_family/authorize -> compiler.resolve -> scene.assemble -> registered controller preparation -> backend -> signals`. Full COM tensors and independent tendon transmissions already exist.
- Mathematical research: the Main `research_analysis` interface reaches `analysis.dispatch`, original method authorization/admission and the existing Worker. Model/solver declarations are registered, but a general candidate-bound Platform Registry tool was missing. The new `research.math` delegates to this same dispatcher.
- Physical evidence: `Host.invoke -> reservation -> simulation/evaluation -> immutable Store`. Native orientation uses explicit sequence optimization and `physical_replay`, not position-only NMPC.
- Passive research: `task.passive_response -> no_active_control -> PassiveBackend -> staged passive evidence -> passive_evaluation_v2`. Existing KKT, tangents, compliance and sensitivities are conditional mathematical evidence, not dynamic acceptance.
- Reporting: saved results flow through result cards and Reporter; trace/cost records existed, but original public requests, source schemas and raw usage were not uniformly exported for replay.

## Per-task, eight-level original matrix

Columns: specification / adapter / generation / math Registry entry / backend / evaluator / Main-Reporter / Store-trace-cost.

| Task | Original statuses |
|---|---|
| T01 | AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL |
| T02 | AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL |
| T03 | AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL |
| T04 | MISSING / MISSING / AVAILABLE / PARTIAL / PARTIAL / PARTIAL / PARTIAL / PARTIAL |
| T05 | AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL |
| T06 | AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL |
| T07 | PARTIAL / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / PARTIAL / PARTIAL |
| T08 | AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL / AVAILABLE / AVAILABLE / AVAILABLE / PARTIAL |
| T09 | MISSING / MISSING / PARTIAL / PARTIAL / MISSING / MISSING / MISSING / PARTIAL |
| T10 | PARTIAL / PARTIAL / AVAILABLE / PARTIAL / PARTIAL / MISSING / PARTIAL / PARTIAL |

### T01 M1_reach_hold

Original targets, named zero state, 0.54–0.60 s formal 20 ms hold samples, 10 mm position and 30 mm/s speed are retained per condition. Endpoint evaluation is composed with holding evidence.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T02 M2_loaded_hold

Original three signed/zero COM-force conditions, 0.10–0.35 s force interval, payload inertia, 0.30–0.35 s hold, 10 mm and 20 mm/s bounds retained. Reduced predictor omits injected forces; physical execution applies them.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T03 M3_fast_reach

Original 0.50 s horizon, 0.45–0.50 s formal hold, initial state, 10 mm and 20 mm/s bounds retained. No generic Reach replacement.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T04 Figure-eight Tracking

Exact integrated quintic speed ramps give two cycles in 22 s at world mount z=0.17 m. Prepared initial q/u require registered static qualification at <=1e-7 N.m balance; no historical preload is installed. Actual lobes, drift, strict source bounds and complete physical grid are checked.

Original gap: safe figure-eight reference/phase semantics, complete tracking constraints and prepared initialization were not exposed.

### T05 M5_tool_axis

Position plus directed tip-local axis; original 0.58 and 0.60 s samples, 8 mm and 3 degrees. Existing native sequence optimization/Replay is supported; pose NMPC is not implemented or advertised as equivalent.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T06 M6_loaded_scan

Frozen 20 g rigid tool, off-diagonal inertia and COM are checked against actual design/compiled load. Original timed scan position and normalized axis reference, 12 mm and 10 degree bounds retained. Native sequence/Replay route remains required.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T07 C1 Four-tendon Multi-task

Exactly four independent tendon/actuator maps and one shared design. M1_A/B/C and M5 retain distinct goals, grids and velocity requirements. Aggregation never replaces per-subtask evaluation.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T08 P3 Progressive Stiffness

Existing passive v2 program, fixed payout, no active channels, common unloaded equilibrium, both directions, stage qualification, KKT/tangent methods and independent evaluator reused. Original development_not_registered_SELECT status retained. Legacy 1,600,000-row evidence recovered; original evaluator and current stiffness metrics agree, while legacy v2 complete-state/binding equivalence remains partial.

Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.

### T09 Spring Button Press v1.2

Source parent task/environment/evaluation files govern v1.2. Native slide, true normal contact, spring/damper, housing/probe geometry, full rigid inertia and passive rebound are expressed in the shared backend. Existing GVS position NMPC is available; contact-aware NativeModel mathematics remains unsupported, with explicit admission rejection.

Original gap: one-floor assembly could not express the button slide, moving body, native pair force or environment state. NativeModel rejects the extra state/contact, and remains mathematically scoped accordingly.

### T10 M7 External Impact Recovery

Original M2 design/discretization fingerprint is frozen. World +/-Y half-sine 0.50–0.55 s at payload COM, 0.5 ms physics and 10 ms control. Full controller views are identical across cases, including blind labels/provenance; reference clock stops after approach. Frozen-input controls are executor-owned and excluded from active-pass aggregation.

Original gap: only constant control-grid COM loads, with no half-sine environment schedule, blind observation view, recovery evaluator or frozen-input condition.

## Related branch review

| Branch | Review outcome |
|---|---|
| codex/m1-ablation-gates-20261111 | Method-level authorization and temporal resolution/knot grants reviewed. Experimental ablation gates and quota addenda were not imported; existing authorization remains authoritative. |
| codex/p3-ablation-gates-20261112 | Passive mathematical/research gates reviewed. No ablation configuration, experimental state or altered method set imported. |
| codex/p3-account3-resume-fix-20261112 | Account/gateway/resume changes excluded as unrelated. No credentials, sessions or quota recovery copied. |
| codex/p3-intent-projection-revision-20261112 | Main intent projection/knowledge restoration reviewed. No historical knowledge store or experiment artifacts imported. |
| codex/p3-structured-direct-math-20261112 | Candidate-bound Direct Math and shared model-evaluator extraction reviewed. The existing baseline methods suffice for this interface work; no algorithm or branch-wide merge was needed. |

Only a source-verified P3 task-data translation is reused from the local prior task definitions. Its `protocol_source` must equal the canonical hash of frozen Showcase P3/task.json before the importer accepts it. No historical candidate/Store or task-specific solver is copied.

See `TASK_CAPABILITY_MATRIX.json` for before/after status and concrete module references for each of the eight levels. Missing P3 regression evidence is represented separately from available evaluator code. No capability is inferred from historical success alone.
