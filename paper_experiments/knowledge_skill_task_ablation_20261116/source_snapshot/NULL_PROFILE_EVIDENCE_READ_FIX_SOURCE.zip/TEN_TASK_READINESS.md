# Ten-task Core research readiness

Date: 2026-11-12 (Asia/Shanghai). Base: `2c83f8b7bd654328dd7648f844295c54a7c15223`. Implementation version: 0.2.2.

**9/10 interfaces meet the full offline readiness gates. The overall ten-task acceptance is not complete.**

| Task | Name | Core research status | Historical offline regression |
|---|---|---|---|
| T01 | M1_reach_hold | CORE_RESEARCH_READY | PASS |
| T02 | M2_loaded_hold | CORE_RESEARCH_READY | PASS |
| T03 | M3_fast_reach | CORE_RESEARCH_READY | PASS |
| T04 | Figure-eight Tracking | CORE_RESEARCH_READY | PASS |
| T05 | M5_tool_axis | CORE_RESEARCH_READY | PASS |
| T06 | M6_loaded_scan | CORE_RESEARCH_READY | PASS |
| T07 | C1 Four-tendon Multi-task | CORE_RESEARCH_READY | PASS |
| T08 | P3 Progressive Stiffness | NOT_CORE_RESEARCH_READY | PARTIAL: source gap |
| T09 | Spring Button Press v1.2 | CORE_RESEARCH_READY | PASS |
| T10 | M7 External Impact Recovery | CORE_RESEARCH_READY | PASS |

All ten tasks have registered research entrypoints and validated frozen definitions. T08 retains `development_not_registered_SELECT`. Its legacy Store and 1,600,000 rows were recovered and hash-verified; original evaluator and current stiffness-metric regressions agree. The legacy layout lacks the versioned complete integration-state/current binding proofs required by the current v2 full-evidence inspector. Strict readiness therefore remains unresolved; those fields were not fabricated. See `T08_HISTORICAL_EVIDENCE_RECOVERY.md`.

`CORE_RESEARCH_READY` means an interface can support future authorized research through existing tools; it does not predict that any controller or design will pass. `HISTORICAL_RESULT_PASS` refers only to the archived required-case results. `NEW_STUDY_PASS` was never produced in this phase; every new-Study status is `NOT_RUN`.

All active cases use the same Core architecture. T05/T06 use the existing native sequence/physical Replay route for axis objectives. T09 uses existing GVS position control with native contact physics and an independent contact evaluator; native contact-aware trajectory mathematics is explicitly rejected. T10 requires a shared blind controller as well as a shared design; its frozen-input controls do not enter active success aggregation.

See `TEN_TASK_READINESS.json` for all eleven gates per task and `TEST_RESULTS.json` for actual test records. No Main, Provider, optimization, candidate search or trajectory integration was run.
