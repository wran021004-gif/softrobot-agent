# T08 historical evidence recovery

Both original Store SHA-256 values match the user-supplied digests. The original task file SHA-256 is 3f88a70e4461a384969d2173ae7c5da68379556344fd89df3fed7a7e993b064d. Its parsed content equals the frozen Showcase task and Core T08_SOURCE. Original family identity is 823432cb8ef0f1324e6b497e0dcb101dfcd8ee886a2e57f63c7e18d3d449fc92.

The registered evidence.passive_history.audit recovered an index of all eight source CSVs, read all 1,600,000 physical-step rows, verified hashes, grids, stage/force timing and original full-step route certificates, reran the exact hash-pinned original evaluator and compared the current Core v2 stiffness extractor. All source files remain unchanged. This audit performed zero integrations, optimizer calls and Provider sends.

Original evaluator regression and current stiffness-metric regression are COMPLETE. Current v2 full evidence regression remains PARTIAL: the legacy layout has no complete versioned mjSTATE_INTEGRATION boundary snapshots/current binding proofs. Those fields were not invented or relabeled as new Core execution. Historical source status remains development_not_registered_SELECT; NEW_STUDY_RESULT is NOT_RUN.

The original Store and frozen delivery directory remain the read-only authorities. T08_HISTORICAL_RECOVERY.json contains every CSV SHA-256, original Store artifact reference and original physical implementation commit. HISTORICAL_RECOVERY_STORE contains the exact request, failure, corrected retry and actual budget receipts. An initial audit call failed on an attempted mutation of a frozen Timing model; it consumed one operation and no science budget. The corrected call completed.

For new Core executions, the existing per-step CSV now additionally records the actual loaded material-point position/velocity/displacement, full constraint-row arrays/classifications, route-check state and solver warm state at every completed step. Existing stage qualification, source bindings and complete boundary states remain authoritative. No controller or optimizer was added.
