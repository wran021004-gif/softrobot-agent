# Evaluator regression report

Frozen reference: `2e5d1088746df0916e2a7ec60f4780998c6ba004`. Actual outcome: **20 PASS, 0 FAIL, 1 PARTIAL**. These are read-only regressions, not new physical solutions.

| Task | Condition | Regression | Archived outcome |
|---|---|---|---|
| T01 | central_high | PASS | HISTORICAL_RESULT_PASS |
| T01 | negative_low | PASS | HISTORICAL_RESULT_PASS |
| T01 | positive_high | PASS | HISTORICAL_RESULT_PASS |
| T02 | negative | PASS | HISTORICAL_RESULT_PASS |
| T02 | positive | PASS | HISTORICAL_RESULT_PASS |
| T02 | zero | PASS | HISTORICAL_RESULT_PASS |
| T03 | default | PASS | HISTORICAL_RESULT_PASS |
| T04 | default | PASS | HISTORICAL_RESULT_PASS |
| T05 | default | PASS | HISTORICAL_RESULT_PASS |
| T06 | default | PASS | HISTORICAL_RESULT_PASS |
| T07 | M1_A | PASS | HISTORICAL_RESULT_PASS |
| T07 | M1_B | PASS | HISTORICAL_RESULT_PASS |
| T07 | M1_C | PASS | HISTORICAL_RESULT_PASS |
| T07 | M5 | PASS | HISTORICAL_RESULT_PASS |
| T08 | both_directions | PARTIAL | HISTORICAL_RESULT_PASS |
| T09 | default | PASS | HISTORICAL_RESULT_PASS |
| T10 | positive_y | PASS | HISTORICAL_RESULT_PASS |
| T10 | negative_y | PASS | HISTORICAL_RESULT_PASS |
| T10 | no_impulse | PASS | HISTORICAL_RESULT_PASS |
| T10 | positive_y_frozen | PASS | HISTORICAL_RESULT_FAIL |
| T10 | negative_y_frozen | PASS | HISTORICAL_RESULT_FAIL |

Position/axis/hold metrics are recomputed from saved full-step CSVs, with exact original formal sample selection. Figure-eight phase is checked against the original source function; drift uses the original monotone phase interpolation, and tendon speed uses the original gradient definition for this historical evaluator. Spring Button and M7 additionally run their original evaluator functions as offline test oracles. Source strict/inclusive comparisons and tolerances are retained, including strict button release force and the original strict figure-eight inequalities. Invalid/missing/nonfinite data is never scored as success.

Source limitations: M1–M6/C1 saved solver-error counts are original aggregate metadata, not reconstructed per-step warning observations. Figure-eight NPZ lacks per-step contacts/warnings; its original recorded aggregate maxima are explicitly labeled as regression metadata. P3 legacy Store recovery verified eight cases and 1,600,000 CSV rows, original evaluator results and current Core stiffness metrics; current v2 complete-state/binding proofs remain a distinct format gap. Its original PASS is retained; full v2 evidence equivalence is not asserted. No synthetic trajectory fills these gaps.

All per-metric comparisons, source hashes, margins and failed checks are in `EVALUATOR_REGRESSION_RESULTS.json`. The original Showcase is unchanged; C009 result hash remains `9928d7f71233ee931005bfe1f8b4cc5d34cdf61fd315d91b217e65686f5c7c0f`. Provider sends, optimizations and integrated physics steps for this regression: 0.
