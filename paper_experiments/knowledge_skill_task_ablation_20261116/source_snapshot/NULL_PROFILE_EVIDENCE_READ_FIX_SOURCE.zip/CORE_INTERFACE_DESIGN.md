# Core interface design

Version 0.2.0 extends the existing Core architecture. There is one Main, Reporter, Registry, Host, Store and research dispatcher. The new package contains protocol adapters, evaluators and environment composition; it contains no optimizer or control algorithm.

## Data flow

```text
TASK_PROTOCOLS/Txx.json -> task.protocol.inspect/bind
 -> existing frozen Study configuration / ResearchTaskAdapter
 -> research.dispatch / research.math -> original admission and Workers
 -> FamilySpace / Compiler -> existing controller or native sequence
 -> shared MuJoCo backend + environment adapter
 -> dense typed task observations -> frozen protocol evaluator
 -> immutable Store -> ResultCard / Reporter -> Main
 -> Store-derived MAIN_REPLAY_INPUT.json
```

`TaskProtocol` freezes source commit, file hashes, condition roles, original TaskDefinitions, independent channel counts, physical environment and acceptance definitions. `TaskDefinition.acceptance` is additive and omitted when absent. Original task families and their base goal/evaluator contracts remain intact. The complete evaluator is composed at the existing `evaluation.run` and physical Replay boundaries, and the existing acceptance/SELECT machinery receives its result.

`tools/research/protocol_adapter.py` extends the existing family adapters with the frozen acceptance and evidence requirements. It preserves the original reference and mathematical-method interfaces. `task.protocol.bind` validates a supplied owned configuration; it does not choose a structure or controller. With an explicit owned candidate, it creates a source-bound candidate variant using the existing Store/candidate verification mechanism. The frozen Main task cannot be changed by this operation.

## Registry and Main

New public tools are `task.protocol.inspect`, `task.protocol.bind`, `task.protocol.evaluate`, `task.protocol.aggregate`, `task.initial_state.qualify`, `reference.generate`, `trace.decision`, `trace.replay_export`, `research.math` and `research.dispatch`. Shared contracts include `task.protocol`, `task.observations` and `reference.parametric_tracking_goal`; `evaluate.task_protocol` is a registered evaluator. Backend `backend.family_mujoco@1.5.0` extends the existing backend lifecycle.

`research.math` delegates to `tools.research.analysis.dispatch` with the original guard. `research.dispatch` delegates to the original Plan dispatcher. Candidate ownership, applicable models, selected methods, original mathematical/physical budgets, Workers, failure handling and independent evaluation remain in those implementations. No numerical computation is routed around the Registry by these adapters.

The existing Study resolver accepts an explicit `registry_tools` map. For example, a later authorized Study may include:

```json
{
  "registry_tools": {
    "task.protocol.inspect": "1.0.0",
    "task.protocol.bind": "1.0.0",
    "task.protocol.evaluate": "1.0.0",
    "task.protocol.aggregate": "1.0.0",
    "task.initial_state.qualify": "1.0.0",
    "reference.generate": "1.0.0",
    "research.math": "1.0.0",
    "trace.decision": "1.0.0",
    "trace.replay_export": "1.0.0"
  }
}
```

This is a tool grant inside an otherwise complete Study specification, not a Study launch or authorization. Main receives the actual registered input schemas through its existing native tool directory and route selection. Reporter receives deterministic result cards with every recorded check, margin, failure and evidence origin. No new Main Agent is created.

## Reference, environment and observation adapters

`ReferenceGenerator` permits constant, quintic-node and figure-eight references only. There are no executable callbacks or import paths in JSON. Figure-eight phase integrates quintic **speed** ramps; it is not a smooth position interpolation of a sampled figure eight. Reference position and analytical velocity preserve phase, 2 s ramps, 22 s time definition and two cycles. Prediction-only endpoint holding is explicit and distinct from scored task duration.

`PhysicalEnvironment` composes native geometry, named dynamic bodies, slide/hinge joints, full COM tensors, spring/damper coefficients, named contact pairs, observation sites, joint/input bounds and world COM wrenches into the existing MJCF emitter. Hinge stiffness/damping use N.m/rad and N.m.s/rad; slide values use N/m and N.s/m. Wrenches use N and N.m in world coordinates, refreshed at integration-step start on a declared physical grid. Half sine, constant, linear and cubic smoothstep waveforms are versioned data.

`TaskEvidence` records the initial state and every completed physical step. It includes named state layout, actual tendon tensions/lengths/analytical speeds, world position/velocity/rotation/tool axis, environment joint state, native pair count/normal force, warning/contact counts, sample-time wrench, preceding applied wrench/COM point and impulse. Every array has explicit units, frame, phase, dimension and source. `mj_contactForce` supplies the normal force; spring/damper reaction is not substituted.

M7 environment schedules, labels, direction identifiers and case-specific provenance are withheld from controller task/numerical views. Controller views are tested identical for positive, negative, no-impulse and frozen-control conditions. The normal reference/cost clock stops after the allowed approach phase; internal control-update scheduling continues at 10 ms. Frozen-input conditions are applied by the executor without further feedback calls. Required cases must share controller identity as well as physical design.

## Initialization and task-specific invariants

- T01/T02/T03 retain original goals, clocks, initial state and formal holding samples; task-owned payload tensors are checked.
- T04 mount z=0.17 m, original 2 g payload, four channels, joint bounds and pointer geometry are frozen as task data. A supplied candidate q/u is checked by `task.initial_state.qualify` using one static `mj_forward` and the source 1e-7 N.m balance threshold. It never searches for equilibrium. A registered, source-bound qualification is required before physical execution; historical q/u is not installed as a default.
- T05/T06 keep directed local-axis semantics and the existing native sequence/physical Replay route. Full orientation NMPC is not implemented. Non-identity tip frame rotations are preserved by the compiler/emitter.
- T07 checks one independent actuator per tendon and evaluates M1_A/M1_B/M1_C/M5 separately on one structure.
- T08 retains fixed payout, zero active actuators, common unloaded equilibrium, both load directions, staged load/unload qualification and source development status. Existing passive mathematics/backend/evaluator are reused.
- T09 uses the parent authoritative task/environment/evaluation files unchanged by v1.2. Probe-center observation, complete 10 g tool inertia, button inertia, native contact geometry, 50 N/m spring, 0.20 N.s/m damping, 3 mm travel and release checks are explicit. Existing GVS position control can be selected; NativeModel contact-aware mathematics is rejected rather than misrepresented.
- T10 rejects any change to the original M2 design/discretization. The original pulse waveform, force application and physical/control grids are frozen. Expected-failing frozen-input controls are reported independently.

## Compatibility

Legacy task/environment/initial-state/zero-minimum-tension serialization retains its previous shape. New optional fields require new immutable dependency identities; existing Studies are not migrated or resumed automatically. A shared lower tension bound extends the existing NMPC transcription variables without changing its solver or algorithm. Runtime data remains outside source control. Installed wheels include the protocol assets under `tools/assets/TASK_PROTOCOLS`.
