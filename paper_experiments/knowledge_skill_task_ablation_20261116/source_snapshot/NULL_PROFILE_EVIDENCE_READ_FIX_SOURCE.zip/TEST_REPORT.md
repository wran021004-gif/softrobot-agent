# Offline test report

Actual final run: **43 tests, 43 passed, 0 failures, 0 errors, 0 skipped**. Complete output, interpreter and dependency versions: `TEST_RESULTS.json`.

CLI validation passed for all 10 frozen protocols and 51 Registry declarations (`CLI_VALIDATION.json`). Local setuptools built `softrobot_agent_core-0.2.2-py3-none-any.whl` with 11 protocol/source assets and no missing required files. The extracted wheel independently passed the same protocol/Registry CLI checks, without installing dependencies or contacting a package index (`PACKAGE_VALIDATION.json`). An earlier pip attempt failed at its Windows temporary-directory ACL before compilation; its actual error is retained in that artifact.

Measured/enforced test counters: `{"native_forward_evaluations": 3, "optimization_calls": 0, "physics_steps": 0, "provider_requests": 0, "worker_launches": 0}`. Static `mj_forward` and XML compilation are model-interface checks, not trajectory validation. Mock Host/Worker calls are labeled in test names and do not certify physical performance.

Coverage includes all ten protocol schemas/Registry families; all existing active case configuration admissions; four independent channels and duplicate-map rejection; fixed M2 structure; reference phase, derivative and endpoint tail; source-directed axis; static full-inertia/button XML; true native contact observation; actual world COM wrench; blind identical M7 controller views and reference clock; frozen input ownership; strict/boundary/missing/nonfinite evaluator behavior; protected historical results; Store evidence and Reporter cards; original Main mathematical delegation; permissions, receipts, exhaustion, idempotency and exact request/schema export; raw role usage/unavailable fields.

Earlier development runs exposed and fixed: a missing `tip_tool_axis` declaration on the unified backend; source-builder mismatch in a test fixture that changed its tool without changing its frozen prototype; an invalid Reach settling configuration used for Tracking; a string-provider usage parsing error; Windows temporary-directory ACL/SQLite cleanup problems; an invalid dictionary literal in the controller provenance view; the strict Study merge rejecting registry_tools; new fixture path/grant-ID/output-envelope assumptions in its formal-entry regression. These failed runs were not reported as passes. Final failures/errors are listed in the JSON (empty when all pass).

Not executed by design: Provider sends, formal Main/Reporter sessions, mathematical/structural/controller optimization, real Workers, candidate searches, independent dynamic verification, `mj_step`, multi-case physical integration and new successful structures. Native contact-aware mathematics and full orientation NMPC remain unsupported; supported task routes use existing controllers/native sequence methods as documented. P3 full historical regression remains a source gap, not a passing test.

Reproduce with the project runtime:

```powershell
$env:SOFTROBOT_AGENT_HOME = '<isolated writable data directory>'
$env:SOFTROBOT_SHOWCASE_REFERENCE = '<read-only checkout at 2e5d108>'
python -m tools.development.run_offline_checks --output TEST_RESULTS.json
python -m tools.development.offline_regression --reference $env:SOFTROBOT_SHOWCASE_REFERENCE --output EVALUATOR_REGRESSION_RESULTS.json
python -m tools.research protocol-validate
```
# 2026-11-13 binding repair regression

`python -m unittest tests.test_ten_task_interfaces -v`: **45 tests passed** in 52.912 s. The integration, optimization, network and real-Worker guards remained enabled. New tests cover exact-protocol parent → frozen-condition aliases, immutable parent proof, changed-task rejection, read-only legacy lookup, and provenance-preserving replacement of the invalid inherited binding.

The only changed runtime source is `tools/research/conditions.py`. Both active Studies have identical scientific source hashes and unchanged scientific Registry dependencies before/after the repair; the affected request had launched no physical or mathematical computation. Prior results and costs are retained, not reset or relabeled as new executions.
