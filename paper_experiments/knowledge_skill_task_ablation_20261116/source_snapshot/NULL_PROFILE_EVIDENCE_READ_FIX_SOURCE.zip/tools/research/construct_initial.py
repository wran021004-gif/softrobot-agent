"""Native constrained equilibrium construction; qualification remains separate."""
import numpy as np
from pydantic import Field,FiniteFloat
from schemas.common import Contract
from schemas.platform import EvidenceRef,Payload
from .prepared_initial import configuration_for_qualification,static_binding


class ConstructInitial(Contract):
    configuration: EvidenceRef
    qpos_seed_rad: dict[str,FiniteFloat] = Field(default_factory=dict)
    tensions_seed_n: dict[str,FiniteFloat] = Field(default_factory=dict)
    max_iterations: int = Field(default=200,ge=1,le=1000)
    reference_times_s: list[FiniteFloat] | None = Field(default=None,min_length=2,max_length=300,description='Optional increasing frozen-reference times, starting at zero. Each point consumes one mathematical evaluation. Returns a warm-started native equilibrium bank and absolute tension knots, without integration or qualification.')
    tension_reference_n: dict[str,FiniteFloat] = Field(default_factory=dict,description='Optional nominal absolute tensions for the existing small regularizer; useful for interior antagonistic preload. Does not change physical bounds.')
    tension_interior_margin_n: FiniteFloat = Field(default=0.,ge=0,description='Optional inward search margin within the unchanged task/native tension box. Use a positive margin when the original evaluator prohibits saturation; no acceptance limit is relaxed.')


def construct(configuration,args):
    import mujoco
    from scipy.optimize import minimize
    from extensions.tendon_family.mujoco_analysis import NativeModel
    from extensions.reference.generators import ParametricTrackingGoal
    cfg=configuration_for_qualification(configuration);native=NativeModel(cfg);m=native.model
    n=len(native.order);nt=len(native.tendons);d=mujoco.MjData(m)
    if set(args.qpos_seed_rad)-set(native.order) or set(args.tensions_seed_n)-set(native.tendons) or set(args.tension_reference_n)-set(native.tendons):
        raise ValueError('UNKNOWN_NAMED_INITIAL_SEED')
    times=reference_times(cfg,args)
    reference=ParametricTrackingGoal.model_validate(cfg['task']['goal']['data'])
    low,high=cfg['task']['acceptance']['parameters']['tension_n']
    qbounds=[]
    for name in native.order:
        jid=m.joint(name).id
        qbounds.append(tuple(m.jnt_range[jid]) if m.jnt_limited[jid] else (-np.pi,np.pi))
    margin=args.tension_interior_margin_n
    input_bounds=[(max(low,float(a))+margin,min(high,float(b))-margin) for a,b in native.limits]
    if any(a>=b for a,b in input_bounds):raise ValueError('EMPTY_INTERIOR_TENSION_SEARCH_BOX')
    bounds=qbounds+input_bounds
    seed=np.r_[[args.qpos_seed_rad.get(j,0.) for j in native.order],
        [args.tensions_seed_n.get(t,low) for t in native.tendons]]
    nominal=np.asarray([args.tension_reference_n.get(t,0.) for t in native.tendons])
    if any(not a<=u<=b for u,(a,b) in zip(nominal,bounds[n:])) and args.tension_reference_n:
        raise ValueError('NOMINAL_TENSION_OUTSIDE_NATIVE_BOUNDS')
    previous=None;cache=None
    def evaluate(x):
        nonlocal previous,cache
        if previous is None or not np.array_equal(previous,x):
            d.qpos[native.qi]=x[:n];d.qvel[:]=0;d.ctrl[native.aids]=x[n:]
            native.forward(d)
            cache=(d.site_xpos[native.tip].copy(),(d.qfrc_passive+d.qfrc_actuator-d.qfrc_bias)[native.vi].copy())
            previous=x.copy()
        return cache
    def objective(x):
        tip,_=evaluate(x)
        return float(np.sum(((tip-target)/.02)**2)+1e-8*np.sum((x[n:]-nominal)**2))
    points=[]
    for time_s in times:
        target=np.asarray(reference.at_time(time_s)[0])
        solution=minimize(objective,seed,method='SLSQP',bounds=bounds,
            constraints=[dict(type='eq',fun=lambda x:evaluate(x)[1]/.01)],
            options=dict(maxiter=args.max_iterations,ftol=1e-13))
        tip,residual=evaluate(solution.x);seed=solution.x.copy()
        points.append(dict(optimizer_success=bool(solution.success),optimizer_message=str(solution.message),iterations=int(solution.nit),
            reference_time_s=float(time_s),target_position_m=target.tolist(),tip_position_m=tip.tolist(),
            position_error_m=float(np.linalg.norm(tip-target)),static_balance_inf_nm=float(np.max(abs(residual))),
            qpos_rad=dict(zip(native.order,solution.x[:n].tolist())),qvel_rad_s=dict.fromkeys(native.order,0.),
            tensions_n=dict(zip(native.tendons,solution.x[n:].tolist()))))
    result=dict(version='native_equilibrium_construction_v1',optimizer='scipy.SLSQP',**points[0],
        static_binding=static_binding(cfg),physics_identity=native.physics['identity'],cost=native.cost,
        optimization_calls=len(points),physics_steps=0,qualified=False,
        construction_tension_bounds_n=[list(v) for v in input_bounds],
        next_action='Submit the time-zero named state and tensions to task.initial_state.qualify. Construction is not qualification or task acceptance; independently replay any interpolated feedforward schedule.')
    if args.reference_times_s is not None:
        result.update(reference_bank=points,tendon_order=native.tendons,
            tension_knots=dict(times_s=times,tensions_n=[[p['tensions_n'][t] for t in native.tendons] for p in points]),
            maximum_position_error_m=max(p['position_error_m'] for p in points),
            maximum_static_balance_inf_nm=max(p['static_balance_inf_nm'] for p in points))
    return result


def reference_times(cfg,args):
    times=args.reference_times_s or [0.]
    if times[0]!=0. or any(b<=a for a,b in zip(times,times[1:])) or times[-1]>cfg['task']['timing']['duration_s']:
        raise ValueError('INCREASING_FROZEN_REFERENCE_TIMES_FROM_ZERO_REQUIRED')
    return times


def run(ctx,args):
    from tools.research.state import guard
    from tools.research.budget import mathematics_fits
    charged=False
    cfg=ctx.artifact(args.configuration)
    count=len(reference_times(configuration_for_qualification(cfg),args))
    if 'spec' in ctx.store.session(ctx.run_id)['state']:
        guard(ctx.host,True)
        with ctx.store.transaction() as db:
            state=ctx.store.session(ctx.run_id,db)['state']
            if not mathematics_fits(state['spec'],state.get('mathematical_evaluations',0),count):
                raise ValueError('INITIAL_CONSTRUCTION_MATHEMATICAL_BUDGET_EXHAUSTED')
            state['mathematical_evaluations']=state.get('mathematical_evaluations',0)+count
            ctx.store.update_state(db,ctx.run_id,state);charged=True
    result=construct(cfg,args)
    result['charged_mathematical_evaluations']=count if charged else 0
    return Payload(contract='task.initial_construction',data=result)
