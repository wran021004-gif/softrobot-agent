"""Adapt the existing finite control search to native short trajectory evaluation.

No second optimizer, Store, evaluator or budget. Only full physical_replay can
establish frozen task acceptance; these callbacks rank sampled native proxies.
"""
from copy import deepcopy
import json
import time
import numpy as np
from tools.platform_store import plain


def baseline_identity(configuration, candidate, point, schedule):
    """Actual shared first rollout, independent of method/objective/search window."""
    import mujoco
    from tools.state_io import digest
    return digest(dict(candidate=plain(candidate),robot=configuration['robot'],task=configuration['task'],
        numerical={k:configuration['policy'].get(k) for k in ('backend','discretization','dynamics_model')},
        engine=mujoco.__version__,point={k:point[k] for k in ('actual_time_s','qpos_rad','qvel_rad_s',
            'integration_state','native_replay') if k in point},
        trajectory={k:schedule['trajectory'][k] for k in ('times_s','tensions_n','tendon_order')}))


def nonlinear_task_reason(family):
    """Current T1/T2 task boundary shared by admission and its catalog."""
    if family=='task.tracking':
        return 'Tracking nonlinear T1/T2 is not applicable; only direct sequence control is adapted.'
    if family in ('task.position_tool_axis','task.oriented_tracking'):
        return 'Tool-axis nonlinear T1/T2 is not applicable; only direct native sequence control is adapted.'
    return None


def window_facts(requirements, point):
    """Time facts shared by planning and admission; never construct a request."""
    start=point.get('actual_time_s')
    samples=[requirements.time_grid_s[i] for c in requirements.constraints for i in c.indices]
    return dict(state_time_s=start,task_deadline_s=requirements.duration_s,
        legal_correction_window_s=None if start is None else [start,requirements.duration_s],
        earliest_required_sample_s=min(samples) if samples else None,
        covers_required_samples=start is not None and all(start-1e-12<=t<=requirements.duration_s+1e-12 for t in samples),
        state_requirement='Frozen standardized initialization is at 0 s. A later origin requires an exact owned native checkpoint or verified measured prefix; a correction window does not move the initial state.')


def window_applicability(requirements, query, assessed, point, reasons):
    q=getattr(query,'control_optimization',None)
    if q is None:
        reasons.append('Bound complete source schedule and explicit v2 search window required.')
        window=None
    else:
        window=q.settings.correction_window_s
        if (point.get('actual_time_s') is None or abs(window[0]-point['actual_time_s'])>1e-12
                or abs(window[1]-requirements.duration_s)>1e-12):
            reasons.append(f'Native optimization window must start at selected state time {point.get("actual_time_s")} s and end at task duration {requirements.duration_s} s; received {window}. Frozen initialization starts at 0 s; a later window requires a matching saved state.')
    if (abs(query.protocol.duration_s-requirements.duration_s)>1e-12 or
            abs(query.protocol.period_s-requirements.physical_inputs['control_period_s'])>1e-12):
        reasons.append('Frozen duration and input period must match protocol.')
    if query.operation=='mujoco_nonlinear_task_capability_v1' and window and abs(window[0])>1e-12:
        reasons.append('Nonlinear T1 requires the complete frozen task from 0 s.')
    coverage=[]
    tracking=requirements.binding.get('task_family')=='task.tracking'
    axis_task=requirements.binding.get('task_family') in ('task.position_tool_axis','task.oriented_tracking')
    expected=({'timed_tracking':'tip_position','tool_axis_direction':'tip_tool_axis'} if requirements.binding.get('task_family')=='task.oriented_tracking' else
        {'tool_position':'tip_position','tool_axis_direction':'tip_tool_axis'} if axis_task else {'timed_tracking':'tip_position'} if tracking else
        {'terminal_error_m':'tip_position','holding_max_error_m':'tip_position','holding_max_speed_m_s':'tip_velocity'})
    reason=nonlinear_task_reason(requirements.binding.get('task_family'))
    if reason and query.operation!='mujoco_direct_control_v1':reasons.append(reason)
    if abs(requirements.sample_period_s-query.protocol.period_s)>1e-12:
        reasons.append('Native control requires matched sample and control grids.')
    if {c.constraint_id for c in requirements.constraints}!=set(expected):
        reasons.append('Native control requires registered Reach/Hold or timed Tracking norm constraints.')
    for c in requirements.constraints:
        matched=[i for i in c.indices if window and window[0]-1e-12<=requirements.time_grid_s[i]<=window[1]+1e-12]
        supported=((c.kind=='norm_bound' or (axis_task and c.constraint_id=='tool_axis_direction' and c.kind=='unsupported'
            and c.unsupported_requirement.get('kind')=='directed_unit_axis_cone')) and c.signal.entity=='tip' and c.signal.frame=='world' and
            c.signal.phase=='post_step' and c.signal.name==expected.get(c.constraint_id))
        if not supported:reasons.append('Unsupported native control constraint: '+c.constraint_id)
        if supported and len(matched)!=len(c.indices):reasons.append('All task position/velocity constraint samples must be covered by the native window.')
        coverage.append(dict(constraint_id=c.constraint_id,expressible=supported,
            status='diagnostic' if supported else 'not_checked',analyzed_indices=matched if supported else [],
            reason='Sampled native control proxy; remaining acceptance components require full replay.'))
    return dict(status='not_applicable' if reasons else 'applicable',reasons=reasons,
        constraint_coverage=coverage,full_task_supported=False,execution_support='independent_full_replay_required',
        model_assessment=assessed,horizon=dict(task_duration_s=requirements.duration_s,
            origin=point.get('actual_time_s'),analysis_window_s=window,period_s=query.protocol.period_s,
            **window_facts(requirements,point),
            interpretation='Every covered constraint sample, including checkpoint origin; no inherited prefix acceptance.'))


def calculate(configuration, binding, query, point, requirements, context, checkpoint=None):
    from extensions.tendon_family.mujoco_analysis import NativeModel
    from tools.research.local_control_search import search
    from tools.research.control_correction import task_measure, constraint_vectors
    from tools.research_tasks import task_adapter
    from tools.research.native_analysis import assessment, applicability
    from tools.research.analysis import scoped_result
    from schemas.platform import SessionInput
    started=time.perf_counter();q=query.control_optimization;settings=q.settings
    tracking=configuration['task']['family']=='task.tracking'
    axis_task=configuration['task']['family'] in ('task.position_tool_axis','task.oriented_tracking')
    if tracking and query.operation!='mujoco_direct_control_v1':
        raise ValueError('TRACKING_NONLINEAR_T1_T2_NOT_APPLICABLE')
    source=context['schedule'];tr=source['trajectory'];times=np.asarray(tr['times_s'])
    baseline_key=baseline_identity(configuration,binding['candidate'],point,source)
    k=round(point['actual_time_s']/query.protocol.period_s)
    prefix=point.get('prefix_tensions_n')
    if point.get('native_replay'):
        replay=point['native_replay']
        prefix=(replay['control_schedule']['trajectory']['tensions_n'][:k] if 'control_schedule' in replay else
            [r['tension_n'] for r in replay['rows']])
    if prefix is None or not np.array_equal(np.asarray(prefix).reshape(k,len(tr['tendon_order'])),np.asarray(tr['tensions_n'])[:k]):
        raise ValueError('CHECKPOINT_REQUIRES_IDENTICAL_VERIFIED_CONTROL_PREFIX')
    native=NativeModel(configuration)
    if checkpoint:checkpoint('native_progress_0000',dict(stage='native_model_built',completed_rollouts=0,
        cost={**native.cost,'kernel_wall_s':time.perf_counter()-started}))
    point,start=native.reconstruct(point) if point.get('native_replay') else (point,native.restore(point))
    if not np.allclose(native.limits[:,0],0,atol=0,rtol=0):raise ValueError('ZERO_LOWER_TENSION_BOUND_REQUIRED')
    adapter=task_adapter(configuration);options=adapter.control_search_options()
    if abs(configuration['task']['timing']['sample_period_s']-query.protocol.period_s)>1e-12:
        raise ValueError('NATIVE_CONTROL_V1_REQUIRES_MATCHED_SAMPLE_AND_CONTROL_GRIDS')
    initial=dict(id='native',schedule=source,limits=native.limits[:,1].tolist(),task_options=options)
    starts=[initial,*[dict(initial,id='native-'+str(i+1),schedule=row['schedule'])
        for i,row in enumerate(context.get('additional_starts',[]))]]
    start_sources={'native':context['source'],**{'native-'+str(i+1):row['source']
        for i,row in enumerate(context.get('additional_starts',[]))}}
    for item in starts:
        if not np.array_equal(np.asarray(item['schedule']['trajectory']['tensions_n'])[:k],np.asarray(tr['tensions_n'])[:k]):
            raise ValueError('CHECKPOINT_REQUIRES_IDENTICAL_VERIFIED_CONTROL_PREFIX')
    evaluations=[]
    reused=context.get('resume',{}).get('candidates',[])
    peak_state=context.get('resume_checkpoints',{}).get('baseline_peak_speed_state')
    retained_states={};best_scores={}
    resume_best=context.get('resume',{}).get('best')
    if resume_best and context.get('resume_checkpoints',{}).get('best_control_states'):
        retained_states['best']=(resume_best['sequence_hash'],context['resume_checkpoints']['best_control_states'])
        best_scores['best']=(resume_best['measure']['signed_maximum_excess'],resume_best['measure']['sum_normalized_excess'])
    def evaluate(_start, schedule, metadata):
        nonlocal peak_state
        if metadata['callback_index']<len(reused):
            row=reused[metadata['callback_index']]
            if (row['sequence_hash']!=metadata['sequence_hash'] or row['label']!=metadata['label']
                    or row['coefficients_n']!=metadata['coefficients_n'] or row.get('start','native')!=metadata['start']):
                raise ValueError('NATIVE_CONTINUATION_DIVERGED_NO_RESTART')
            evaluations.append(row['measure'])
            return {k:row[k] for k in ('reference','outputs','measure','task_gap','cost_s','independent_evaluation_executed')}
        try:
            outputs=native.rollout_sequence(start,times[k:],schedule['trajectory']['tensions_n'][k:],
                capture_control_states=True,holding_start_s=options.get('holding_start'),
                capture_actuator_extrema=bool(options.get('actuator_limits')),
                **(dict(capture_speed_after_s=options['holding_start']) if not tracking and not axis_task and not evaluations else {}))
            peak_state=outputs.pop('peak_speed_state',peak_state)
            control_states=outputs.pop('control_states')
        except Exception as exc:
            diagnostic=getattr(exc,'mujoco_diagnostic',None) or getattr(exc,'native_diagnostic',None)
            if metadata['label']=='baseline' and not evaluations and diagnostic:
                exc.native_baseline_failure=dict(identity=baseline_key,
                    failure_class='native_baseline_execution_blocker',reason=str(exc),
                    time_s=diagnostic.get('time_before_call_s',diagnostic.get('time_s')),
                    stage='initial_baseline_rollout',completed_optimization_evaluations=0,
                    scientific_infeasibility=False,task_acceptance='unmeasured')
            if checkpoint:checkpoint('native_progress_'+str(len(evaluations)+1).zfill(4),dict(
                callback_status='incomplete',completed_rollouts=len(evaluations),
                latest_complete_measure=evaluations[-1] if evaluations else None,
                cost={**native.cost,'kernel_wall_s':time.perf_counter()-started}))
            raise

        measure=task_measure(outputs,**options)
        if axis_task:components=measure['component_signed_excess']
        elif tracking:
            ratios=np.linalg.norm(constraint_vectors(outputs,**options),axis=1)
            components=dict(tracking=float(max(ratios)-1))
        else:
            from .control_correction import holding_mask
            hold=holding_mask(outputs['times_s'],options['holding_start'],options.get('holding_windows_s'))
            p=np.linalg.norm(np.asarray(outputs['tip_positions_m'])-options['target'],axis=1)
            v=np.linalg.norm(outputs['tip_velocities_m_s'],axis=1)
            ratios=np.r_[p[-1]/options['terminal_position_limit'],p[hold]/options['position_limit'],v[hold]/options['speed_limit']]
            sample_times=np.r_[outputs['times_s'][-1],np.asarray(outputs['times_s'])[hold],np.asarray(outputs['times_s'])[hold]]
            worst=int(np.argmax(ratios));goal_worst=dict(
                kind='terminal_position' if worst==0 else 'holding_position' if worst<=sum(hold) else 'holding_speed',
                time_s=float(sample_times[worst]),normalized_signed_excess=float(ratios[worst]-1))
            if measure.get('worst_constraint',{}).get('normalized_signed_excess',-float('inf'))<goal_worst['normalized_signed_excess']:
                measure['worst_constraint']=goal_worst
            components=dict(terminal=float(ratios[0]-1),position=float(max(p[hold])/options['position_limit']-1),
                speed=float(max(v[hold])/options['speed_limit']-1))
        components.update(measure.get('actuator_component_signed_excess',{}))
        score=(measure['signed_maximum_excess'],measure['sum_normalized_excess'])
        for group,eligible in (('best',True),('validation',metadata['sequence_hash'] not in context.get('rejected_sequences',[]))):
            if eligible and (group not in best_scores or score<best_scores[group]):
                best_scores[group]=score;retained_states[group]=(metadata['sequence_hash'],control_states)
        evaluations.append(measure)
        if checkpoint:checkpoint('native_progress_'+str(len(evaluations)).zfill(4),dict(completed_rollouts=len(evaluations),latest=measure,
            cost={**native.cost,'kernel_wall_s':time.perf_counter()-started}))
        return dict(reference='native-rollout-'+str(len(evaluations)-1),outputs=outputs,measure=measure,
            task_gap=dict(valid_complete=True,accepted=False,normalized_gap=measure['normalized_gap'],
                components=components),
            cost_s=0.,independent_evaluation_executed=False)
    result=search(starts,evaluate,settings,evaluation_kind='native_short_rollout',reuse_sequences=True,
        rank_key=lambda row:(row['measure']['signed_maximum_excess'],row['measure']['sum_normalized_excess']),
        stop_when=lambda row:(row['measure']['signed_maximum_excess']<=-settings.safety_margin_fraction
            and row['sequence_hash'] not in context.get('rejected_sequences',[])))
    best=result['best']
    if best is None:raise ValueError('NO_VALID_NATIVE_CONTROL_PREDICTION')
    validation=(result['candidates'][-1] if result['stop_reason']=='local_target_reached' else
        min((r for r in result['candidates'] if r['sequence_hash'] not in context.get('rejected_sequences',[])),
            key=lambda r:(r['measure']['signed_maximum_excess'],r['measure']['sum_normalized_excess']),default=best))
    if reused:result['proposed_validation']=validation['reference']
    from tools.research.control_correction import corrected_tensions
    selected_start=next(s for s in starts if s['id']==validation['start'])
    optimized=deepcopy(selected_start['schedule'])
    optimized['trajectory']['tensions_n']=corrected_tensions(selected_start['schedule']['trajectory']['tensions_n'],times[:-1],settings.knots_s,
        validation['coefficients_n'],native.limits[:,1],settings.correction_window_s).tolist()
    optimized.update(source_kind='explicit_control_schedule_v1',task_acceptance='unmeasured')
    optimized['provenance']=dict(method=query.operation,source=start_sources[validation['start']],candidate=binding['candidate'],
        selected_start=validation['start'],
        state_provenance=point.get('provenance'),settings=plain(settings),inherited_acceptance=False)
    cost=dict(**native.cost,optimization_iterations=result['iterations_started'],
        completed_response_steps=len(result['local_responses']),
        optimization_evaluations=len(evaluations),kernel_wall_s=time.perf_counter()-started)
    if reused:cost['reused_native_callbacks']=len(reused)
    raw=dict(initial_state=point,original_schedule=source,optimized_schedule=optimized,optimization=result,cost=cost,
        external_force_execution=dict(forces=native.scene['forces'],semantics=native.scene['semantics'].get('external_forces')))
    best_start=next(s for s in starts if s['id']==best['start'])
    best_tr=deepcopy(best_start['schedule']['trajectory'])
    best_tr['tensions_n']=corrected_tensions(best_tr['tensions_n'],times[:-1],settings.knots_s,
        best['coefficients_n'],native.limits[:,1],settings.correction_window_s).tolist()
    if best['sequence_hash']!=validation['sequence_hash']:
        raw['best_schedule']=deepcopy(optimized)
        raw['best_schedule']['trajectory']=best_tr
        raw['best_schedule']['provenance'].update(source=start_sources[best['start']],selected_start=best['start'])
        raw['exported_control_role']='next_validation_proposal_distinct_from_best_model_prediction'
    if len(starts)>1:
        raw['start_sources']=[dict(start=s['id'],source=start_sources[s['id']],schedule=s['schedule']) for s in starts]
    if retained_states.get('best',(None,))[0]==best['sequence_hash']:
        from tools.state_io import digest
        raw['best_control_states']={}
        for name,saved in retained_states['best'][1].items():
            index=int(np.argmin(abs(times-saved['actual_time_s'])))
            saved.update(candidate=binding['candidate'],configuration_identity=binding['effective_configuration_identity'],
                prefix_tensions_n=best_tr['tensions_n'][:index],remaining_task_s=max(0.,float(times[-1]-saved['actual_time_s'])),
                provenance=dict(method='best_native_control_checkpoint',source=start_sources[best['start']],
                    sequence_hash=digest(best_tr['tensions_n']),state_selection=name,
                    control_grid_time_s=float(times[index]),inherited_acceptance=False))
            saved['u']=best_tr['tensions_n'][min(index,len(best_tr['tensions_n'])-1)]
            raw['best_control_states'][name]=saved
    if configuration['task']['family']=='task.oriented_tracking':raw['rigid_tool_binding']=native.tool_load_binding
    if peak_state is not None:
        peak_state.update(candidate=binding['candidate'],configuration_identity=binding['effective_configuration_identity'],
            provenance=dict(method='baseline_rollout_holding_speed_peak',source=context['source'],inherited_acceptance=False))
        raw['baseline_peak_speed_state']=peak_state
    baseline=evaluations[0];comparison=dict(baseline=baseline,best=best['measure'])
    fields=([('max_position_error','max_position_error_m','m'),('max_tool_axis_angle_error','max_tool_axis_angle_error_rad','rad')] if axis_task else [('max_position_error','max_position_error_m','m'),
        ('rms_position_error','rms_position_error_m','m')] if tracking else [
        ('holding_max_speed','holding_max_speed_m_s','m/s'),
        ('holding_max_position_error','holding_max_position_error_m','m')])
    fields.append(('signed_maximum_excess','signed_maximum_excess','1'))
    quantities=[dict(name=label+'_'+name,value=row[field],unit=unit,
        source_pointer='/native_dynamics/optimization/'+('candidates/0' if label=='baseline' else 'best')+'/measure/'+field)
        for label,row in comparison.items() for name,field,unit in fields]
    summary=dict(question='Bounded native sequence control optimization',basis=dict(model='model.mujoco_native@1.0.0',
        state_time_s=point['actual_time_s'],window_s=settings.correction_window_s,channels=native.tendons,
        search_dimension=result['search_dimension'],sample_count=len(best['outputs']['times_s'])),quantities=quantities,
        comparison=comparison,solver=dict(stop_reason=result['stop_reason'],
            last_local_solver=next((r['local_solver'] for r in reversed(result['candidates']) if r.get('local_solver')),None)),
        interpretation='Cloned nonlinear native sequence predictions with the existing bounded local control search.',
        limitations=['Local sampled simulation estimate; no global optimum, hardware or regional guarantee.'],
        unresolved=['Full 0-to-duration replay and independent frozen acceptance remain required.'],cost=cost,
        control_schedule_pointer='/control_schedule_reference',detail_pointer='/native_dynamics',
        next_actions=['physical_replay using control_schedule_reference','Read local_responses to revise parameterization or radius','Rebuild a legal prefix for each changed structure'])
    fit=applicability(requirements,query,assessment(SessionInput.model_validate(configuration),requirements),point)
    value=dict(status='computed',operation=query.operation,binding={**binding,'model_identity':binding['effective_configuration_identity']},
        model_identity=binding['effective_configuration_identity'],protocol=plain(query.protocol),
        operating_point={key:point[key] for key in ('actual_time_s','phase','input_units')},native_dynamics=raw,native_analysis=summary,
        task_acceptance='unmeasured',local_model_constraints=dict(status='diagnostic_only'),proxy_values={},
        internal_calculations=[dict(purpose=query.operation,**cost)],limitations=summary['limitations'])
    value=scoped_result(value,requirements,fit,query)
    if query.operation=='mujoco_nonlinear_task_capability_v1':
        from tools.research.nonlinear_capability import t1_summary,control_sensitivities
        value['nonlinear_capability']=t1_summary(value,settings)
        raw['control_task_sensitivity']=control_sensitivities(result,requirements)
    json.dumps(value,allow_nan=False)  # Fail before worker publication, with last progress retained.
    return value
