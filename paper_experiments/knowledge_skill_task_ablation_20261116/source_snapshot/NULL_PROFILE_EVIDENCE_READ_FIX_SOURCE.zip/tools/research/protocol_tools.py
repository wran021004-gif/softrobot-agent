"""Expose explicitly granted Registry schemas to the existing Main harness."""
import json

PUBLIC=('task.protocol.inspect','task.protocol.bind','task.protocol.evaluate','task.protocol.aggregate','task.initial_state.construct','task.initial_state.qualify','reference.generate','trace.decision','trace.replay_export','research.math','evidence.passive_history.audit')


def freeze_registry_tools(configuration,bindings):
    from tools.platform_registry import registry
    if not isinstance(bindings,dict) or set(bindings)-set((*PUBLIC,'research.dispatch')):
        raise ValueError('EXPLICIT_SUPPORTED_REGISTRY_TOOL_BINDINGS_REQUIRED')
    for name,version in bindings.items():
        registry().get(name,version,'tool')
        configuration['policy']['tool_bindings'][name]=version
        if name not in configuration['policy']['allowed_tools']:configuration['policy']['allowed_tools'].append(name)
        configuration['policy'].setdefault('operation_allowances',{})[name]=dict(timeout_s=None,reserve_s=None)


def definitions(host):
    policy=host.store.session(host.run_id)['snapshot']['input']['policy']
    granted=policy.get('tool_bindings',{})
    return [host.reg.get(name,granted[name],'tool') for name in PUBLIC if name in granted]


def native_tools(host,tool_class,request_phase=None):
    result=[]
    for definition in definitions(host):
        name=definition.extension_id.replace('.','_')
        def execute(use,definition=definition,**kwargs):
            from tools.research.budget import provider_request_scope
            # The same Host owns permissions, operation budgets, evidence,
            # receipts and failures; Main has no direct Python execution route.
            with provider_request_scope(host,request_phase):
                receipt=host.invoke(dict(request_id='registry-'+use['toolUseId'],tool_id=definition.extension_id,
                    tool_version=definition.version,arguments=use['input'],reason='Main selected the explicitly granted registered interface '+definition.extension_id,cache='new'))
            return dict(toolUseId=use['toolUseId'],status='success' if receipt['execution_status']=='completed' else 'error',
                content=[dict(text=json.dumps(host.observation(receipt),ensure_ascii=False))])
        result.append(tool_class(name,dict(name=name,description=definition.description,
            inputSchema={'json':definition.input_schema.model_json_schema()}),execute))
    return result


def reporter_view(evaluation):
    """Only recorded facts and margins; no additional interpretation or Provider."""
    raw=evaluation.model_dump(mode='json') if hasattr(evaluation,'model_dump') else evaluation
    detail=raw.get('diagnostics',{})
    return dict(validity=raw['validity'],task_success=raw['task_success'],failed_checks=detail.get('failed_checks',[]),
        worst_constraint=detail.get('worst_constraint'),constraints=detail.get('constraints',{}),
        missing_reason=raw.get('reason'),interpretation='Valid failed constraints, missing observations, historical regression and new Study success are distinct.')


def result_card(value,reference):
    from schemas.research_reporting import ResultCard,ResultIdentity,EvidenceLocation,ReportedMetric,RecordedField
    from tools.research.contracts import EvidenceSummary
    detail=value['diagnostics'];origin=detail.get('origin','unavailable')
    location=lambda pointer:EvidenceLocation(reference=reference,pointer=pointer)
    metrics=[]
    for key,constraint in detail.get('constraints',{}).items():
        escaped=key.replace('~','~0').replace('/','~1');pointer='/diagnostics/constraints/'+escaped
        metrics.append(ReportedMetric(name=key,value=constraint['observed'],unit=constraint['units'],threshold=constraint['limit'],
            threshold_source=location(pointer+'/limit'),passed=detail['checks'][key],scope='physical_task',source=location(pointer+'/observed')))
    return ResultCard(identity=ResultIdentity(result=location(''),design_identity=detail.get('design_identity'),
            task_identity=detail.get('bound_task_identity',detail.get('task_protocol_hash')),operation='frozen_protocol_evaluation'),
        evidence_summary=EvidenceSummary(claim_kind='PHYSICAL_OBSERVATION' if origin in ('core_execution','historical') else 'NUMERICAL_DIAGNOSTIC',
            verification_status='historical_offline_regression' if origin=='historical' else value['validity'],evidence_reference=reference,
            covered_samples=dict(required_frozen_constraints=list(detail.get('checks',{}))),
            supported_inferences=['Saved evaluator measurements within the frozen protocol and recorded evidence origin.'],
            unsupported_inferences=['Historical evidence is not new Study success.','No future or continuous-time guarantee.']),
        recorded_context=[RecordedField(name='evidence_origin',value=origin,source=location('/diagnostics/origin'))],
        metrics=metrics,main_violations=detail.get('failed_checks',[]),deterministic_summary=reporter_view(value),
        detail_sources=[location('/diagnostics')])
