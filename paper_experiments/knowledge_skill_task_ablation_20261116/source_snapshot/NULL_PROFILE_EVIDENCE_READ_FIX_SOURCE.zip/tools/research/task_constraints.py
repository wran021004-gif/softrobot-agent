"""Pure task translation and existing local-tool applicability; no Store or solver."""
from tools.research.budget import mathematical_remaining
from copy import deepcopy
from tools.research.scientific_intent import mechanism_interface
from schemas.platform import Binding, Payload
from tools.platform_store import plain
from tools.research_tasks import task_adapter
from tools.research.math_capability_catalog import (OPERATION_CATEGORIES, CAPABILITY_STATUS_MEANINGS,
    capability_inventory, generic_operations, parameter_sensitivity_scope)

SCIENTIFIC_INTERPRETATION = dict(
    version='scientific_interpretation_v1',
    measured_observation='Named model or physical execution observations apply only to recorded states, actual inputs, times and sampling conditions.',
    model_calculation='Calculations depend on the named model, assumptions, operating point, input bounds and horizon; nonlinear physical transfer requires validation.',
    research_hypothesis='A proposed mechanism needs subsequent observations that can support or weaken it.',
    causal_conclusion='Requires controlled conditions or other identifying evidence; unequal outcomes alone do not identify a cause.',
    prediction_difference='Match candidate, task, actual control, initial state, input channels and time grid before computing model prediction differences.',
    time_scope='Finite discrete observations alone do not establish between-sample or extrapolated dynamics; state any additional model assumptions.',
    horizon_scope='Instantaneous dynamics, local sensitivity or single-time braking authority does not establish complete finite-horizon task feasibility or infeasibility.')

METHOD_MEANINGS = {
    'mechanism_structure_v1': ('Native mechanism and structural direction', 'Registered instantaneous native mechanism compositions and normalized two-scale legal continuous structural perturbations at explicit state/input semantics; bounded local proposals only, never complete task improvement or a strict gradient.'),
    'linearization': ('Local dynamics', 'Frozen continuous affine A/B/C/D and drift at the declared operating point; not a trajectory or stability proof.'),
    'controllability': ('Local drive authority', 'Finite continuous/held-input normalized Gramians and output authority; signed unbounded increments do not prove bounded nonnegative tendon feasibility.'),
    'equilibrium': ('Static input construction', 'Bounded local static target construction. Static balance cannot establish holding-window maximum speed or identify a structure-versus-dynamic-control cause. Solver failure is not structural infeasibility; matched dynamic execution and independent evaluation remain necessary.'),
    'input_sensitivity': ('Static input response', 'Checked local implicit-function response of equilibrium to physical input; SoRoSim fixed-input equilibrium only.'),
    'design_sensitivity': ('Static structural response', 'Paired single-parameter local static sensitivity with fixed physical input; no global design descent guarantee.'),
    'mujoco_direct_control_v1': ('Native sequence control diagnostic', 'Reach/Hold, timed Tracking, position/tool-axis or loaded oriented Tracking. Direct and T1 share local response/pattern search and the explicitly selected temporal resolution; changing method does not add independent interval controls. Produces a full schedule for independent physical_replay. Only T1 supplies saved-T1 semantics for T2. No task acceptance or global optimality from optimization.'),
    'native_dynamics_v1': ('Native MuJoCo mechanics', 'Native mass, forces, acceleration, world tip and tendon Jacobians at an exact native state. Small internal force-balance residuals do not establish GVS/MuJoCo prediction agreement; that requires matched state/input/output comparisons.'),
    'short_input_response_v1': ('Native short input response', 'Legal actual-tension FD at two input step sizes, optional bounded correction checked by native integration. Neither two FD sizes nor two integration timesteps prove numerical convergence or a regional bound; a failed local correction does not establish infeasibility.'),
    'fixed_input_structure_v1': ('Native structure and function response', 'Recompile registered one-parameter candidates at fixed input; this response is not reoptimized structural capability or an optimal-value gradient.'),
    'endpoint': ('Bounded terminal feasibility', 'Bounded affine input sequence for covered terminal position conditions; intermediate constraints remain unchecked.'),
    'braking': ('Bounded terminal braking', 'Bounded affine sequence for covered terminal position/speed; not full holding-window compliance.'),
    'instantaneous_braking_v1': ('Instantaneous braking authority', 'Minimum instantaneous speed derivative over the physical input box at an exact saved state. Multiplying by a time interval does not establish finite-horizon braking or controllability.'),
    'trajectory_feasibility': ('Sampled feasible sequence', 'Independent discrete replay within the bounded affine model. Small internal dynamics/replay residuals are not cross-model prediction errors; failed search is inconclusive, not structural infeasibility.'),
    'task_capability': ('Best found task violation', 'Three-start SLSQP minimization of a dimensionless max normalized signed residual; physical conversion depends on the active constraint and its threshold. Negative means a model-sample feasible witness, not a globally optimal control. Condition numbers alone are not task-score error bounds.'),
    'sampled-affine-conic-minimax-v1': ('Numerical optimal task violation', 'min_U max_i g_i over an affine sampled model and physical box. Supports declared sampled norm/component constraints, including timed position and Reach/Hold speed; no directed-axis, rigid-load/contact acceptance. GVS predictions require matched actual-control/state/grid comparison and independent physical evaluation. SOCP primal/dual/support/gap checks are floating estimates; strict optimal_value remains unavailable. Free path progress jointly optimizes U and s, enumerating sampled corners in a chosen finite horizon; no unrestricted-time exclusion or geometric acceptance.'),
    'controlled-capability-sensitivity-v1': ('Controlled structural direction', 'Matched baseline and +/-h (optionally +/-h/2) models: reoptimized FD versus fixed U, conditional envelope and dual-face checks. Path progress is reoptimized too. Branch ties/active-set changes withhold a strict gradient; no physical improvement guarantee.')}


def registered_analysis_method_names():
    """Reuse existing method declarations; do not infer a candidate or a method."""
    from tools.research.nonlinear_capability import METHODS
    return sorted(set(METHOD_MEANINGS)|set(METHODS.values()))


def analysis_operating_points(method, operation):
    """Discover legal points using the original full-request restrictions."""
    from tools.research.contracts import AnalysisRequest
    from tools.research.optimal_capability import SENSITIVITY
    points=[]
    for point in AnalysisRequest.model_json_schema()['properties']['operating_point']['enum']:
        try:AnalysisRequest.validate_operating_point(operation,point,optimal_sensitivity=method==SENSITIVITY)
        except ValueError:continue
        points.append(point)
    return points


def selected_operating_point_guidance(host, reference, method, detail):
    """Read-only selected-method guidance; no reconstruction or integration."""
    from types import SimpleNamespace
    from tools.research.state import state
    from tools.research.numerics import native_point, execution_update
    from tools.research.design import verify_candidate
    s=state(host)
    try:cfg=verify_candidate(host,reference)['configuration']
    except ValueError as exc:
        if str(exc)!='OLD_EVALUATION_PROFILE_CANDIDATE_REQUIRES_NEW_CONSTRUCTION':raise
        return dict(method=method,operating_points=[],saved_sources=[],available_source_references=[],
            unavailable_sources=[str(exc)],source_selection_rule='Historical state/control evidence grants no current-profile execution permission.',
            nonzero_state_status='requires_current_profile_candidate',
            preparation=dict(tool='research_plan',action='generate',decision=dict(selected_candidate=reference),generation=dict(changes={})),
            details_query=dict(reference=reference,view='full',pointer='/parameters'))
    if cfg['task'].get('physical_problem'):
        from tools.research.structure_research import finite_time_discovery
        finite=finite_time_discovery(cfg)
        points=[dict(name='re_equilibrated',meaning='Solve the frozen unilateral assembly under the selected load; no active input.')]
        if finite['status']!='not_applicable':
            points.append(dict(name='frozen_task_initial_state',effect_semantics='finite_time_task_response',
                meaning='Complete registered frozen loading protocol, every condition and qualification gate; no active input.',
                cost_preview=finite))
        return dict(method=method,operating_points=points,
            saved_sources=[],unavailable=[],load_conditions=[x['name'] for x in cfg['task']['physical_problem']['loads']],
            details_query=dict(reference=reference,view='full',pointer='/configuration/task/physical_problem'))
    operation=detail['operation'];native=detail['request_template'].get('model_source')=='mujoco'
    sources=[];unavailable=[]
    if native:
        for ref in s.get('analysis_results',[]):
            result=host.store.artifact(ref,paths=('candidate','native_dynamics.baseline_peak_speed_state.actual_time_s'))
            if result.get('candidate')!=reference:continue
            checkpoint=result.get('native_dynamics',{}).get('baseline_peak_speed_state')
            best=host.store.artifact(ref,paths=('status','operation','native_dynamics.optimization.best.reference'))
            if best.get('status')=='computed' and best.get('operation') in ('mujoco_direct_control_v1','mujoco_nonlinear_task_capability_v1') and best.get('native_dynamics',{}).get('optimization',{}).get('best'):
                sources.append(dict(saved_state=ref,native_state_selection=dict(kind='best_peak_speed'),
                    readiness='Exact best-control sample; saved checkpoint reused, otherwise charged prefix replay inside Worker.',
                    alternatives=['best_holding_start','best_pre_hold_peak_speed','best_sample with explicit time_s'],
                    scope='Real best-control state only. At deadline no remaining control horizon; no full-task feasibility claim.'))
            if not checkpoint:continue
            try:
                point=native_point(host,SimpleNamespace(candidate=reference,saved_state=ref),cfg)
                sources.append(dict(saved_state=ref,actual_time_s=point['actual_time_s'],
                    checkpoint_pointer='/native_dynamics/baseline_peak_speed_state',
                    nonzero_generalized_velocity=any(v!=0 for v in point['qvel_rad_s']),
                    source_control=point['provenance'].get('source'),
                    readiness='complete recorded integration state; exact restore verified inside Worker',
                    scope=point['provenance']['scope']))
            except (ValueError,KeyError,IndexError) as exc:unavailable.append(dict(reference=ref,reason=str(exc)))
        for ref in [*s.get('results',[]),*s.get('physical_replays',[])]:
            result=host.store.artifact(ref)
            if result.get('candidate')!=reference:continue
            query=SimpleNamespace(candidate=reference,saved_state=None,execution=ref,update_id=0,operating_point='saved_state')
            try:
                point=native_point(host,query,cfg)
                sources.append(dict(execution=ref,verified_update_id=0,actual_time_s=point['actual_time_s'],
                    trajectory=point['provenance']['trajectory'],model_source='mujoco',
                    readiness='verified_measured_prefix; choose an actual trace interval update_id; worker reconstruction not executed'))
            except (ValueError,KeyError,IndexError) as exc:unavailable.append(dict(reference=ref,reason=str(exc)))
    else:
        for ref in s.get('historical_diagnostic_sources',[]):
            saved=host.store.artifact(ref)
            if saved.get('provenance',{}).get('candidate')!=reference or saved.get('configuration')!=cfg:continue
            try:
                item=execution_update(host,ref,saved['record']['update_id'])
                if item['configuration']!=cfg:continue
                sources.append(dict(execution=ref,update_id=item['record']['update_id'],
                    readiness='complete recorded update; exact reduced dimensions and phase checked at admission'))
            except (ValueError,KeyError,IndexError) as exc:unavailable.append(dict(reference=ref,reason=str(exc)))
    points=[]
    for point in analysis_operating_points(method,operation):
        required=['saved_state OR execution + update_id'] if point=='saved_state' else []
        ready='source_selection_required' if sources else 'missing_exact_state_source'
        if point!='saved_state':ready='requires_scientific_parameters_and_admission'
        if native and point=='standardized_initial_pretension':
            try:
                native_point(host,SimpleNamespace(candidate=reference,saved_state=None,operating_point=point),cfg)
                ready='frozen_initialization_available'
            except ValueError as exc:ready='not_applicable';required.append(str(exc))
        points.append(dict(operating_point=point,readiness=ready,required_sources=required,
            coverage='Exact selected instant/prefix and remaining horizon only.' if point=='saved_state' else
                'Frozen time-zero initialization; does not diagnose the observed terminal state.' if native else
                'Declared model operating point; no measured terminal state is implied.'))
    return dict(method=method,scientific_purpose=detail['scientific_purpose'],operating_points=points,
        available_source_references=sources,unavailable_sources=unavailable,
        source_selection_rule='Choose saved_state alone OR execution plus an actual update_id; never combine. To select a best Native trajectory state, pair its result saved_state with native_state_selection. Tip arrays select time only; full integration state is restored or reconstructed with actual costs.',
        nonzero_state_status='recorded_sources_require_Main_choice_and_Worker_validation' if sources else '当前没有合法的非零速度机制工作点来源',
        preparation=dict(tool='research_plan',action='physical_replay',scope='A complete candidate-bound measured execution provides trajectory intervals; independent Replay charges and all original prerequisites apply.'),
        key_state_selection='For speed/braking hypotheses prefer an actual recorded interval before hold, with nonzero velocity or a large measured task violation. Main reads the cited trajectory, selects its update_id, and original native_point admission verifies the source; time-zero zero-speed braking is not substituted.',
        saved_state_requirements='Exact candidate/configuration identity, model state, channel order, input units and phase; native requires integration checkpoint, reduced state cannot substitute. Unlisted states remain subject to original source admission.',
        coverage=detail['coverage'],scientific_scope=detail.get('scientific_scope'),limitations=[detail['description'],*detail['limitations']],
        deterministic_method_applicability=detail['applicability']['status'],execution_status=detail['execution_status'],
        admission='Parameter legality, available evidence, execution permission and scientific conclusions are separate; full original admission still applies.')


def mathematical_method_view(host, reference, *, budget_snapshot=None):
    """Existing candidate-bound read view: legacy T2 root plus all method details."""
    from tools.research.state import state, protected
    from tools.research.contracts import AnalysisRequest
    from tools.research.optimal_capability import candidate_methods, CONIC, SENSITIVITY
    from tools.research.design import verify_candidate
    from tools.research.research_context import mathematics_authorization
    s=state(host);spec=s['spec'];c=host.store.artifact(reference)
    if reference==s.get('family_space_reference'):
        return dict(candidate=None,methods={},operation_categories=dict(OPERATION_CATEGORIES),
            capability_statuses=dict(CAPABILITY_STATUS_MEANINGS),
            capability_inventory=capability_inventory(reference=reference),
            scope='Static C0 discovery at the frozen domain anchor. Candidate applicability and request admission are unassessed; use an owned candidate for formal method templates.')
    if reference not in s.get('candidates',{}).values():raise ValueError('OWNED_RESOLVED_CANDIDATE_REQUIRED')
    try:verify_candidate(host,reference);binding_error=None
    except ValueError as exc:binding_error=str(exc)
    analysis_metadata=[(r,host.store.artifact(r,paths=('candidate','implementation','status','model','protocol',
        'requested_operation.operating_point'))) for r in s.get('analysis_results',[])]
    readiness=candidate_methods(host,reference,analysis_metadata=analysis_metadata) if binding_error is None else dict(
        method=SENSITIVITY,status='requires_current_profile_candidate',reasons=[binding_error])
    cfg=c['configuration'];requirements=describe_analysis_requirements(cfg,{})
    from tools.research.physical_replay import legal_control_sources
    bound_sources=legal_control_sources(host,reference) if binding_error is None else []
    from tools.research.config import frozen_analysis_protocol
    protocol=frozen_analysis_protocol(spec,c)
    remaining=mathematical_remaining(spec,s.get('mathematical_evaluations',0))
    readiness.setdefault('remaining_evaluations',remaining)
    rows=analysis_capabilities(cfg,requirements,protocol,
        remaining_evaluations=remaining,mathematical_methods={CONIC:spec.get('mathematical_methods',{}).get(CONIC),
            SENSITIVITY:spec.get('mathematical_methods',{}).get(SENSITIVITY)})
    models=[]
    for r,v in analysis_metadata:
        if (v.get('candidate')==reference and v.get('implementation')==s['freeze'] and
                v.get('status')=='computed' and v.get('model') and v.get('protocol')==protocol):models.append(r)
    authorization=mathematics_authorization(host,s);methods={}
    closed=s['research_status']=='stopped' or protected(host)
    for row in rows:
        key=SENSITIVITY if row.get('submode') else row.get('capability_method') or row['operation']
        purpose,meaning=METHOD_MEANINGS[key]
        kinds=row.get('constraint_kinds',['norm_bound','component_interval','path_bound'])
        reasons=[*row['reasons'],*([binding_error] if binding_error else [])]
        if key==SENSITIVITY:
            reasons=[r for r in reasons if r!='candidate_variable_and_saved_model_stencil_validation_required']+readiness.get('reasons',[])
        authorized='analysis' in spec['capabilities'] and (not row.get('capability_method') or
            bool(spec.get('mathematical_methods',{}).get(key) and spec.get('mathematical_methods',{}).get(CONIC)))
        request=dict(candidate=reference,operation=row['operation'],protocol=protocol,
            operating_point='target_equilibrium' if key=='equilibrium' else 'fixed_input_equilibrium' if key in
            ('input_sensitivity','design_sensitivity') else 'saved_state' if key=='instantaneous_braking_v1' else 'controller_start_input')
        required=[]
        if key in ('linearization','controllability'):
            required.append('scoring_window_s from protocol.windows_s')
            if protocol['windows_s']:request['scoring_window_s']=protocol['windows_s'][0]
        if key=='instantaneous_braking_v1':required.append('saved_state OR execution + update_id')
        if key in ('native_dynamics_v1','short_input_response_v1','fixed_input_structure_v1','mujoco_direct_control_v1'):
            request.update(model_source='mujoco',operating_point='standardized_initial_pretension')
            required.append('operating_point: frozen initialization OR saved_state with exact saved_state / execution + update_id source')
            if key=='native_dynamics_v1':required.append('Optional native.tensions_n; otherwise use the selected point input')
            elif key=='fixed_input_structure_v1':required.append('Optional native={tensions_n,horizon_s}; fixed across structure comparisons')
            elif key=='short_input_response_v1':required.append('Optional native={tensions_n,horizon_s,difference_step_n,correction_radius_n}')
        if key=='mujoco_direct_control_v1':
            required.append('control_optimization={source,settings}; v2 settings require explicit correction_window_s and knots_s. Window starts at the selected native state and ends at the frozen task deadline, covering all required samples.')
            required.append('method=pattern requires safety_margin_fraction=0; positive safety_margin_fraction requires compatible v2 method=response. correction_window_s allows control changes; it is not the Reach/Hold scoring holding window.')
        if key=='fixed_input_structure_v1':required.append('structure_response={variable,candidates}; choose a legal continuous variable and owned same-task comparable single-parameter candidates; fixed input is not reoptimized capability')
        if key=='design_sensitivity':required.append('design_sensitivity={variable,step,minus_candidate,plus_candidate}')
        if row.get('capability_method'):request['capability_method']=CONIC
        if key==SENSITIVITY:required.append('optimal_sensitivity={variable,steps,model_results baseline first}; validated stencil required')
        methods[key]=dict(operation=row['operation'],method=key,method_version=row.get('method_version',key),scientific_purpose=purpose,description=meaning,
            candidate=reference,task_identity=c.get('task_identity'),task_family=cfg['task']['family'],
            kernel_supported=True if key in ('linearization','controllability','instantaneous_braking_v1','native_dynamics_v1','short_input_response_v1','fixed_input_structure_v1','mujoco_direct_control_v1') else
                any(x.kind in kinds for x in requirements.constraints) and
                all(x.kind in kinds or x.kind == 'unsupported' for x in requirements.constraints),
            model_built=bool(models),model_sources=[dict(reference=r,pointer='/model') for r in models],
            coverage=row.get('coverage',[]),full_task_supported=row.get('full_task_supported',False),
            study_authorized=authorized,formal_scope_authorized=authorization['registered_study_scope_authorized'],
            formal_execution_authorized=bool(authorized and authorization['registered_study_scope_authorized'] is True),
            execution_status='blocked' if reasons or not authorized or closed else 'conditional_on_admission',
            missing=reasons+row.get('parameter_requirements',[])+([] if authorized else ['study_method_grant_required'])+
                ([] if authorization['registered_study_scope_authorized'] is True else ['formal_study_math_scope_required'])+
                (['study_stopped'] if s['research_status']=='stopped' else ['protected_closeout'] if closed else []),
            estimated_evaluations=row['evaluations'],wall_cost='unknown',
            estimated_evaluation_range=row.get('evaluation_range',[row['evaluations'],row['evaluations']]),
            cost_scope=row.get('evaluation_rule','Model preparation and internal solver attempts are distinct; see original receipts.'),
            limitations=row['limitations'],prerequisites=row['prerequisites'],applicability=row,
            required_parameters=required,request_template=request,
            detail_query=dict(reference=reference,view='mathematical_capabilities',pointer='/methods/'+key),
            schema_query=dict(reference=reference,view='mathematical_capabilities',pointer='/analysis_request_schema'))
        methods[key]['planning_status']=('unauthorized' if not authorized or authorization['registered_study_scope_authorized'] is not True else
            'unsupported' if binding_error or row.get('planning_status')=='unsupported' else
            'insufficient_budget' if row.get('budget_allowed') is False else
            'blocked' if closed else row.get('planning_status','unsupported' if reasons else 'ready'))
        if key==SENSITIVITY:
            methods[key]['readiness']=readiness
            methods[key]['cost_scope']='M*B conic solves + up to 2*k dual-face attempts; M=1+2*k. B=1 except two-segment paths: samples-2. Model preparation additional; wall cost unknown.'
            methods[key].update(registered=True,authorized=methods[key]['formal_execution_authorized'],
                applicable=row['task_applicable'] and any(r.get('parameter') for r in readiness.get('variables',[])),
                executable=bool(methods[key]['formal_execution_authorized'] and not closed and readiness.get('status')=='executable'))
            if not methods[key]['executable']:methods[key]['execution_status']='blocked'
            elif not reasons:methods[key]['planning_status']='ready'
            methods[key]['structural_proposal']='Optional research_plan(action=generate, generation=<copy current parameters with one bounded edit>, supporting_evidence=[T2 result], decision.claimed_inference=empirical_search). Choose direction and step from the evidence; unresolved permits contrasts or no edit. New candidate requires its own T1 control reoptimization (1 model + B solves); physical acceptance remains unmeasured.'
        if key=='mujoco_direct_control_v1':
            methods[key]['control_input_guidance']=dict(
                candidate_role='Structure reference; candidate is not an executable control source.',
                source_role='Complete executable sequence bound to candidate/task/channels/time grid/bounds; use the returned source reference.',
                recorded_sources=bound_sources,
                baseline_initialization=dict(tool='research_plan',action='initialize_control',
                    control_seed=dict(candidate=reference,method='baseline'),
                    scope='Optional candidate pretension baseline on the full frozen task grid; task_acceptance=unmeasured. Full Plan/decision admission applies.'),
                after_initialization=('On the identical candidate/condition, the V4 scientific choice survives this preparation. Submit research_analysis with the chosen scope and effort; select a source only if distinct legal schedules exist.' if spec.get('research_decisions',{}).get('analysis_interface')=='scientific_question_v4' else
                    'Use returned source, not candidate. Submit diagnose again with your chosen hypothesis, candidate and method, then research_analysis.'),
                settings=required[-1])
            if spec.get('native_control_limits'):methods[key]['execution_limits']=spec['native_control_limits']
            from tools.research.native_control import window_facts
            from tools.research.budget import decision_budget
            budget=(budget_snapshot if budget_snapshot is not None else decision_budget(host))['science_budget']
            methods[key]['action_prerequisites']=dict(candidate=reference,
                initial_state=dict(operating_point='standardized_initial_pretension',**window_facts(requirements,dict(actual_time_s=0.))),
                recorded_control_sources=bound_sources,
                required_agent_fields=['control_optimization.source','control_optimization.settings with explicit v2 window and knots'],
                unmet=['control_source_selection_required','explicit_search_settings_required'],
                callback_unit='cloned native sequence rollout; not a new independent physical replay',
                per_request_limits=spec.get('native_control_limits'),
                remaining_mathematical=budget['remaining_mathematical'],
                remaining_shared_physical=budget['remaining_physical'],
                remaining_replay_sublimit=budget['remaining_full_replays'],
                available_full_replays=budget['available_full_replays'],
                scope='Planning facts for this template, not execution permission or selected control. Saved-state requests resolve their actual origin and prefix at admission.')
            executions=[r for r in s.get('results',[]) if host.store.artifact(r).get('candidate')==reference]
            from tools.research.rl import measured_nmpc_trajectory
            for execution in reversed(executions):
                try:measured_nmpc_trajectory(host,execution,bind_model=False)
                except (ValueError,KeyError):continue
                methods[key]['measured_control_initialization']=dict(action='initialize_control',
                    control_seed=dict(candidate=reference,parent=reference,source=execution),
                    next='Use the returned explicit schedule as control_optimization.source or control_search.source. Full Plan/decision and normal admission required.',
                    scope='Measured applied NMPC tensions only, exact candidate/task/channels/grid/bounds; acceptance is not inherited.')
                break
            methods[key]['cost_scope']='Response search: S=starts, D_i=effective active coefficients in update i; callbacks = S baselines + sum(D_i FD probes + 1 candidate evaluation per completed update), all within evaluation_requests. Partial/failed callbacks also consume the cap; recorded counts own actual cost. Each suffix rollout advances (deadline-state_time)/physics_dt steps. Native cost.physics_steps includes required prefix reconstruction and all native rollouts. evaluation_callbacks and optimization_evaluations describe the same rollouts, not extra runs. Full independent physical_replay is separate with its own physics_steps; new_physical_evaluations=0 does not mean native integration was free.'
            from tools.research.scientific_intent import question_contract, ScientificQuestionV2
            if issubclass(question_contract(spec),ScientificQuestionV2):
                methods[key]['cost_scope']+=' control_search_effort independently selects method, knot_count, iterations and callback cap. Uniform knot times cover the chosen adjustment window; evaluation covers the full frozen task. Omitted iterations=min(callback cap, original/Study iteration caps); original early termination still applies.'
            else:
                methods[key]['cost_scope']+=' Explicit control_search_effort selects parameterization and finite effort within the current frozen grant. Legacy fixed-quota ScientificQuestion defaults retain their historical settings; unmetered mathematics defaults iterations to the chosen callback/Study limit. research_plan(control_search) uses independent physical replay callbacks with separate backend charges. Neither interface changes task constraints or makes focus_metric an objective override.'
            methods[key]['supported_task_families']=['task.reach','task.tracking:timed','task.position_tool_axis','task.oriented_tracking']
            methods[key]['supported_models']=['model.mujoco_native@1.0.0']
            methods[key]['kernel_supported']=row['planning_status']!='unsupported'
            methods[key]['control_sources']='Use this candidate\'s initialize_control baseline (pretension or explicit tensions), a bound mathematical schedule, or a complete current-Study NMPC actual-input result via source+parent without channel_map. New designs require explicit legal rebinding; a PPO checkpoint is not a schedule.'
            methods[key]['handoff']='physical_replay(candidate=same candidate, source=returned control_schedule_reference); independent acceptance and public evidence_read are required before SELECT.'
        if key=='short_input_response_v1':
            methods[key]['cost_scope']='One baseline + up to four FD rollouts per channel (two input sizes, central or one-sided) + optional one nonlinear candidate rollout. Required prefix reconstruction is already included in native cost.physics_steps; recorded rollouts/physics_steps own actual cost. Full independent physical_replay is additional if requested.'
        if key==CONIC:
            from tools.research.research_context import history_index
            methods[key]['previous_work']=[{k:r[k] for k in ('owning_study','evidence_scope','actual_result',
                'repeat_hint','experimental_equivalence','source')} for r in history_index(host,reference,request)
                if r['method']==key]
            methods[key]['repeat_guidance']='Read the original result and state what new information a repeat adds. Reproducibility, numerical checks and changed conditions are legitimate; this hint never vetoes execution. Configuration/request matching alone does not prove identical models, working points or controls.'
    from copy import deepcopy
    from tools.research.nonlinear_capability import METHODS, T1, T2, LIMITATIONS, candidate_responses
    for operation,method in METHODS.items():
        # Frozen old studies retain their existing catalog and authorization.
        if not spec.get('mathematical_methods',{}).get(method):continue
        item=deepcopy(methods['mujoco_direct_control_v1'])
        item.update(operation=operation,method=method,method_version=method,
            scientific_purpose='Finite-budget nonlinear task capability' if method==T1 else 'Reoptimized structural response',
            description='Limited-budget mathematical diagnostic; automatic physical ranking has not been validated.',
            limitations=LIMITATIONS,required_parameters=[r for r in item['required_parameters'] if not r.startswith('operating_point:')] if method==T1 else
                ['nonlinear_response={variable,unit,t1_results=[baseline,minus,plus]}'],
            cost_scope=item['cost_scope'] if method==T1 else 'One aggregation evaluation for admitted saved T1 results, zero new native models, optimizations or physics steps. Prior T1 charges remain referenced; actual preparation/worker wall time is additional.',
            request_template=dict(candidate=reference,operation=operation,model_source='mujoco',
                operating_point='standardized_initial_pretension',protocol=protocol),
            detail_query=dict(reference=reference,view='mathematical_capabilities',pointer='/methods/'+method))
        from tools.research.native_control import nonlinear_task_reason
        reason=nonlinear_task_reason(cfg['task']['family'])
        item['supported_task_families']=['task.reach']
        if reason:
            item.update(kernel_supported=False,full_task_supported=False,coverage=[],
                execution_status='blocked',planning_status='unsupported',applicable=False,executable=False,
                missing=[*item['missing'],reason],applicability=dict(status='not_applicable',reasons=[reason]))
            item.pop('action_prerequisites',None)
            methods[method]=item
            continue
        if method==T2:
            item['missing']=[m for m in item['missing'] if not m.startswith('control_optimization')]
            item['missing'].append('three comparable completed T1 results')
            for name in ('handoff','measured_control_initialization','control_sources','control_input_guidance','execution_limits','action_prerequisites'):
                item.pop(name,None)
            item['coverage']=[]
            item['applicability']=dict(status='requires_parameters',
                parameter_requirements=['nonlinear_response'],execution_support='saved_evidence_only')
            if binding_error is None and c.get('generation_version'):
                prepared=candidate_responses(host,reference)
                item.update(prepared)
                if prepared['batch_request']:
                    item['request_template']=prepared['batch_request']
                    item['missing']=[m for m in item['missing'] if m!='three comparable completed T1 results']
            item.update(registered=True,authorized=item['formal_execution_authorized'],
                applicable=bool(item.get('ready_requests')),executable=bool(item.get('ready_requests') and
                    item['formal_execution_authorized'] and (remaining is None or remaining>=1) and not closed))
            item['planning_status']=('unauthorized' if not item['authorized'] else 'blocked' if closed else
                'insufficient_budget' if remaining is not None and remaining<1 else 'ready' if item['executable'] else 'requires_comparable_t1_results')
            if item.get('ready_requests'):
                item['applicability'].update(status='applicable',parameter_requirements=[])
            item['execution_status']='conditional_on_admission' if item['executable'] else 'blocked'
            item['estimated_evaluations']=1
            item['required_parameters']=['nonlinear_response v1: {variable,unit,t1_results} OR v2: {version,directions}; read analysis_request_schema']
            item['action_prerequisites']=dict(candidate=reference,
                required_agent_fields=['nonlinear_response'],unmet=item['missing'],
                estimated_mathematical_evaluations=item['estimated_evaluations'],remaining_mathematical=remaining,
                callback_unit='saved T1 evidence aggregation; no new Native rollout or independent physical replay',
                scope='Comparable completed T1 sources and original request bindings are checked at admission; no new initial state or control window is selected.')
            item['sensitivity_evidence']='Per-sample fixed-control and best-found reoptimized secants when source rollout arrays exist. V2 directions optionally bind validation_coordinates and validation_t1_results excluded from the fitted stencil. Multiple scales share the same baseline; active-time switches and failed prediction checks remain unresolved.'

        methods[method]=item
    if mechanism_interface(spec):
        from tools.research.structure_research import METHOD
        item=deepcopy(methods['native_dynamics_v1'])
        authorized=bool(item['study_authorized'] and spec.get('mathematical_methods',{}).get(METHOD))
        item.update(method=METHOD,operation=METHOD,method_version=METHOD,
            scientific_purpose=METHOD_MEANINGS[METHOD][0],description=METHOD_MEANINGS[METHOD][1],
            study_authorized=authorized,formal_execution_authorized=authorized and item['formal_scope_authorized'],
            estimated_evaluations=1,estimated_evaluation_range=[1,64],
            cost_scope='Shared allowance: inspect=1, compare=2; differentiated paths use one common baseline plus their actual two-scale central/one-sided probes, plus a two-path joint check. optimize reserves its explicit bounded SciPy search cap. Saved prefix reconstruction has its original native cost.',
            required_parameters=['ScientificQuestionV2 operation, effect_semantics, registered target, point/control semantics and evaluation cap; candidate and task come from diagnose.'],
            request_template=dict(candidate=reference,operation=METHOD,model_source='mujoco',
                operating_point='standardized_initial_pretension',protocol=protocol),
            detail_query=dict(reference=reference,view='mathematical_capabilities',pointer='/methods/'+METHOD))
        if cfg['task'].get('physical_problem'):
            from tools.research.structure_research import finite_time_discovery
            capabilities=task_adapter(cfg).physical_capabilities()
            ready=authorized and item['formal_scope_authorized'] and not closed and not binding_error and (remaining is None or remaining>=1)
            ready=ready and capabilities['status']=='supported'
            item.update(planning_status='unsupported' if capabilities['status']=='unsupported' else 'insufficient_budget' if remaining is not None and remaining<1 else 'ready' if ready else 'blocked',execution_status='conditional_on_admission' if ready else 'blocked',
                description='Shared geometry, qualified unilateral equilibrium, active sets, re-equilibrated response and registered complete finite-time task response. Independent acceptance remains separate.',
                missing=[] if ready else ['original_scope_budget_or_candidate_admission'],
                applicable=True,executable=ready,registered_acceptance=task_adapter(cfg).execution_requirements()['registered_acceptance'],
                prerequisites=['Frozen passive assembly, load condition and material-point binding.'],
                finite_time_response=finite_time_discovery(cfg),
                required_parameters=['V4 operation, effect_semantics, matching target, frozen load selection and evaluation cap; registered paths for structural probes.'],
                coverage=[dict(constraint_id=r['constraint_id'],status='diagnostic_or_finite_time_conditional',expressible=False)
                    for r in task_adapter(cfg).dynamic_constraint_view()])
            item['applicability'].update(status='applicable',reasons=[],full_task_supported=False)
        if not authorized:
            item['planning_status']='unauthorized';item['execution_status']='blocked'
            item['missing']=[*item['missing'],'explicit_frozen_mechanism_method_grant_required']
        methods[METHOD]=item
        item['task_conditioned_query']=dict(reference=reference,view='mathematical_capabilities',pointer='/structure_research/task_conditioned_view')
        methods['native_dynamics_v1']['frontend_role']='internal_mechanism_source'
        item['internal_mechanics_query']=methods['native_dynamics_v1']['detail_query']
    for method,item in methods.items():
        item['generic_operations']=generic_operations(method)
        template=item['request_template']
        points=analysis_operating_points(method,item['operation'])
        item['already_bound']={k:template[k] for k in ('candidate','protocol','operation','capability_method') if k in template}
        if template.get('model_source')=='mujoco':item['already_bound']['model_source']='mujoco'
        if len(points)==1 and points[0]!='saved_state':item['already_bound']['operating_point']=points[0]
        item['required_sources']=item['prerequisites']
        if method=='fixed_input_structure_v1':
            item['required_sources']=['Current owned candidate and same-task legal comparable single-parameter structure candidates; Main must select them.',
                'Frozen initial state or exact candidate-bound saved_state / execution + update_id; equal physical inputs and comparison conditions.']
        elif method=='design_sensitivity':
            item['required_sources']=['Current candidate, minus_candidate and plus_candidate for one legal continuous variable; fixed physical input.']
        elif method in (T1,'mujoco_direct_control_v1'):
            item['required_sources']=['Current structure candidate is not a control source. control_optimization.source must reference a complete candidate/task/channel/time/bounds-bound executable sequence. If missing, use research_plan(initialize_control) baseline and its returned source; then resubmit diagnose. Main chooses method and settings.']
            from tools.research.tool_readiness import native_baseline_failures
            item['baseline_execution_admission']=dict(known_failures=native_baseline_failures(host,reference),
                rule='Exact unchanged failed baseline is blocked before another Worker or mathematical charge, across T1/Direct/objective changes. Other legal baselines remain selectable; contact-free Native applicability is unchanged.')
        elif method==T2:item['required_sources']=['Comparable completed same-task T1 results; original stencil admission applies.']
        item['request_template_query']={**item['detail_query'],'pointer':item['detail_query']['pointer']+'/request_template'}
        item['scientific_scope']=dict(computes=item['description'],
            model_sources=item.get('model_sources'),operating_points=analysis_operating_points(method,item['operation']),
            legal_sources='Exact owned candidate, model, physical input bounds, state provenance and frozen task/protocol; source admission remains mandatory.',
            task_quantities=item.get('coverage',[]),full_task_supported=item.get('full_task_supported',False),
            inference='Model-scoped mathematical evidence only after actual computation and validation. An intent or accepted request establishes no scientific result.',
            missing_evidence=item.get('missing',[]),requires_mathematical_execution=True,
            physical_acceptance='Independent registered task evaluation is required; no static, local or optimizer result substitutes for it.')
    if spec.get('research_decisions',{}).get('analysis_interface') in ('bound_scientific_variables_v1','bound_scientific_variables_v2'):
        from tools.research.research_context import research_intent
        intent=research_intent(host)['latest_decision'] or {}
        decision=(intent.get('agent_hypothesis') or {}).get('decision') or {}
        selected=decision.get('selected_method')
        if (intent.get('action')=='diagnose' and intent.get('execution_status')=='completed'
                and decision.get('selected_candidate')==reference and selected in methods and binding_error is None):
            methods[selected]['operating_point_guidance']=selected_operating_point_guidance(host,reference,selected,methods[selected])
    extra={}
    if mechanism_interface(spec):
        from tools.research.structure_research import parameters,discovery
        from extensions.math_analysis.mechanism_registry import catalog,mechanism_ids
        extra['structure_research']=dict(**discovery(spec,c,reference,method_detail=methods['mechanism_structure_v1'],remaining_evaluations=remaining),mechanisms=catalog(),parameters=parameters(spec,c),
            task_conditioned_view=task_adapter(cfg).structure_task_view(),
            selectable_mechanisms=mechanism_ids('passive_unilateral_equilibrium' if cfg['task'].get('physical_problem') else 'active_ideal_tension'),
            evaluation_rule='One common baseline, actual stencil coordinates per selected effective path, one joint check for two paths; bounded local SciPy search uses the requested cap.',method_query=methods['mechanism_structure_v1']['detail_query'],
            differentiation='Normalized linear/log coordinates; central or legal one-sided two-scale native differences, at most two actual continuous physical parameters. No strict derivative or descent certificate.',
            unsupported_parameter_kinds=dict(undeclared='Only the selected frozen FamilySpace generates parameter domains; absent density/damping fields are not assumed available.',
                controller='Controller weights and numerical resolution are outside structural mechanisms.',input_set='Tension limits change the feasible input set and require separate semantics.',
                topology='Counts/topology require discrete comparison; not ordinary differentiation.'),
            working_point_semantics=dict(frozen_task_initial_state='Each structure uses its task initializer and the same absolute tensions.',
                fixed_generalized_pose='Same named qpos, zero velocity; no Cartesian-pose or equilibrium mapping.',
                same_generalized_coordinates='Same named qpos/qvel, reset solver history.',
                saved_native_state='Actual owned checkpoint/prefix for baseline; perturbed structures transfer named qpos/qvel with reset history. Not preserved Cartesian physical state.'),
            working_point_sources=selected_operating_point_guidance(host,reference,'mechanism_structure_v1',methods['mechanism_structure_v1']),
            other_methods_query=dict(reference=reference,view='mathematical_capabilities',pointer='/methods'))
    return dict(**readiness,candidate=reference,methods=methods,**extra,
        operation_categories=dict(OPERATION_CATEGORIES),
        capability_statuses=dict(CAPABILITY_STATUS_MEANINGS),
        capability_inventory=capability_inventory(methods,reference),
        research_opportunities=mathematical_research_view(spec,c,reference,requirements,methods),
        scientific_interpretation=SCIENTIFIC_INTERPRETATION,
        analysis_request_schema=AnalysisRequest.model_json_schema())


def mathematical_action_view(detail):
    """Prioritize action fields of one original registered method; no new catalog."""
    import json
    keys=('method','operation','scientific_purpose','description','planning_status','missing',
        'required_parameters','required_sources','estimated_evaluations','estimated_evaluation_range','wall_cost',
        'cost_scope','formal_execution_authorized','execution_status','request_template_query','control_input_guidance')
    result={k:detail[k] for k in keys if k in detail}
    if detail.get('control_input_guidance'):
        guide=detail['control_input_guidance'];point=detail['action_prerequisites']['initial_state']
        result['scientific_inputs']=dict(
            control_source=dict(references=guide['recorded_sources'],role='Complete candidate/task/channel/grid/bounds-bound control sequence, not structure; unmeasured initialization is not scientific evidence.'),
            correction_window_s=dict(form='[start_s,end_s], not a duration scalar',
                required_interval_s=point['legal_correction_window_s'],source='native_control.window_facts: frozen task and native state'),
            knots_s='Main chooses ordered legal knot times within the interval. Later knots do not shorten the full T1 computation window. Control correction interval, knots and Reach/Hold scoring window are distinct.',
            method_margin='pattern requires safety_margin_fraction=0; positive margin requires compatible v2 response.',
            per_request_limits=detail.get('execution_limits'))
    row=detail['applicability']
    result['applicability']={k:row[k] for k in ('status','model','task_applicable','reasons') if k in row}
    result['applicability'].update(task_family=detail['task_family'],kernel_supported=detail['kernel_supported'])
    result['limitations']=['Mechanism diagnostics and task sensitivities remain model-scoped; independent task evaluation alone establishes acceptance.']
    query=detail['detail_query']
    fields=list(detail)
    result['full_detail_queries']=[{**query,'fields':fields[i:i+32]} for i in range(0,len(fields),32)]
    result['query_rule']='Keep view=mathematical_capabilities for all derived subpaths and fields. Explicit fields retrieve the original method object.'
    if len(json.dumps(detail['request_template'],ensure_ascii=False).encode())<=1000:
        result['request_template']=detail['request_template']
    result['next_submission']=dict(tool='research_plan',action='diagnose',
        available=detail['formal_execution_authorized'] and detail['planning_status'] not in ('unauthorized','unsupported','insufficient_budget','blocked'),
        after_completed_diagnose='research_analysis; original source, parameter and budget admission applies.')
    result['already_bound']=dict(fields=list(detail['already_bound']),
        query={**query,'pointer':query['pointer']+'/already_bound'})
    # Put the executable entry before large source/template objects in the
    # existing selected-facts handoff projection as well as the direct response.
    result={'next_submission':result.pop('next_submission'),**result}
    return result


def mathematical_research_view(spec, candidate, reference, requirements, methods):
    """Join existing FamilySpace paths, task constraints and method applicability.

    This is a read projection, not a parameter/metric registry or execution gate.
    Candidate compilation and the original method admission remain authoritative.
    """
    from tools.research.optimal_capability import family_analysis_parameters
    from tools.research.nonlinear_capability import T1, T2
    from tools.research.config import frozen_analysis_protocol
    parameters=(family_analysis_parameters(spec,candidate) if candidate.get('generation_version')
        in ('serial_family_generation_v1','serial_family_generation_v2') else [])
    constraints=plain(requirements)['constraints']
    metrics=[dict(metric_id=c['constraint_id'],constraint=c,
        sources=[dict(reference=reference,pointer='/configuration'+p) for p in c['provenance']],
        semantics='Frozen TaskAdapter constraint; mathematical coverage and independent task acceptance are separate.')
        for c in constraints]
    from tools.research_tasks import task_adapter
    dynamic=task_adapter(candidate['configuration']).dynamic_constraint_view()
    for row in dynamic:
        metrics.append(dict(metric_id=row['constraint_id'],constraint={**row,
            'signal':dict(name=row['signal']) if isinstance(row['signal'],str) else row['signal']},
            sources=[dict(reference=reference,pointer='/configuration'+p) for p in row['provenance']],
            semantics='Frozen dynamic evaluator or qualification gate; not an affine kernel constraint. Static mechanisms are auxiliary only.'))
    if T1 in methods:
        metrics.append(dict(metric_id='best_found_J',unit='1',method=T1,
            constraint_ids=[c['constraint_id'] for c in constraints],
            definition='Minimum observed maximum normalized signed constraint excess under the recorded native control search and budget.',
            source=dict(module='tools.research.nonlinear_capability',function='t1_summary'),
            result_pointer='/nonlinear_capability/best_found_J',
            limitations='Finite-budget model diagnostic; neither global optimum nor independent task acceptance.'))
    rows=[]
    for parameter in parameters:
        links=[]
        for method in parameter['applicable_mathematical_methods']:
            if method not in methods:continue
            detail=methods[method]
            coverage=detail.get('coverage',[])
            # T2 aggregates T1's frozen task quantities; it enforces no task itself.
            metric_ids=([c['constraint_id'] for c in constraints]+(['best_found_J'] if T1 in methods else []) if method==T2 and detail['kernel_supported'] else
                [c['constraint_id'] for c in coverage if c.get('status')!='not_applicable'])
            links.append(dict(method=method,metric_ids=metric_ids,
                planning_status=detail['planning_status'],request_query=detail['detail_query'],
                **(dict(source_method=T1,source_request_query=methods[T1]['detail_query']) if method==T2 and T1 in methods else {}),
                scope='Saved comparable T1 contrasts' if method==T2 else 'See method coverage and original admission'))
        rows.append({**parameter,'method_links':links,
            'sensitivity_scope':parameter_sensitivity_scope(parameter)})
    from tools.research.scientific_intent import explicit_actions, scientific_actions, parameter_catalog
    return dict(version='candidate_mathematical_research_v1',candidate=reference,
        **(dict(scientific_actions=scientific_actions(spec),parameter_catalog=parameter_catalog(spec,candidate)) if explicit_actions(spec) else {}),
        task_binding={**requirements.binding, 'task_family':candidate['configuration']['task']['family'],
            'canonical_task_identity':candidate.get('task_identity'),
            'condition_id':candidate.get('condition_id')},protocol=frozen_analysis_protocol(spec,candidate),
        parameters=rows,metrics=metrics,
        methods={key:dict(planning_status=detail['planning_status'],
            execution_status=detail['execution_status'],missing=detail['missing'],
            estimated_evaluations=detail['estimated_evaluations'],wall_cost=detail['wall_cost'],
            cost_scope=detail['cost_scope'],request_query=detail['detail_query']) for key,detail in methods.items()},
        fixed_conditions=['Frozen task condition and protocol, topology, nonselected parameters, material/load, initial state, input channels/bounds, time grid and control-search settings/budget; compare actual search opportunities.'],
        workflow='Main chooses hypothesis, parameters and legal contrasts. research_plan(diagnose) selects candidate/method; research_analysis binds frozen identities and separately admits the request. Read original results via evidence_read or research_investigate.',
        limitations=['Parameter continuity does not establish compiled perturbation candidates or a mathematical derivative.',
            'Method links identify declared parameter support; missing task, source, grant and budget prerequisites still block execution.',
            'No registered arbitrary mechanism metric is inferred from a task score.'])


def mathematical_opportunity_summary(view, *, observations=(), latest_result=None,
                                    control_sources=(), execution_block=None):
    """Bounded discovery from original applicability, never request admission.

    Relevance orders overlapping constraints and distinct scientific operation/
    model scopes. It neither diagnoses a cause nor selects a Plan or input.
    """
    research=view['research_opportunities'];rows=research['parameters']
    authorized=[p for p in rows if p['study_authorized'] and p['continuous_perturbation']
        and p['effective_in_current_execution']]
    constraints={m['metric_id']:m['constraint'] for m in research['metrics'] if 'constraint' in m}
    failed=[r for r in observations if r.get('passed') is False]
    focus=failed or list(observations) or [dict(constraint_id=k,passed=None) for k in constraints]
    ids={r['constraint_id'] for r in focus if r['constraint_id'] in constraints}
    signals={constraints[k]['signal']['name'] for k in ids}
    linked={}
    for parameter in rows:
        for link in parameter['method_links']:
            linked.setdefault(link['method'],set()).update(link['metric_ids'])
    ranked=[];unavailable={};unavailable_examples=[]
    for key,detail in view['methods'].items():
        if detail.get('frontend_role')=='internal_mechanism_source':continue
        status=detail['planning_status']
        # These are the original gate's verdicts, not a second applicability test.
        if execution_block or status in ('unauthorized','unsupported','insufficient_budget','blocked'):
            reason=execution_block or status;unavailable[reason]=unavailable.get(reason,0)+1
            if not unavailable_examples:
                unavailable_examples.append(dict(method=key,status=reason,
                    reasons=[execution_block] if execution_block else detail['missing'][:2],detail_query=detail['detail_query']))
            continue
        coverage={r['constraint_id'] for r in detail['coverage'] if r.get('status')!='not_applicable'}
        overlap=ids & (coverage | linked.get(key,set()))
        outputs=set(detail['applicability'].get('required_outputs',[]))
        rank=(len(overlap),bool(coverage and detail['full_task_supported']),len(signals & outputs),status=='ready')
        ranked.append((rank,key,detail,overlap))
    methods=[];seen=set()
    for _,key,detail,overlap in sorted(ranked,key=lambda r:r[0],reverse=True):
        categories=detail['generic_operations'];scope=detail['applicability'].get('model')
        kind=(tuple(sorted(categories)),scope,bool(detail['coverage'] and detail['full_task_supported']))
        if kind in seen:continue
        seen.add(kind)
        guide=detail.get('control_input_guidance') or {}
        sources=guide.get('recorded_sources',[]) or [r for r in control_sources
            if r.get('full_control_sequence') and not r.get('requires_initialization')]
        missing=list(dict.fromkeys(detail['missing']))
        if guide and not sources:missing.insert(0,'legal_control_source')
        methods.append(dict(method=key,purpose=detail['scientific_purpose'],
            generic_operations=categories,status=detail['planning_status'],
            execution_status=detail['execution_status'],readiness='request_preparation_available' if detail['planning_status']=='ready' and not missing else 'requires_inputs',
            request_admission='not_checked',missing=missing[:3],
            preparation={k:guide['baseline_initialization'][k] for k in ('tool','action','control_seed')} if guide and not sources else None,
            recorded_control_source_available=bool(sources) if guide else None,
            related_constraints=sorted(overlap),
            coverage='full_task_model' if detail['coverage'] and detail['full_task_supported'] else 'diagnostic_or_partial',
            estimated_evaluations=detail['estimated_evaluations'],wall_cost=detail['wall_cost'],
            detail_query=detail['detail_query']))
        if len(methods)==4:break
    return dict(version=research['version'],candidate=view['candidate'],
        task_binding={k:research['task_binding'].get(k) for k in ('task_family','condition_id')},
        operation_categories=list(OPERATION_CATEGORIES),
        status='research_requests_can_be_prepared' if methods else 'no_new_mathematical_request_available',
        current_focus=[dict(constraint_id=r['constraint_id'],signal=constraints[r['constraint_id']]['signal']['name'],
            status='violated' if r.get('passed') is False else 'satisfied_observation' if r.get('passed') is True else 'unmeasured',
            evidence_scope=r.get('scope','unmeasured'),source=r.get('source')) for r in focus if r['constraint_id'] in constraints][:3],
        latest_result=latest_result,unavailable_status_counts=unavailable,unavailable_examples=unavailable_examples,
        parameters=dict(total=len(rows),continuous_authorized=len(authorized),
            categories=sorted({p['category'] for p in authorized}),
            registered_categories=sorted({p['category'] for p in rows})),
        methods=methods,
        method_directory_query=dict(reference=view['candidate'],view='mathematical_capabilities',pointer='/methods'),
        full_catalog_query=dict(reference=view['candidate'],view='mathematical_capabilities',pointer='/capability_inventory'),
        detail_query=dict(reference=view['candidate'],view='mathematical_capabilities',pointer='/research_opportunities'),
        scope='Display order reflects constraint coverage, not cause or a required route. Other methods remain discoverable. Original authorization, source, scientific-input and budget admission still applies.')


def mathematical_catalog(view):
    """Small per-method facts; full instructions and native schemas stay reachable."""
    from tools.research.optimal_capability import SENSITIVITY
    rows={}
    shared_cost='Model preparation and internal solver attempts are distinct; see original receipts.'
    for row in view['methods'].values():
        item={k:row[k] for k in ('scientific_purpose','description','method_version','kernel_supported','model_built','full_task_supported','study_authorized',
            'formal_execution_authorized','execution_status','planning_status','missing','estimated_evaluations','cost_scope','supported_task_families','execution_limits',
            'registered','authorized','applicable','executable') if k in row}
        item['detail_pointer']='/methods/'+row['method']
        item['generic_operations']=generic_operations(row['method'])
        item['request_template_query']={**row['detail_query'],
            'fields':[k for k in ('candidate','operation','request_template','required_parameters',
                'formal_execution_authorized','missing','execution_limits','cost_scope','action_prerequisites') if k in row]}
        if row.get('action_prerequisites'):item['action_prerequisites']=row['action_prerequisites']
        if row.get('measured_control_initialization'):
            item['control_initialization_query']={**row['detail_query'],'pointer':item['detail_pointer']+'/measured_control_initialization'}
        if row['method']==SENSITIVITY and row.get('authorized') and 'missing_validated_model_stencil' in row['missing']:
            item['preparation_query']={**row['detail_query'],'pointer':item['detail_pointer']+'/readiness'}
            item['preparation_hint']='Authorized; model group not prepared. Read allowed variables, bounded h / h/2, generation/model requests and estimated math cost here; other missing items still apply.'
        item['coverage']=[{k:v for k,v in c.items() if k in ('constraint_id','status','expressible')} for c in row['coverage']]
        item['missing']=list(dict.fromkeys(item['missing']))
        if item.get('cost_scope')==shared_cost:item.pop('cost_scope')
        rows[row['method']]=item
    binding=next(iter(view['methods'].values()))
    return dict(version='mathematical_capability_catalog_v1',listed_methods_implemented=True,candidate=view['candidate'],task_identity=binding['task_identity'],task_family=binding['task_family'],
        operation_categories=dict(OPERATION_CATEGORIES),
        capability_inventory_query=dict(reference=view['candidate'],view='mathematical_capabilities',pointer='/capability_inventory'),
        detail_query=dict(reference=view['candidate'],view='mathematical_capabilities',pointer='/methods'),
        schema_query=dict(reference=view['candidate'],view='mathematical_capabilities',pointer='/analysis_request_schema'),
        formal_scope_authorized=binding['formal_scope_authorized'],model_sources=binding['model_sources'][-1:],cost_scope=shared_cost,
        limitations=['Candidate-bound planning only; all model/state/input/protocol and remaining-budget admission checks still apply.',
            'Agent selected_method is proposal text, not execution admission. Unlisted combinations have no registered executable template; even listed methods require request-specific admission.',
            'Local sampled numerical evidence does not prove physical acceptance or strict/global optimality.'],methods=rows)


def analysis_capabilities(configuration, requirements, protocol, *, model=None, exact_point=None,
                          remaining_evaluations=None, mathematical_methods=None):
    """Candidates for existing operations, using the same execution applicability gate."""
    from types import SimpleNamespace
    from typing import get_args
    from tools.research.contracts import AnalysisRequest,NativeAnalysisOptions,NativeStructureResponse
    from schemas.platform_analysis import TaskAnalysisProtocol
    from schemas.platform import SessionInput
    configuration=SessionInput.model_validate(configuration)
    p=TaskAnalysisProtocol.model_validate(protocol)
    rows=[]
    for operation in get_args(AnalysisRequest.model_fields['operation'].annotation):
        if operation in ('mujoco_nonlinear_task_capability_v1','mujoco_reoptimized_structure_response_v1','mechanism_structure_v1'):continue
        native=operation in ('native_dynamics_v1','short_input_response_v1','fixed_input_structure_v1','mujoco_direct_control_v1')
        sampled=operation in ('trajectory_feasibility','task_capability','mujoco_direct_control_v1')
        static=operation in ('equilibrium','input_sensitivity','design_sensitivity')
        point='standardized_initial_pretension' if native else 'target_equilibrium' if operation=='equilibrium' else 'fixed_input_equilibrium' if static else 'controller_start_input'
        if exact_point and not static:point='saved_state'
        query=SimpleNamespace(operation=operation,operating_point=point,protocol=p,
            scoring_window_s=p.windows_s[0] if p.windows_s else None,
            native=NativeAnalysisOptions() if native else None,control_optimization=None)
        parameters=[]
        if operation=='fixed_input_structure_v1':
            parameters=['structure_response.variable: choose a legal continuous structure variable',
                'structure_response.candidates: select owned same-task legal comparable single-parameter candidates']
        if operation=='design_sensitivity':
            parameters=['design_sensitivity.variable','design_sensitivity.step',
                'design_sensitivity.minus_candidate','design_sensitivity.plus_candidate']
        if operation=='mujoco_direct_control_v1':
            # Probe only required coverage, not a fabricated executable source or search settings.
            start=(exact_point or {}).get('actual_time_s',0.)
            query.control_optimization=SimpleNamespace(settings=SimpleNamespace(correction_window_s=[start,requirements.duration_s]))
            parameters=['control_optimization.source','control_optimization.settings (version=local_control_search_v2, explicit correction_window_s and knots_s)']
        assessment=model_assessment(configuration,requirements,operation,model=model,model_source='mujoco' if native else 'controller')
        applicability=check_analysis_applicability(requirements,query,assessment,model,exact_point)
        reasons=list(applicability['reasons'])
        if operation=='instantaneous_braking_v1' and exact_point is None:
            reasons.append('Exact saved state required.')
        planning='unsupported' if reasons else 'requires_parameters' if parameters else 'ready'
        count=3 if operation in ('design_sensitivity','fixed_input_structure_v1') else 1
        evaluation_range=[count,count]
        if operation=='fixed_input_structure_v1':
            comparison=NativeStructureResponse.model_json_schema()['properties']['candidates']
            evaluation_range=[1+comparison['minItems'],1+comparison['maxItems']]
        budget=None if remaining_evaluations is None else remaining_evaluations>=evaluation_range[0]
        if budget is False:reasons.append('Insufficient mathematical evaluation budget.')
        rows.append(dict(operation=operation,status='not_applicable' if reasons else 'requires_parameters' if parameters else applicability['status'],
            planning_status='unsupported' if planning=='unsupported' else 'insufficient_budget' if budget is False else planning,
            parameter_requirements=parameters,
            reasons=reasons,model=assessment['model_id'],
            constraint_kinds=['norm_bound','component_interval'] if sampled else ['norm_bound'],
            required_outputs=sorted({c.signal.name for c in requirements.constraints}) if sampled else
                ['tip_velocity'] if operation in ('braking','instantaneous_braking_v1') else ['tip_position'],
            category='native_control_diagnostic' if operation=='mujoco_direct_control_v1' else 'task_capability_estimate' if operation=='task_capability' else 'sampled_feasibility' if sampled else 'diagnostic',
            control='bounded native sequence reoptimization' if operation=='mujoco_direct_control_v1' else 'reoptimized; optional fixed baseline replay' if operation=='task_capability' else
                'bounded sequence search' if sampled or operation in ('endpoint','braking') else 'operating-point diagnostic',
            prerequisites=['candidate','frozen protocol',point]+(['paired structure candidates'] if operation in ('design_sensitivity','fixed_input_structure_v1') else []),
            time_scope='aligned post-step samples over actual remaining horizon' if sampled else
                'static operating point' if static else 'declared local scoring window or exact instant',
            coverage=applicability['constraint_coverage'],full_task_supported=applicability['full_task_supported'],
            budget_allowed=budget,evaluations=count,evaluation_range=evaluation_range,wall_cost='unknown',
            limitations=['Model-scoped calculation; independent physical acceptance required.',
                'Final admission checks candidate, exact state, numerical time budget and constructed outputs.']))
    if mathematical_methods:
        from tools.research.optimal_capability import CONIC,SENSITIVITY,dependencies,conic_subproblems
        env=dependencies()
        path=next((c for c in requirements.constraints if c.kind=='path_bound'),None)
        subproblems=conic_subproblems(requirements)
        for method in (CONIC,SENSITIVITY):
            count=1+subproblems if method==CONIC else 3*subproblems+2
            reasons=[]
            if not mathematical_methods.get(method) or not mathematical_methods.get(CONIC):reasons.append('method_not_authorized')
            if not env['available']:reasons.append('worker_dependency_unavailable')
            if remaining_evaluations is not None and remaining_evaluations<count:reasons.append('insufficient_budget')
            if method==SENSITIVITY:reasons.append('candidate_variable_and_saved_model_stencil_validation_required')
            query=SimpleNamespace(operation='task_capability',operating_point='controller_start_input',
                protocol=p,scoring_window_s=None,capability_method=CONIC)
            fit=check_analysis_applicability(requirements,query,model_assessment(configuration,requirements,'task_capability',model),model)
            reasons.extend(fit['reasons'])
            rows.append(dict(operation='task_capability',capability_method=CONIC,
                submode='optimal_sensitivity' if method==SENSITIVITY else None,
                method_version=('sampled-affine-conic-path-progress-v1' if method==CONIC else 'controlled-path-progress-sensitivity-v1') if path is not None else method,
                status='not_applicable' if reasons else 'conditional',reasons=reasons,dependency_environment=env,
                task_applicable=fit['status']!='not_applicable',
                planning_status='unauthorized' if 'method_not_authorized' in reasons else 'unsupported' if fit['reasons'] or not env['available'] else
                    'insufficient_budget' if 'insufficient_budget' in reasons else 'requires_parameters' if method==SENSITIVITY else 'ready',
                evaluations=count,evaluation_rule=(f'One model build plus {subproblems} internal conic subproblems' if method==CONIC else f'(1+2*k)*{subproblems}+2*k kernel/dual-face solves for k central step sizes; existing models required'),
                **(dict(kernel_subproblems_per_model=subproblems) if path is not None else {}),
                **(dict(coverage=fit['constraint_coverage'],full_task_supported=fit['full_task_supported']) if fit is not None else {}),
                remaining_evaluations=remaining_evaluations,
                budget_allowed=None if remaining_evaluations is None else remaining_evaluations>=count,
                prerequisites=['Current owned candidates, applicable task/model, frozen protocol and explicit method grant']+
                    (['Single authorized parameter; model_results baseline first; explicit steps; all model bindings checked'] if method==SENSITIVITY else []),
                limitations=['Floating numerical checks only; no strict optimum, gradient or physical acceptance.']))
    return rows


def describe_analysis_requirements(configuration, binding):
    return task_adapter(configuration).analysis_requirements(binding)


def endpoint_target(requirements, protocol, *, braking=False):
    """Project only declared terminal norm conditions into the existing kernel."""
    from schemas.platform_analysis import EndpointTarget
    last=len(requirements.time_grid_s)-1
    def terminal(name):
        return [c for c in requirements.constraints if c.kind=='norm_bound'
                and c.signal.name==name and last in c.indices
                and (c.signal.entity,c.signal.units,c.signal.frame,c.signal.dimension,c.signal.phase)==
                    ('tip','m' if name=='tip_position' else 'm/s','world',3,'post_step')]
    positions=terminal('tip_position');velocities=terminal('tip_velocity')
    if not positions or (braking and not velocities):
        raise ValueError('Terminal norm position (and velocity for braking) conditions required; path progress is not a fixed endpoint problem.')
    def select(rows):
        references=[c.reference[c.indices.index(last)] for c in rows]
        if any(r!=references[0] for r in references):
            raise ValueError('Endpoint kernel requires one consistent terminal reference per output.')
        return references[0],min(c.radius for c in rows)
    position,radius=select(positions)
    args=dict(position_m=position,position_tolerance_m=radius,position_scale_m=protocol.output_scale_m)
    if velocities:
        velocity,limit=select(velocities)
        args.update(tip_velocity_m_s=velocity,tip_speed_limit_m_s=limit)
    return EndpointTarget(**args)


def model_assessment(configuration, requirements, operation,model=None,model_source='controller'):
    """Use the same GVS model binding as the candidate linearization builder."""
    if model_source=='mujoco' or configuration.task.physical_problem:
        from tools.research.native_analysis import assessment
        return assessment(configuration,requirements)
    from extensions.tendon_family.model_applicability import assess_model_uses
    from tools.platform_registry import registry
    saved_model=model is not None
    use = 'static_equilibrium' if operation in ('equilibrium','input_sensitivity','design_sensitivity') else 'linearization'
    model = Binding(extension_id='model.gvs', version='1.0.0', parameters=Payload(
        contract='family.gvs_model', data=dict(basis=configuration.policy.controller.parameters.data['recipe']['basis'])))
    if model_source=='sorosim' or (model_source=='controller' and configuration.policy.controller.extension_id == 'controller.sorosim_matlab_nmpc'):
        model = Binding(extension_id='model.sorosim_gvs',version='1.0.0',parameters=Payload(
            contract='family.sorosim_model',data=dict(basis=configuration.policy.controller.parameters.data['recipe']['basis'])))
    reg = registry()
    declaration = reg.mathematical_model(model)
    assessment = plain(assess_model_uses(configuration.robot, configuration.task, model, [use],
        required_physics={use:requirements.required_physics}, registry=reg))
    declared = {name for name, supported in plain(declaration.capabilities).items() if supported}
    unknown = set(requirements.required_physics)-set(declaration.unsupported_physics)-declared
    if unknown:
        assessment['uses'][use]['status'] = 'REJECT'
        assessment['uses'][use]['reasons'].append('Required physics has no declared capability: '+', '.join(sorted(unknown)))
    if model_source=='controller' and configuration.policy.controller.extension_id not in ('controller.gvs_nmpc','controller.sorosim_matlab_nmpc'):
        assessment['uses'][use]['status']='REJECT'
        assessment['uses'][use]['reasons'].append('No candidate model preparation implemented for this controller configuration.')
    reference=task_adapter(plain(configuration)).control_reference()
    preparation=[]
    if model_source=='sorosim' and 'solver' not in configuration.policy.controller.parameters.data:
        preparation.append('Explicit SoRoSim needs frozen SoRoSim solver settings; no settings are fabricated from another controller.')
    if not saved_model:
        control=configuration.policy.controller.parameters.data
        if control['recipe'].get('reference_mode','constant')!=reference['kind']:
            preparation.append('Candidate initializer preparation requires a controller recipe matching the task reference kind.')
        if assessment['model_id']=='model.sorosim_gvs' and reference['kind']!='constant':
            preparation.append('Current SoRoSim preparation requires a constant target working point; dynamic-reference preparation is not implemented.')
        if reference['kind']!='constant' and (configuration.policy.controller.extension_id,configuration.policy.controller.version)!=('controller.gvs_nmpc','12.0.0'):
            preparation.append('Dynamic-reference candidate preparation requires the registered GVS 12.0.0 recipe.')
    if preparation:
        assessment['uses'][use]['status']='REJECT'
        assessment['uses'][use]['reasons'].extend(preparation)
    if use=='static_equilibrium' and reference['kind']!='constant' and operation=='equilibrium':
        assessment['uses'][use]['status']='REJECT'
        assessment['uses'][use]['reasons'].append('Target-equilibrium construction assumes a constant target; a timed or free-progress reference supplies no static working point.')
    return assessment


def check_analysis_applicability(requirements, query, assessment, model=None, exact_point=None):
    """Describe partial terminal coverage separately from diagnostics and execution.

    Preflight output signatures are the fixed EndpointOutputLinearization exports
    of tendon_family.math_analysis.linear_model; constructed models are checked
    again using their actual outputs before metrics/endpoint computations.
    """
    if requirements.horizon_semantics=='static_load_cases' and query.operation!='mechanism_structure_v1':
        return dict(status='not_applicable',reasons=['PASSIVE_REQUIRES_REGISTERED_CONSTRAINED_MECHANISM_METHOD'],
            constraint_coverage=[],full_task_supported=False)
    if assessment['model_id']=='model.mujoco_native':
        from tools.research.native_analysis import applicability
        return applicability(requirements,query,assessment,exact_point)
    reasons = [reason for verdict in assessment['uses'].values() if verdict['status'] == 'REJECT'
               for reason in verdict['reasons']]
    if requirements.binding.get('task_family') in ('task.position_tool_axis','task.oriented_tracking'):
        reasons.append('Position/tool-axis mathematical analysis is not_applicable for existing affine/GVS methods; use the native sequence response with both real constraints.')
    if query.operating_point in ('target_equilibrium','halfway_waypoint'):
        positions=[c for c in requirements.constraints if c.signal.name=='tip_position']
        if any(c.kind!='norm_bound' for c in positions) or len({tuple(r) for c in positions for r in c.reference})!=1:
            reasons.append('Static target/halfway construction requires a single constant position reference, not a moving reference or free path progress.')
    if query.operation in ('endpoint','braking'):
        try:endpoint_target(requirements,query.protocol,braking=query.operation=='braking')
        except ValueError as exc:reasons.append(str(exc))
    if (query.operation in ('input_sensitivity','design_sensitivity') or query.operating_point=='fixed_input_equilibrium') and assessment['model_id']!='model.sorosim_gvs':
        reasons.append('Static IFT v1 is implemented only by the SoRoSim provider.')
    outputs = {'tip_position':('m', 'world', 3), 'tip_velocity':('m/s', 'world', 3)}
    if model is not None:
        if model.binding.get('task_identity')!=requirements.binding['task_identity']:
            reasons.append('Saved model must bind the exact task identity.')
        outputs = {o.name:(o.units, o.frame, o.dimension) for o in model.endpoint_outputs}
    p = query.protocol
    if abs(p.duration_s-requirements.duration_s) > p.horizon_alignment_atol_s:
        reasons.append('Protocol duration differs from the frozen task horizon.')
    if abs(p.period_s-requirements.physical_inputs['control_period_s']) > p.horizon_alignment_atol_s:
        reasons.append('Protocol period differs from the frozen physical input grid.')
    point = model.operating_point if model is not None else exact_point or {}
    trajectory = query.operation in ('trajectory_feasibility', 'task_capability')
    sampled = None
    if trajectory:
        from extensions.math_analysis.trajectory import time_scope
        start = point.get('actual_time_s', point.get('time_s'))
        if start is None and query.operating_point in ('standardized_initial_pretension','controller_start_input'):
            start = 0.
        try:
            sampled = time_scope(requirements, p, start)
        except ValueError as exc:
            reasons.append(str(exc))
        paths=[c for c in requirements.constraints if c.kind=='path_bound']
        if len(paths)>1 or any(len(c.path_vertices_m) not in (2,3) for c in paths):
            reasons.append('Current free-progress kernel supports exactly one path with one or two straight segments.')
        if paths and sampled is not None and (sampled['start_time_s']!=0
                or any(c.indices!=list(range(len(requirements.time_grid_s))) for c in paths)):
            reasons.append('Free path progress requires the complete declared initial horizon; saved partial paths need separate prefix evidence.')
        if any(len(c.path_vertices_m)==3 and len(c.indices)<3 for c in paths):
            reasons.append('A path corner requires an interior analysis sample.')
    remaining = point.get('remaining_task_s', requirements.duration_s)
    horizon = query.scoring_window_s if query.operation in ('linearization','controllability') else remaining
    instantaneous=query.operation=='instantaneous_braking_v1'
    if instantaneous:horizon=0.
    if query.operation != 'equilibrium' and not trajectory and not instantaneous and (horizon is None or horizon <= 0 or horizon > remaining+p.horizon_alignment_atol_s
            or abs(round(horizon/p.period_s)*p.period_s-horizon) > p.horizon_alignment_atol_s):
        reasons.append('Positive aligned horizon within actual remaining task time is required.')
    if model is not None:
        inputs = requirements.physical_inputs
        if (model.time_domain != 'continuous'
                or any((s.name,s.units,s.frame) != ('tendon_tension','N','tendon_path') for s in model.input_definition)
                or model.binding.get('tendon_order') != inputs['tendon_order']
                or model.binding.get('tension_limits_n') != inputs['upper']
                or len(model.u0) != len(inputs['upper'])
                or any(not lo <= u <= hi for lo,u,hi in zip(inputs['lower'],model.u0,inputs['upper']))):
            reasons.append('Model physical input order, bounds, or operating input mismatch.')
    last = len(requirements.time_grid_s)-1
    coverage = []
    for c in requirements.constraints:
        status, indices, reason = 'not_applicable', [], 'Existing tools do not enforce this constraint kind or sampled window.'
        signature = (c.signal.units, c.signal.frame, c.signal.dimension)
        if c.kind == 'unsupported':
            reason = 'Unsupported requirement retained verbatim; no compatible mathematical tool.'
        elif outputs.get(c.signal.name) != signature or c.signal.phase != 'post_step' or c.signal.entity!='tip':
            reason = 'Output identity, units, frame, dimension, or sampling phase is not exposed by this analysis.'
        elif instantaneous:
            status,reason='diagnostic','Instantaneous speed derivative only; no frozen task samples verified.'
        elif query.operation in ('linearization','controllability','equilibrium','input_sensitivity','design_sensitivity'):
            if c.signal.name == 'tip_position' and c.kind in ('norm_bound','path_bound'):
                status, reason = 'diagnostic', 'Local position authority/static construction only; no sampled constraint verification.'
        elif trajectory and c.kind=='path_bound' and getattr(query,'capability_method',None)!='sampled-affine-conic-minimax-v1':
            reason='Free progress requires the conic path formulation; fixed-reference SLSQP is not substituted.'
        elif trajectory and c.kind in ('norm_bound','component_interval','path_bound') and sampled is not None:
            indices = [i for i in c.indices if i in sampled['sample_steps']]
            if indices:
                status = 'applicable' if indices == c.indices else 'partial'
                reason = 'Shared held-input trajectory; past samples require separate evidence.'
        elif c.kind == 'norm_bound':
            if c.signal.name == 'tip_position' and last in c.indices:
                status, indices, reason = ('applicable' if c.indices==[last] else 'partial'), [last], 'Terminal position only under bounded local affine dynamics.'
            elif query.operation == 'braking' and c.signal.name == 'tip_velocity' and last in c.indices:
                status, indices, reason = 'partial', [last], 'Terminal speed only; other holding samples are not checked.'
        coverage.append(dict(constraint_id=c.constraint_id, expressible=c.kind != 'unsupported',
            status=status, analyzed_indices=indices, reason=reason))
        if trajectory:
            coverage[-1]['unchecked_indices'] = [i for i in c.indices if i not in indices]
    available = any(c['status'] != 'not_applicable' for c in coverage)
    if not available:
        reasons.append('No constraint has a compatible operation; no unrelated calculation will run.')
    if reasons:
        coverage = [{**c, 'status':'not_applicable', 'analyzed_indices':[],
                     'reason':'; '.join(reasons)+' '+c['reason']} for c in coverage]
        if trajectory:
            for c, source in zip(coverage, requirements.constraints):
                c['unchecked_indices'] = source.indices
    return dict(status='not_applicable' if reasons else 'applicable', reasons=reasons,
        path_scope=('Free progress within a chosen numerical horizon; sampled corner visits, not unrestricted-time infeasibility or independent geometric acceptance'
            if any(c.kind=='path_bound' for c in requirements.constraints) else None),
        constraint_coverage=coverage, full_task_supported=bool(trajectory and not reasons and sampled['start_time_s'] == 0.
            and all(c['status'] == 'applicable' for c in coverage) and not any(c.kind=='path_bound' for c in requirements.constraints)), execution_support='not_assessed',
        model_assessment=assessment, horizon=dict(task_duration_s=requirements.duration_s,
            remaining_task_s=remaining, analysis_horizon_s=None if query.operation == 'equilibrium' else horizon,
            period_s=p.period_s, origin=point.get('actual_time_s'),
            interpretation='static construction' if query.operation == 'equilibrium' else
                'Actual saved-state remaining horizon, or nominal horizon from the declared configuration operating point.',
            **({'trajectory_grid':sampled} if trajectory else {})))
