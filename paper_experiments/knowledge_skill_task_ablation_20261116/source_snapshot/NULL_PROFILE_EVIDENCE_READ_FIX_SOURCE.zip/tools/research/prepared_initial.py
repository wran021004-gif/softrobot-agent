"""Qualify a supplied equilibrium using static mj_forward; never find one."""
from copy import deepcopy
from pathlib import Path
import numpy as np
from pydantic import Field,FiniteFloat
from schemas.common import Contract
from schemas.platform import EvidenceRef,Payload,SessionInput
from tools.platform_store import plain
from tools.state_io import digest


class QualifyInitial(Contract):
    configuration: EvidenceRef
    qpos_rad: dict[str,FiniteFloat]
    tensions_n: dict[str,FiniteFloat]


def static_binding(configuration):
    cfg=configuration.model_dump(mode='json') if hasattr(configuration,'model_dump') else configuration
    return digest(dict(robot=cfg['robot'],discretization=cfg['policy']['discretization'],environment=cfg['task']['environment'],reference=cfg['task']['goal']))


def configuration_for_qualification(configuration):
    from tools.task_protocols import load
    case=load('T04').cases[0];cfg=deepcopy(configuration);cfg['task']=deepcopy(case.task)
    cfg['task']['acceptance']=plain(case.acceptance)
    cfg['task']['environment']['data']['physical_environment']=plain(case.environment_extension)
    return cfg


def qualify(configuration,qpos_rad,tensions_n,path):
    import mujoco
    from extensions.tendon_family.backends import physics_for
    from extensions.tendon_family.scene import assemble_physical
    from extensions.tendon_family.mjcf import compile_xml,load_model
    from tools.platform_registry import registry
    cfg=SessionInput.model_validate(configuration_for_qualification(configuration));p=physics_for(cfg)
    if set(qpos_rad)!=set(p['dofs']) or set(tensions_n)!={t['entity'] for t in p['tendons']}:
        raise ValueError('COMPLETE_NAMED_EQUILIBRIUM_STATE_AND_TENSIONS_REQUIRED')
    scene=assemble_physical(cfg,p);scene['control']=dict(tension_execution_mode='ideal_tension')
    compile_xml(p,scene,registry().parse(cfg.policy.backend.parameters),path)
    model=load_model(path=path);data=mujoco.MjData(model)
    qi=[model.jnt_qposadr[model.joint(j).id] for j in p['dofs']]
    aids=[model.actuator(t['entity']+'_direct_tension').id for t in p['tendons']]
    data.qpos[qi]=[qpos_rad[j] for j in p['dofs']]
    u=np.asarray([tensions_n[t['entity']] for t in p['tendons']]);data.ctrl[aids]=u
    limits=model.actuator_ctrlrange[aids]
    if not np.isfinite(u).all() or np.any(u<limits[:,0]) or np.any(u>limits[:,1]):raise ValueError('PREPARED_TENSIONS_OUTSIDE_FROZEN_BOUNDS')
    mujoco.mj_forward(model,data)
    residual=float(abs(data.qfrc_passive+data.qfrc_actuator-data.qfrc_bias).max())
    bound=cfg.task.acceptance.parameters['initial_static_balance_max_nm']
    checks=dict(static_balance=residual<=bound,no_contacts=data.ncon==0,no_warnings=not any(w.number for w in data.warning),
        finite=all(np.isfinite(v).all() for v in (data.qpos,data.qvel,data.qacc)),
        joint_limits=all(not model.jnt_limited[j] or model.jnt_range[j,0]<=data.qpos[model.jnt_qposadr[j]]<=model.jnt_range[j,1] for j in range(model.njnt)),
        actual_tension=np.allclose(-data.actuator_force[aids],u,rtol=0,atol=1e-10))
    return dict(version='prepared_initial_v1',qualified=all(checks.values()),checks={k:bool(v) for k,v in checks.items()},
        static_binding=static_binding(cfg),physics_identity=p['identity'],qpos_rad=qpos_rad,
        qvel_rad_s={j:0. for j in p['dofs']},tensions_n=tensions_n,static_balance_inf_nm=residual,static_balance_limit_nm=bound,
        native_forward_evaluations=1,optimization_calls=0,physics_steps=0,
        scope='Static qualification of supplied state and absolute tensions. No state construction, search or trajectory acceptance.')


def run(ctx,args):
    current=ctx.store.session(ctx.run_id)['state'];charged=False
    if 'spec' in current:
        from tools.research.state import guard
        from tools.research.budget import mathematics_fits
        guard(ctx.host,True)
        with ctx.store.transaction() as db:
            state=ctx.store.session(ctx.run_id,db)['state']
            if not mathematics_fits(state['spec'],state.get('mathematical_evaluations',0),1):
                raise ValueError('STATIC_QUALIFICATION_MATHEMATICAL_BUDGET_EXHAUSTED')
            state['mathematical_evaluations']=state.get('mathematical_evaluations',0)+1
            ctx.store.update_state(db,ctx.run_id,state);charged=True
    result=qualify(ctx.artifact(args.configuration),args.qpos_rad,args.tensions_n,ctx.folder/'initial_model.xml')
    result['charged_mathematical_evaluations']=int(charged)
    return Payload(contract='task.prepared_initial',data=result)


def validate(store,configuration):
    cfg=configuration.model_dump(mode='json') if hasattr(configuration,'model_dump') else configuration
    task=cfg['task']
    if (task.get('acceptance') or {}).get('evaluator')!='figure_eight':return
    initial=task['initializer']['parameters']['data'];ref=initial.get('qualification')
    if not ref:raise ValueError('QUALIFIED_INITIAL_EVIDENCE_REQUIRED_BEFORE_PHYSICAL_EXECUTION')
    value=store.artifact(ref)
    prepared=value.get('data',{})
    if (value.get('contract')!='task.prepared_initial' or prepared.get('qualified') is not True
            or prepared.get('static_binding')!=static_binding(cfg)
            or any(initial.get(k)!=prepared.get(k) for k in ('qpos_rad','qvel_rad_s','tensions_n'))):
        raise ValueError('PREPARED_INITIAL_EVIDENCE_STATE_OR_MODEL_MISMATCH')
