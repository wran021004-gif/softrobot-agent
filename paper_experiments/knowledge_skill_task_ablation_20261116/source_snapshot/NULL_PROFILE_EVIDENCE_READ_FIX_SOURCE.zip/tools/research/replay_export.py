"""Store-derived replay material; export never invokes or automatically retries tools."""
from collections import defaultdict
from contextlib import contextmanager,closing
import time
import json
from typing import Literal
from schemas.common import Contract
from schemas.platform import Payload, EvidenceRef
from pydantic import Field
from tools.platform_store import plain,now
from tools.state_io import digest

UNAVAILABLE='unavailable'


def task_binding(task):
    catalog_id=(task.get('acceptance') or {}).get('task_id')
    protocol_hash=digest(task)
    if catalog_id:
        from tools.task_protocols import load
        protocol_hash=digest(plain(load(catalog_id)))
    return dict(task_id=catalog_id or task['task_id'],runtime_task_id=task['task_id'],
        task_protocol_hash=protocol_hash,bound_task_identity=digest(task))


class Decision(Contract):
    research_question: str = Field(min_length=1,max_length=2000)
    rationale_summary: str = Field(min_length=1,max_length=2000,description='Brief auditable decision summary; no private chain of thought.')
    selected_tool: str
    next_operation: str
    evidence: list[EvidenceRef] = Field(default_factory=list)


class ReplayRequest(Contract):
    include_outputs: bool = True


def record_decision(ctx,args):
    value=dict(version='research_decision_v1',event_id=ctx.row['execution_id'],study_id=ctx.run_id,
        **task_binding(plain(ctx.input.task)),actor=ctx.host.actor,timestamp=now(),**plain(args))
    ref=ctx.save_artifact(value,'research_decision')
    return Payload(contract='trace.decision',data=dict(reference=plain(ref),record=value))


def types(value):
    if isinstance(value,dict):return {k:types(v) for k,v in value.items()}
    if isinstance(value,list):return [types(v) for v in value]
    if value is None:return 'null'
    if isinstance(value,bool):return 'boolean'
    return 'integer' if isinstance(value,int) else 'number' if isinstance(value,float) else 'string'


def record_invocation(host,request,receipt,wall_s,cpu_s,*,started_at=None):
    """Host wrapper, including rejections and failures; idempotent request IDs."""
    request=plain(request)
    if not isinstance(request,dict):request=dict(invalid_envelope=request)
    existing=host.store.events(host.run_id)
    if any(e['kind']=='tool_replay_record' and e['request_id']==request.get('request_id') for e in existing):return
    try:definition=host.reg.get(request['tool_id'],request.get('tool_version','1.0.0'),'tool')
    except (KeyError,ValueError):definition=None
    snap=host.store.session(host.run_id)['snapshot'];out=receipt.get('output')
    value=dict(version='tool_replay_record_v1',timestamp=started_at or UNAVAILABLE,completed_at=now(),actor=host.actor,study_id=host.run_id,
        **task_binding(snap['input']['task']),
        request=request,parameter_types=types(request.get('arguments',{})),
        input_schema=definition.input_schema.model_json_schema() if definition else UNAVAILABLE,
        expected_output_type=definition.output_schema.__name__ if definition else UNAVAILABLE,
        output_schema=definition.output_schema.model_json_schema() if definition else UNAVAILABLE,
        model_binding=snap['input']['policy'].get('dynamics_model'),robot_identity=digest(snap['input']['robot']),
        receipt=receipt,output_reference=out,resources=dict(wall_clock_s=wall_s,host_process_cpu_s=cpu_s,
            worker_cpu_s=UNAVAILABLE,mathematical_evaluations=UNAVAILABLE,optimization_iterations=UNAVAILABLE,
            physics_steps=UNAVAILABLE,physical_launches=UNAVAILABLE,independent_verification=UNAVAILABLE),
        scope='Actual Host invocation; CPU covers this process only. Charged budget is distinct from measured resource dimensions.')
    if out:
        output=host.store.artifact(out)
        data=output.get('data',{}).get('data',{}) if isinstance(output,dict) else {}
        if 'numerical_steps' in data:
            value['resources']['physics_steps']=0 if receipt.get('cache_hit') else data['numerical_steps']
            value['resources']['physical_launches']=0 if receipt.get('cache_hit') else 1
        payload=output.get('data',{}) if isinstance(output,dict) else {}
        if isinstance(payload,dict) and 'native_forward_evaluations' in payload:
            value['resources']['native_forward_evaluations']=payload['native_forward_evaluations']
            value['resources']['physics_steps']=payload.get('physics_steps',UNAVAILABLE)
    with host.store.transaction() as db:
        ref=host.store.put(db,value)
        host.store.event(db,host.run_id,'tool_replay_record',receipt['execution_status'],
            request=request.get('request_id'),execution=receipt.get('execution_id'),caller=host.actor,
            inputs=request.get('evidence',[]),outputs=[ref])


@contextmanager
def native_entry(host,interface,schema,arguments,request_id,*,origin=None,entrypoint=None):
    """Capture original public dispatch parameters before intent compilation."""
    from copy import deepcopy
    started_at=now();frozen_arguments=deepcopy(plain(arguments));started=time.perf_counter();cpu=time.process_time();error=None
    try:yield
    except BaseException as exc:
        error=dict(type=type(exc).__name__,message=str(exc));raise
    finally:
        events=host.store.events(host.run_id)
        if not any(e['kind']=='native_replay_record' and e['request_id']==request_id for e in events):
            row=host.store.lookup(host.run_id,request_id)
            receipt=json.loads(row['receipt']) if row and row.get('receipt') else None
            value=dict(version='native_replay_record_v1',interface=interface,entrypoint=entrypoint,
                study_id=host.run_id,request_id=request_id,actor=host.actor,timestamp=started_at,completed_at=now(),origin=origin,input_schema=schema,
                original_arguments=frozen_arguments,parameter_types=types(frozen_arguments),receipt=receipt,error=error,
                wall_clock_s=time.perf_counter()-started,host_process_cpu_s=time.process_time()-cpu,
                scope='Exact original entry request before compilation; internal worker reservations remain separate costs, not duplicate replay requests.')
            with host.store.transaction() as db:
                ref=host.store.put(db,value)
                host.store.event(db,host.run_id,'native_replay_record','failed' if error else 'recorded',request=request_id,
                    caller=host.actor,outputs=[ref])


def normalize_usage(request_id,request,response,timestamp):
    raw=response.get('usage') or {}
    provider=request.get('provider',{})
    def field(*keys):
        for key in keys:
            value=raw
            for part in key.split('.'):
                value=value.get(part) if isinstance(value,dict) else None
            if type(value) is int and value>=0:return value
        return UNAVAILABLE
    purpose=request.get('purpose',UNAVAILABLE);role='main' if purpose=='conversation' else purpose
    return dict(request_id=request_id,provider_request_id=response.get('provider_request_id') or UNAVAILABLE,actor=purpose,role=role,
        model=request.get('model',provider.get('model',UNAVAILABLE) if isinstance(provider,dict) else UNAVAILABLE),
        provider=provider.get('adapter',UNAVAILABLE) if isinstance(provider,dict) else provider,
        input_tokens=field('input_tokens','prompt_tokens'),output_tokens=field('output_tokens','completion_tokens'),
        cached_input_tokens=field('input_tokens_details.cached_tokens','prompt_tokens_details.cached_tokens','prompt_cache_hit_tokens'),
        reasoning_tokens=field('output_tokens_details.reasoning_tokens','completion_tokens_details.reasoning_tokens'),
        total_tokens=field('total_tokens'),retry=request.get('retry',UNAVAILABLE),timestamp=timestamp,raw_usage=raw)


def export(host,*,include_outputs=True):
    snapshot=host.store.session(host.run_id)['snapshot'];sessions={host.run_id:snapshot}
    with closing(host.store.connect(True)) as db:
        available={row['run_id']:host.store.session(row['run_id'],db)['snapshot'] for row in db.execute('SELECT run_id FROM sessions')}
    while True:
        children={run:s for run,s in available.items() if s.get('parent_run_id') in sessions and run not in sessions}
        if not children:break
        sessions.update(children)
    events=sorted([e for run in sessions for e in host.store.events(run)],key=lambda e:e['sequence'])
    records=[];native=[];decisions=[];requests={};responses={};usage=[];worker_requests=[]
    for e in events:
        if not e['outputs']:continue
        if e['kind']=='tool_replay_record':
            r=host.store.artifact(e['outputs'][0]);r['event_id']=e['event_id'];r['sequence']=e['sequence']
            if include_outputs and r['output_reference']:r['actual_output']=host.store.artifact(r['output_reference'])
            records.append(r)
        elif e['kind']=='research_decision':decisions.append(host.store.artifact(e['outputs'][0]))
        elif e['kind']=='native_replay_record':
            value=host.store.artifact(e['outputs'][0]);value.update(event_id=e['event_id'],sequence=e['sequence']);native.append(value)
        elif e['kind']=='worker_request':worker_requests.append(dict(event=e,request=host.store.artifact(e['outputs'][0])))
        elif e['kind']=='r3_request':requests[e['request_id']]=host.store.artifact(e['outputs'][0])
        elif e['kind']=='r3_response':responses[e['request_id']]=(host.store.artifact(e['outputs'][0]),e['timestamp'])
    for key,req in requests.items():
        response,timestamp=responses.get(key,({},UNAVAILABLE))
        wire=host.store.artifact(req['request'],raw=True) if req.get('request') else b'{}'
        try:body=json.loads(wire)
        except (ValueError,TypeError):body={}
        req={**req,'model':body.get('model',UNAVAILABLE),'retry':dict(client=req.get('client_retries',UNAVAILABLE),transport=req.get('transport_retries',UNAVAILABLE))}
        if response.get('protocol')=='openai_responses_v1' and response.get('upstream_body'):
            try:response={**response,'usage':json.loads(host.store.artifact(response['upstream_body'],raw=True)).get('usage')}
            except (ValueError,TypeError):pass
        usage.append(normalize_usage(key,req,response,timestamp))
    totals={}
    fields=('input_tokens','output_tokens','cached_input_tokens','reasoning_tokens','total_tokens')
    for role in {u['role'] for u in usage}:
        rows=[u for u in usage if u['role']==role]
        totals[role]={k:sum(u[k] for u in rows) if all(type(u[k]) is int for u in rows) else UNAVAILABLE for k in fields}
        totals[role]['requests']=len(rows)
    # Do not silently omit calls predating the wrapper or internal research calls.
    represented={(r['study_id'],r['request'].get('request_id')) for r in records}|{(r['study_id'],r['request_id']) for r in native}
    represented|={(e['run_id'],e['request_id']) for e in events if e['kind']=='r3_request'}
    with closing(host.store.connect(True)) as db:
        placeholders=','.join('?' for _ in sessions)
        calls=[dict(r) for r in db.execute('SELECT * FROM calls WHERE run_id IN ('+placeholders+') ORDER BY rowid',list(sessions))]
    worker_ids={(w['event']['run_id'],w['request'].get('request_id')) for w in worker_requests}
    unresolved=[c['run_id']+'/'+c['request_id'] for c in calls if (c['run_id'],c['request_id']) not in represented|worker_ids]
    measurements=[]
    def collect(value,reference,pointer='',depth=0):
        if depth>10 or not isinstance(value,dict):return
        if value.get('contract')=='trace.main_replay_input':return
        for key,item in value.items():
            path=pointer+'/'+key.replace('~','~0').replace('/','~1')
            if key in ('cost','actual_resource_consumption','computation_cost','timings_s') and isinstance(item,dict):
                measurements.append(dict(reference=reference,pointer=path,values=item,
                    scope='Recorded resource vector, with original field meanings; nested timing scopes are not additive.'))
            elif key in ('iterations','function_evaluations','optimization_iterations','mathematical_evaluations','physics_steps','physics_step_attempts') and type(item) in (int,float):
                measurements.append(dict(reference=reference,pointer=path,resource=key,amount=item,unit='count'))
            if isinstance(item,dict):collect(item,reference,path,depth+1)
    for call in calls:
        if call['receipt']:
            receipt=json.loads(call['receipt']);reference=receipt.get('output')
            if reference:collect(host.store.artifact(reference),reference)
    failed={(r['study_id'],r['request'].get('request_id')) for r in records if r['receipt']['execution_status'] in ('failed','rejected','unknown','cancelled')}
    failed|={(c['run_id'],c['request_id']) for c in calls if c['status'] in ('failed','rejected','unknown','cancelled')}
    task=snapshot['input']['task'];acceptance=[r for r in records if r.get('expected_output_type')=='EvaluationResult']
    current=host.store.session(host.run_id)['state']
    return dict(version='main_replay_input_v1',core_commit=snapshot.get('project_commit',UNAVAILABLE),
        core_worktree_dirty=snapshot.get('worktree_dirty',UNAVAILABLE),study_id=host.run_id,
        **task_binding(task),frozen_input=snapshot['input'],session_snapshots=sessions,dependency_identity=snapshot.get('dependencies',{}),
        tool_calls=records,native_tool_calls=native,worker_requests=worker_requests,decision_events=decisions,provider_usage=usage,provider_usage_by_role=totals,
        evidence_dependencies=[dict(event_id=e['event_id'],inputs=e['inputs'],outputs=e['outputs']) for e in events],
        candidate_dependencies=host.store.session(host.run_id)['state'].get('result_executions',{}),
        cost=dict(charged_budget=host.store.remaining(host.run_id),resources_by_call=[dict(request_id=r['request'].get('request_id'),**r['resources']) for r in records],
            tool_operations=len(records)+len(native),store_reservations=len(calls),
            charged_tool_operations=sum(json.loads(c['charged'])['tool_calls'] for c in calls),
            failed_calls=len(failed),recorded_cost_measurements=measurements,
            original_research_counters={k:current.get(k,UNAVAILABLE) for k in ('mathematical_evaluations','nmpc_launches','physical_replay_launches','numerical_s')},
            aggregation='Keep resource dimensions and nested execution scopes separate; no undefined total cost.'),
        final_acceptance=dict(success_gate=current.get('success_gate',UNAVAILABLE),selected=current.get('selected',UNAVAILABLE),
            final_disposition=current.get('final_disposition',UNAVAILABLE),
            latest_evaluation=acceptance[-1].get('actual_output',acceptance[-1].get('output_reference')) if acceptance else UNAVAILABLE,
            authority='Only the saved final acceptance/selection gate certifies a new Study; the latest exploratory evaluation is retained separately.'),
        completeness=dict(exact_requests_available=not unresolved,unrepresented_call_ids=unresolved),
        tool_sequence=sorted([dict(kind='host_tool',request_id=r['request'].get('request_id'),timestamp=r['timestamp'],record_event_id=r['event_id']) for r in records]+
            [dict(kind='native_entrypoint',request_id=r['request_id'],timestamp=r['timestamp'],record_event_id=r['event_id']) for r in native],key=lambda r:r['timestamp']),
        replay_policy='Review authorization and remaining budgets before replay; unknown calls never automatically retried. Historical data cannot certify a new Study.')


def export_tool(ctx,args):
    return Payload(contract='trace.main_replay_input',data=export(ctx.host,include_outputs=args.include_outputs))
