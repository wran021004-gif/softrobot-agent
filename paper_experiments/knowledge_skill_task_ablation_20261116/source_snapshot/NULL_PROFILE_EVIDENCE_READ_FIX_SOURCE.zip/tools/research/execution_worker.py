"""One contained complete execution; recovery never launches this worker."""
import sys
from pathlib import Path
from tools.service_execution import contain_worker_children
from tools.state_io import read, atomic_json,io_path


def execute(request):
    from tools.platform_host import Host
    from tools.execution_completion import complete_execution
    from extensions.tendon_family.control_evidence import RECORD_UPDATE_IDS, COMPLETE_UPDATE_INPUTS
    child=Host(Path(request['root']),request['owner'],actor=request['actor'])
    child.create(request['configuration'],parent_run_id=request['study'])
    trace=RECORD_UPDATE_IDS.set(tuple(request['recording']['update_ids']))
    capture=COMPLETE_UPDATE_INPUTS.set(request['recording']['complete_update_inputs'])
    try:
        return complete_execution(child,request['configuration'],request['candidate_id'])
    finally:
        RECORD_UPDATE_IDS.reset(trace)
        COMPLETE_UPDATE_INPUTS.reset(capture)


def main():
    job=contain_worker_children()  # Retain the handle throughout the worker lifetime.
    path=Path(sys.argv[1])
    request=read(path)
    try:
        if request.get('kind')=='candidate_analysis':
            import os
            from importlib.metadata import version
            atomic_json(path.with_name('worker_runtime.json'),dict(python=sys.executable,
                version=sys.version,threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')},
                packages={k:version(k) for k in ('numpy','scipy','pydantic','casadi')},
                implementation=request['implementation']))
            from tools.research.analysis import calculate
            def checkpoint(name,value):
                destination=io_path(path.with_name('numerical_'+name+'.json'))
                if destination.exists():raise ValueError('PRESERVE_NUMERICAL_CHECKPOINT')
                atomic_json(destination,value)
            checkpoint.directory=path.parent
            value=calculate(request['configuration'],request['binding'],request['query'],request.get('exact_point'),checkpoint=checkpoint,
                design_context=request.get('design_context'))
        elif request.get('kind')=='physical_replay':
            from tools.research.physical_replay import calculate
            value=calculate(request,path.parent)
        else:
            value=execute(request)
    except Exception as exc:
        value=dict(status='execution_incomplete',error=type(exc).__name__,reason=str(exc))
        if getattr(exc,'equilibrium_progress',None):
            from extensions.tendon_family.passive_equilibrium import qualification_diagnosis
            value['qualification_diagnosis']=qualification_diagnosis(failure=exc)
        if getattr(exc,'native_baseline_failure',None):value['native_baseline_failure']=exc.native_baseline_failure
        if getattr(exc,'native_diagnostic',None):
            value['native_diagnostic']=exc.native_diagnostic
            value['internal_calculations']=[dict(purpose='failed_native_analysis',**exc.native_diagnostic['cost'])]
            value['physics_steps_lower_bound']=exc.native_diagnostic['cost']['physics_steps']
        if getattr(exc,'mujoco_diagnostic',None):
            diagnostic=exc.mujoco_diagnostic
            if not io_path(path.with_name('numerical_failure.json')).exists():atomic_json(path.with_name('numerical_failure.json'),diagnostic)
            value['numerical_failure']=diagnostic
            value['physics_steps_lower_bound']=diagnostic['confirmed_completed_steps']
    atomic_json(path.with_name('result.json'),value)


if __name__=='__main__':
    main()
