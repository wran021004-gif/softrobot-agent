"""Registered entrypoints delegate to existing research admission and Workers."""
from schemas.platform import Payload
from tools.platform_store import plain


def plan_preflight(inp,args,reg):
    # Core Plan owns its existing public-operation reservation. The envelope
    # reserves no duplicate operation or wall time; original admission still runs.
    return dict(cost=dict(tool_calls=0,wall_s=0.))


def math_preflight(inp,args,reg):
    return dict(cost=dict(wall_s=0.))


def plan(ctx,args):
    from tools.research.core import dispatch
    result=dispatch(ctx.host,plain(args),ctx.request.request_id+'-plan',origin='registry')
    return Payload(contract='research.registered_result',data=plain(result))


def mathematics(ctx,args):
    from tools.research.analysis import dispatch
    from tools.research.state import guard
    result=dispatch(ctx.host,plain(args),ctx.request.request_id+'-math',guard=guard,origin='registry')
    return Payload(contract='research.registered_result',data=plain(result))
