"""Extend existing adapters with authoritative frozen acceptance discovery."""
from tools.state_io import digest


def adapt(adapter):
    if not adapter.task.get('acceptance') or adapter.task['acceptance']['evaluator']=='passive_program':return adapter
    base=type(adapter)
    class ProtocolAdapter(base):
        def control_search_options(self):
            value=super().control_search_options()
            limits=self.task['acceptance']['parameters'].get('geometric_actuator_limits')
            if limits:value['actuator_limits']=limits
            if self.task['acceptance']['evaluator']=='impact_recovery':
                p=self.task['acceptance']['parameters'];a=p['acceptance']
                value.update(holding_windows_s=[p['windows_s']['pre_impact_hold'],p['windows_s']['final_hold']],
                    holding_start=p['windows_s']['pre_impact_hold'][0],position_limit=a['position_error_m'],
                    speed_limit=a['tip_speed_m_s'],terminal_position_limit=a['position_error_m'],
                    actuator_limits=dict(stroke_from_initial_bounds_m=[-a['geometric_tendon_stroke_m'],a['geometric_tendon_stroke_m']],
                        max_tendon_speed_m_s=a['actual_tendon_speed_m_s']))
            return value

        def execution_requirements(self):
            value=super().execution_requirements()
            value.update(protocol_id='offline_frozen_task_v1',protocol_template_id='offline_frozen_task_v1',
                protocol_components=['evaluation_validity','execution_complete','task_evaluator','protocol_sampling','all_frozen_constraints'],
                acceptance_definition=self.task['acceptance'],required_evidence='Dense actual Core task evidence, including initial state; authoritative complete frozen evaluator')
            return value

        def describe(self):
            value=super().describe();value.update(frozen_acceptance=self.task['acceptance'],
                protocol_identity=digest(self.task),physical_environment=self.task['environment']['data'].get('physical_environment'),
                acceptance_authority='evaluate.task_protocol applied after physical execution; position objective alone cannot pass the task')
            return value

        def holding_start_s(self):
            p=self.task['acceptance']['parameters']
            if 'holding_window_s' in p:return p['holding_window_s'][0]
            return super().holding_start_s()

        def ranking_limits(self):
            p=self.task['acceptance']['parameters']
            if self.task['acceptance']['evaluator']=='reach_hold':
                return dict(terminal_error_m=self.task['evaluator']['parameters']['data']['tolerance_m'],
                    holding_max_error_m=p['position_limit_m'],holding_max_speed_m_s=p['speed_limit_m_s'])
            return super().ranking_limits()
    return ProtocolAdapter(adapter.configuration)
