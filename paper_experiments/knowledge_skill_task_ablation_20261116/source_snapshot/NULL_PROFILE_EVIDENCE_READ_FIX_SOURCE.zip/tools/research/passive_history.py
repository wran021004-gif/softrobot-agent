"""Read-only recovery of content-addressed legacy passive evidence.

This audits historical observations. It cannot create a candidate or certify a
new Study. Legacy integration-state omissions remain explicit.
"""
from contextlib import closing
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np
from pydantic import Field
from schemas.common import Contract
from schemas.platform import Payload,TaskDefinition
from tools.platform_store import Store
from tools.state_io import digest


class HistoryAudit(Contract):
    research_root: str
    expected_store_sha256: str = Field(pattern=r'^[a-f0-9]{64}$')


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def recover(root,expected):
    from tools.task_protocols import load
    from tools.paths import resource_path
    from extensions.reference.contracts import PassiveResponseEvaluationV2
    from extensions.reference.passive_evaluation_v2 import stiffness
    root=Path(root).resolve();store=Store(root/'runs/passive-progressive-stiffness-v1/store')
    before=sha(store.db)
    if before!=expected:raise ValueError('HISTORICAL_STORE_HASH_MISMATCH')
    original_path=root/'configs/research/passive_progressive_stiffness_dev_v1.json'
    original=json.loads(original_path.read_text(encoding='utf8'))
    canonical=json.loads(resource_path('TASK_PROTOCOLS/T08_SOURCE.json').read_text(encoding='utf8'))
    if original!=canonical:raise ValueError('HISTORICAL_PROTOCOL_IS_NOT_CURRENT_P3_SOURCE')
    if sha(original_path)!='3f88a70e4461a384969d2173ae7c5da68379556344fd89df3fed7a7e993b064d':
        raise ValueError('HISTORICAL_TASK_FILE_HASH_MISMATCH')
    freeze=json.loads((root/'runs/passive-progressive-stiffness-v1/final_freeze.json').read_text(encoding='utf8'))
    session=store.session(original['task_id'])
    if freeze['protocol']!=original or session['snapshot']['development_freeze']['protocol']!=original:
        raise ValueError('HISTORICAL_FROZEN_PROTOCOL_MISMATCH')
    if freeze['family']!=session['snapshot']['development_freeze']['family']:raise ValueError('HISTORICAL_FAMILY_IDENTITY_MISMATCH')
    # Only the exact, pinned evaluator is an oracle; no JSON-selected callbacks.
    oracle_path=root/'tools/research/passive_evaluation.py'
    if sha(oracle_path)!='42c7dd0b4134e3822c0f8734e671574234082c5d3aff43d0837c4731d3b7249e':
        raise ValueError('ORIGINAL_EVALUATOR_SOURCE_MISMATCH')
    spec=importlib.util.spec_from_file_location('_pinned_passive_history_oracle',oracle_path)
    oracle=importlib.util.module_from_spec(spec);old=sys.dont_write_bytecode;sys.dont_write_bytecode=True
    try:spec.loader.exec_module(oracle)
    finally:sys.dont_write_bytecode=old
    with closing(store.connect(True)) as db:
        indexed={r['trajectory_sha']:r['id'] for r in db.execute(
            "SELECT id,json_extract(body,'$.trajectory_sha256') trajectory_sha FROM artifacts "
            "WHERE json_extract(body,'$.provenance')='CSV reanalysis; no integration'")}
    delivery=root/'runs/passive-progressive-stiffness-v1/delivery-verified'
    summary=json.loads((delivery/'summary.json').read_text(encoding='utf8'))
    protocol=load('T08');task=TaskDefinition.model_validate(protocol.cases[0].task)
    bounds=PassiveResponseEvaluationV2.model_validate(task.evaluator.parameters.data)
    records=[];total=0
    for name,case in summary['cases'].items():
        path=delivery/case['trajectory'];identity=sha(path)
        if identity!=case['trajectory_sha256'] or identity not in indexed:raise ValueError('HISTORICAL_TRACE_BINDING_MISMATCH')
        reference=dict(artifact_id=indexed[identity],media_type='application/json')
        raw=store.artifact(reference)
        if raw['trajectory_sha256']!=identity or raw['implementation_commit']!=freeze['code_commit']:
            raise ValueError('HISTORICAL_RESULT_IDENTITY_MISMATCH')
        evaluation=oracle.evaluate(original,raw)
        if evaluation!=raw['evaluation']:raise ValueError('ORIGINAL_EVALUATOR_REGRESSION_MISMATCH')
        with path.open() as stream:columns=stream.readline().strip().split(',')
        data=np.loadtxt(path,delimiter=',',skiprows=1,ndmin=2)
        col={n:i for i,n in enumerate(columns)};get=lambda n:data[:,col[n]]
        dt=case['timestep_s'];steps=round(sum(s['duration_s'] for s in original['stages'])/dt)
        required=[n for n in columns if not n.startswith('constraint_residual_m_')]
        if len(data)!=steps or not np.isfinite(data[:,[col[n] for n in required]]).all():raise ValueError('INCOMPLETE_OR_NONFINITE_HISTORICAL_TRACE')
        if not np.allclose(get('time_s'),np.arange(1,steps+1)*dt,rtol=0,atol=1e-8):raise ValueError('HISTORICAL_PHYSICS_GRID_MISMATCH')
        direction=np.asarray(original['directions'][case['direction']]);start=0.;prior=0.;force_error=0.
        for i,stage in enumerate(original['stages']):
            count=round(stage['duration_s']/dt);part=data[i*count:(i+1)*count]
            u=np.minimum(np.arange(1,count+1)*dt/original['ramp_s'],1.);alpha=u*u*(3-2*u)
            expected_force=(prior+(stage['force_n']-prior)*alpha)[:,None]*direction
            actual=part[:,[col['force_'+axis+'_n'] for axis in 'xyz']]
            force_error=max(force_error,float(abs(actual-expected_force).max()))
            if not np.all(part[:,col['stage']]==i):raise ValueError('HISTORICAL_STAGE_COVERAGE_MISMATCH')
            prior=stage['force_n'];start+=stage['duration_s']
        if force_error>1e-12 or np.any(get('contacts')) or np.any(get('warnings')):raise ValueError('HISTORICAL_FORCE_CONTACT_OR_WARNING_FAILURE')
        if not raw['geometry']['status']=='legal_at_checked_poses' or raw['geometry']['poses']!=steps:
            raise ValueError('HISTORICAL_FULL_STEP_ROUTE_PROOF_MISSING')
        # Feed the original measured monitor positions and tendon states to the
        # existing v2 stiffness extractor, without inventing integration state.
        mapped=[dict(time_s=r['time_s'],phase=r['stage'],material_positions_m=r['monitor_positions'],
            actual_tension_n=r['tension'],length_residual_m=r['length_residual'],
            constraint_active=[v>0 for v in r['constraint_state']],force_world_n=r['force']) for r in raw['samples']]
        case_task=task.model_copy(update={'timing':task.timing.model_copy(update={'timestep_s':dt})})
        scope=next(s for s in bounds.progressive_stiffness if s.load_condition==case['direction'])
        core=stiffness(case_task,dict(tendon_order=[str(i) for i in range(len(raw['samples'][0]['tension']))],episodes=[
            dict(load_condition=case['direction'],samples=mapped,qualification_samples=mapped)]),scope)
        a=core['stiffness_ratio'];b=evaluation['metrics']['stiffness_ratio']
        if (a is None)!=(b is None) or a is not None and not np.isclose(a,b,rtol=1e-9,atol=1e-10):raise ValueError('CURRENT_CORE_STIFFNESS_REGRESSION_MISMATCH')
        records.append(dict(case=name,rows=steps,sha256=identity,source_path=str(path),source_result=reference,
            historical_status=evaluation['status'],original_evaluator_equal=True,current_core_stiffness_equal=True,
            force_max_difference_n=force_error,full_step_route_proof=raw['geometry'],core_stiffness=core,
            model_sha256=raw['model_sha256'],original_physics_commit=raw['implementation_commit']))
        total+=steps
    if sha(store.db)!=before:raise ValueError('HISTORICAL_STORE_CHANGED')
    return dict(version='passive_history_recovery_v1',origin='historical_read_only',store_path=str(store.db),store_sha256=before,
        task_file_sha256=sha(original_path),protocol_identity=digest(original),family_identity=digest(freeze['family']),
        original_code_commit=freeze['code_commit'],source_commit='83d9b8f35b4015a924e0f8c32d073607247f92b9',
        protocol_semantics_equal=True,rows=total,cases=records,source_files_unchanged=True,
        original_evaluator_regression='COMPLETE',current_core_metric_regression='COMPLETE',
        current_core_full_evidence_regression='PARTIAL',
        missing_current_v2_evidence=['Legacy evidence has no complete versioned mjSTATE_INTEGRATION snapshots or current source bindings.',
            'Current v2 complete-state/independent-confirmation inspector cannot certify a legacy layout; it is not rewritten as current Core execution.'],
        new_study_result='NOT_RUN',new_physics_steps=0,provider_requests=0,optimization_calls=0)


def run(ctx,args):
    return Payload(contract='evidence.passive_history_recovery',data=recover(args.research_root,args.expected_store_sha256))
