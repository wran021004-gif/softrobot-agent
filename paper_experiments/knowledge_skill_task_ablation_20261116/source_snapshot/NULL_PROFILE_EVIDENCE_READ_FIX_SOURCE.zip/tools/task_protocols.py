"""Frozen protocol discovery/binding through the ordinary Registry and Host."""
from copy import deepcopy
import json
from schemas.common import Contract
from schemas.platform import EvidenceRef, Payload, SessionInput
from schemas.task_protocol import TaskProtocol, ReferenceGenerator
from pydantic import Field
from tools.paths import resource_path
from tools.state_io import digest
from tools.platform_store import plain


class ProtocolQuery(Contract):
    task_id: str = Field(pattern=r'^T(0[1-9]|10)$')


class BindProtocol(ProtocolQuery):
    condition_id: str
    configuration: EvidenceRef
    prepared_initial: EvidenceRef | None = None
    candidate: EvidenceRef | None = Field(default=None,description='Optional owned Main candidate to adopt this task binding inside the same frozen Study.')


class EvaluateProtocol(ProtocolQuery):
    condition_id: str
    evidence: EvidenceRef


class AggregateProtocol(ProtocolQuery):
    results: dict[str,EvidenceRef] = Field(min_length=1)


class GenerateReference(Contract):
    reference: ReferenceGenerator
    times_s: list[float] = Field(min_length=1,max_length=100000)
    prediction: bool = False


def load(task_id):
    if task_id not in {f'T{i:02}' for i in range(1,11)}:raise ValueError('UNKNOWN_TASK_PROTOCOL')
    path=resource_path('TASK_PROTOCOLS/'+task_id+'.json')
    return TaskProtocol.model_validate_json(path.read_text(encoding='utf8'))


def inspect(ctx,args):
    p=load(args.task_id)
    return Payload(contract='task.protocol',data=dict(protocol=p.model_dump(mode='json'),protocol_hash=digest(p.model_dump(mode='json')),
        historical_result_is_new_study=False,capability_status='requires_configuration_admission',
        registry_tools=['task.protocol.bind','task.protocol.evaluate','reference.generate','trace.replay_export'],
        study_configuration='Bind every required case to the same owned robot; pass bound SessionInput through existing Study configuration/Host.create. Budgets and authorization remain caller-owned.'))


def bind_configuration(protocol,condition_id,configuration,*,prepared_initial=None,qualification_reference=None):
    p=TaskProtocol.model_validate(protocol);case=next((c for c in p.cases if c.condition_id==condition_id),None)
    if case is None:raise ValueError('UNKNOWN_PROTOCOL_CONDITION')
    cfg=deepcopy(configuration);task=deepcopy(case.task)
    if not {'family','goal','initializer','evaluator'}<=task.keys():
        raise ValueError('SOURCE_TASK_TRANSLATION_NOT_AVAILABLE: '+p.task_id)
    design=cfg['robot']['structure']['data']
    active=design.get('actuators',[]);tendons=design.get('tendons',[])
    if len(active)!=case.independent_channels or len(tendons)!=case.independent_channels and case.independent_channels:
        raise ValueError('PROTOCOL_INDEPENDENT_CHANNEL_COUNT_MISMATCH')
    if active:
        mapped=[]
        for channel in active:
            routes=channel['transmission']
            if len(routes)!=1:raise ValueError('PROTOCOL_REQUIRES_INDEPENDENT_ONE_TENDON_PER_CHANNEL')
            mapped.append(routes[0]['tendon'])
        if len(set(mapped))!=len(tendons) or set(mapped)!={t['id'] for t in tendons}:
            raise ValueError('PROTOCOL_INDEPENDENT_CHANNEL_MAP_MISMATCH')
    if p.task_id=='T08' and (active or not design.get('fixed_payout_lengths_m') or cfg['policy']['controller']['extension_id']!='controller.no_active_control'):
        raise ValueError('PASSIVE_PROTOCOL_REQUIRES_FIXED_PAYOUT_WITH_NO_ACTIVE_CONTROLLER')
    if case.environment_extension:
        task['environment']['data']['physical_environment']=case.environment_extension.model_dump(mode='json')
    task['acceptance']=case.acceptance.model_dump(mode='json');cfg['task']=task
    params=case.acceptance.parameters
    if p.task_id=='T10':
        from extensions.tendon_family.contracts import Design,Discretization
        if (digest(plain(Design.model_validate(design)))!=params['frozen_design_identity']
                or digest(plain(Discretization.model_validate(cfg['policy']['discretization']['data'])))!=params['frozen_discretization_identity']):
            raise ValueError('M7_REQUIRES_UNCHANGED_ORIGINAL_M2_STRUCTURE_AND_DISCRETIZATION')
    minimum=(params.get('tension_bounds_n') or params.get('tension_n') or params.get('actuator_tension_n') or [0])[0]
    if cfg['policy']['controller']['extension_id']=='controller.gvs_nmpc':
        if minimum:cfg['policy']['controller']['parameters']['data']['recipe']['minimum_tension_n']=minimum
    rigid=case.acceptance.parameters.get('rigid_tool')
    if rigid:
        actual=next((c for c in design['components'] if c['id']==rigid['body']),None)
        if actual is None or any(actual.get(k)!=rigid[k] for k in ('mass_kg','com_local_m','inertia_com_local_kg_m2')):
            raise ValueError('FROZEN_RIGID_PAYLOAD_BINDING_REQUIRED')
    if p.task_id=='T09' and (design['tip']['part']!='payload' or list(design['tip']['position_m'])!=[.014,.021,0.]):
        raise ValueError('CONTACT_CONTROL_REFERENCE_REQUIRES_PROBE_CENTER_AS_DESIGN_TIP')
    if p.task_id=='T09':
        eyes=[c for c in design['components'] if c.get('eye_spoke')]
        expected={f'guide_eye_{station}_{i}' for station in ('base','segment0_mid','junction','segment1_mid','segment1_end') for i in range(4)}
        if {c['id'] for c in eyes}!=expected or len(eyes)!=20:
            raise ValueError('V1_2_REQUIRES_TWENTY_PHYSICAL_GUIDE_EYE_SPOKE_COMPONENTS')
    # Preserve candidate-owned dimensions; named zero initializers are mapped by
    # the original family compiler, never by copying a historical successful pose.
    if p.task_id=='T04':
        from tools.research.prepared_initial import static_binding
        if (not prepared_initial or prepared_initial.get('version')!='prepared_initial_v1'
                or prepared_initial.get('qualified') is not True or qualification_reference is None
                or prepared_initial.get('static_binding')!=static_binding(cfg)):
            raise ValueError('SOURCE_BOUND_QUALIFIED_PREPARED_EQUILIBRIUM_REQUIRED')
        cfg['task']['initializer']['parameters']['data']=dict(qpos_rad=prepared_initial['qpos_rad'],
            qvel_rad_s=prepared_initial['qvel_rad_s'],tensions_n=prepared_initial['tensions_n'],
            qualification=plain(qualification_reference),unspecified='zero')
    cfg=SessionInput.model_validate(cfg)
    from tools.platform_tasks import compile_input
    compile_input(cfg)
    return cfg


def bind(ctx,args):
    p=load(args.task_id);prepared=None
    if args.prepared_initial:
        original=ctx.artifact(args.prepared_initial)
        if original.get('contract')!='task.prepared_initial':raise ValueError('REGISTERED_PREPARED_INITIAL_EVIDENCE_REQUIRED')
        prepared=original['data']
        with ctx.store.connect(True) as db:
            producers=[json.loads(r[0]) for r in db.execute('SELECT receipt FROM calls WHERE run_id=? AND receipt IS NOT NULL',(ctx.run_id,))]
        if not any(r.get('tool_id')=='task.initial_state.qualify' and r.get('execution_status')=='completed' and r.get('output')==plain(args.prepared_initial) for r in producers):
            raise ValueError('OWNED_REGISTERED_STATIC_QUALIFICATION_PRODUCER_REQUIRED')
    cfg=bind_configuration(p,args.condition_id,ctx.artifact(args.configuration),prepared_initial=prepared,qualification_reference=args.prepared_initial)
    if args.task_id=='T08':
        from tools.paths import resource_path
        raw=json.loads(resource_path('TASK_PROTOCOLS/T08_SOURCE.json').read_text(encoding='utf8'))
        source=ctx.save_artifact(raw,'frozen_task_protocol_source')
        if plain(source)!=cfg.task.goal.data['protocol_source']:raise ValueError('PASSIVE_PROTOCOL_SOURCE_STORE_IDENTITY_MISMATCH')
    candidate=None
    if args.candidate:
        from tools.research.design import verify_candidate,full_science
        from tools.research.state import state,save,update
        parent=verify_candidate(ctx.host,args.candidate)
        if parent['configuration']!=ctx.artifact(args.configuration):raise ValueError('OWNED_CANDIDATE_CONFIGURATION_REQUIRED')
        a=deepcopy(parent['configuration']['task']);b=cfg.task.model_dump(mode='json')
        a.pop('initializer');b.pop('initializer')
        if a!=b:raise ValueError('TASK_BINDING_CANNOT_CHANGE_FROZEN_MAIN_TASK; prepare the Study with this protocol first')
        current=state(ctx.host);configuration=cfg.model_dump(mode='json')
        identity=bound_candidate_identity(configuration,plain(args.candidate),digest(plain(p)),current['profile']['identity'])
        value={**parent,'identity':identity,'candidate_id':'core-'+identity,'configuration':configuration,
            'configuration_reference':save(ctx.host,configuration,'resolved_candidate_configuration'),
            'scientific_configuration':full_science(configuration),'task_identity':digest(configuration['task']),
            'protocol_binding':dict(task_id=args.task_id,condition_id=args.condition_id,parent=plain(args.candidate),
                prepared_initial=plain(args.prepared_initial),protocol_hash=digest(p.model_dump(mode='json'))),
            'provenance':dict(origin='registered_task_adapter',parent=plain(args.candidate),inherited_acceptance=False)}
        candidate=save(ctx.host,value,'candidate_constructed');update(ctx.host,candidates={**current['candidates'],identity:candidate})
    return Payload(contract='task.bound_configuration',data=dict(configuration=cfg.model_dump(mode='json'),candidate=candidate,
        protocol_hash=digest(p.model_dump(mode='json')),condition_id=args.condition_id,execution_started=False))


def bound_candidate_identity(configuration,parent,protocol_hash,profile_identity):
    from tools.research.design import full_science
    return digest(dict(configuration=full_science(configuration),parent=parent,protocol_hash=protocol_hash,evaluation_profile_identity=profile_identity))


def evaluate(ctx,args):
    from extensions.reference.protocol_evaluation import evaluate,as_platform
    p=load(args.task_id);case=next((c for c in p.cases if c.condition_id==args.condition_id),None)
    if case is None:raise ValueError('UNKNOWN_PROTOCOL_CONDITION')
    value=ctx.artifact(args.evidence);expected=digest(p.model_dump(mode='json'))
    if value.get('protocol_hash')!=expected or value.get('condition_id')!=args.condition_id:
        raise ValueError('TASK_PROTOCOL_EVIDENCE_BINDING_MISMATCH')
    result=evaluate(case.acceptance,case.task,value['arrays'],reference=p.reference.model_dump(mode='json') if p.reference else None)
    result.update(origin=value.get('origin','unavailable'),task_protocol_hash=expected,case_role=case.role,
        condition_id=args.condition_id,design_identity=value.get('design_identity'),controller_identity=value.get('controller_identity'),
        evidence_scope='offline_evaluation; historical evidence is never a new Study result')
    return as_platform(result,args.evidence,'evaluate.task_protocol',expected)


def evaluate_backend(task,result,source,reg,identity):
    from extensions.reference.protocol_evaluation import evaluate,as_platform
    evidence=result.data.data.get('task_evidence')
    if result.solver_status!='completed' or not evidence:
        outcome=dict(validity='incomplete',task_success=None,reason='COMPLETE_CORE_TASK_EVIDENCE_REQUIRED')
    elif evidence.get('task_identity')!=digest(task.model_dump(mode='json')):
        outcome=dict(validity='invalid',task_success=None,reason='TASK_EVIDENCE_IDENTITY_MISMATCH')
    else:
        reference=task.goal.data.get('reference')
        outcome=evaluate(task.acceptance,task.model_dump(mode='json'),evidence['arrays'],reference=reference)
        outcome.update(origin=evidence.get('origin','unavailable'),bound_task_identity=digest(plain(task)),
            design_identity=evidence.get('design_identity'),controller_identity=evidence.get('controller_identity'),source_status=task.acceptance.historical_status)
    return as_platform(outcome,source,task.evaluator.extension_id,identity)


def compose_acceptance(configuration,evaluation,profile,*,evaluation_reference=None,profile_reference=None,motion=None,protocol_id=None):
    from tools.platform_store import plain
    task=configuration['task'];ev=plain(evaluation) if evaluation is not None else None
    report=plain(profile) if profile is not None else {};report=report.get('detail',report)
    detail=(ev or {}).get('diagnostics',{});complete=report.get('complete');issues=[]
    if ev and ev.get('evaluator')!=task['evaluator']['extension_id']:issues.append('EVALUATOR_IDENTITY_MISMATCH')
    if ev and report.get('simulation') and report['simulation']!=ev['source']:issues.append('EVALUATION_SOURCE_MISMATCH')
    if report.get('task') and digest(report['task'])!=digest(task):issues.append('PROFILE_TASK_MISMATCH')
    def component(value):return dict(value=value,passed=value,unit=None,limit=None,reason=None)
    components=dict(evaluation_validity=component(None if not ev else ev['validity']=='valid'),
        execution_complete=component(complete),task_evaluator=component(None if not ev else ev['task_success']),
        protocol_sampling=component(None if not ev else ev['validity']=='valid'),
        all_frozen_constraints=component(None if not ev or ev['validity']!='valid' else bool(detail.get('checks')) and all(detail['checks'].values())))
    for k,v in detail.get('checks',{}).items():
        constraint=detail.get('constraints',{}).get(k,{})
        components['evaluator:'+k]=dict(value=constraint.get('observed',v),passed=v,unit=constraint.get('units'),limit=constraint.get('limit'),reason=None)
    accepted=None if not ev or ev['validity']!='valid' or not complete or issues else bool(ev['task_success'])
    return dict(contract='research.task_acceptance',version='1.0.0',protocol_id='offline_frozen_task_v1',task_family=task['family'],
        task_identity=digest(task),status='accepted' if accepted else 'valid_failure' if accepted is False else 'incomplete',accepted=accepted,
        components=components,metrics=detail.get('metrics',{}),missing=[] if ev and complete else ['complete frozen protocol evidence'],issues=issues,
        execution_id=report.get('execution_id'),sources=dict(evaluation=plain(evaluation_reference),profile=plain(profile_reference)),
        evidence_binding=dict(evaluation=plain(evaluation_reference),profile=plain(profile_reference),simulation=(ev or {}).get('source'),
            evaluation_binding={k:(ev or {}).get(k) for k in ('source','source_execution_id','original_execution_id')},
            profile_binding={k:report[k] for k in ('evaluation','simulation','execution_id') if k in report}),
        timing=task['timing'],continuous_time_guarantee=False,source_status=task['acceptance'].get('historical_status'),
        worst_constraint=detail.get('worst_constraint'),constraint_margins=detail.get('constraints',{}))


def aggregate(protocol,results):
    """Controls are reported separately; acceptance requires every required case."""
    p=TaskProtocol.model_validate(protocol);required={c.condition_id for c in p.cases if c.role=='required'}
    unknown=set(results)-{c.condition_id for c in p.cases}
    if unknown:raise ValueError('UNKNOWN_AGGREGATE_CONDITION')
    identities={r.get('design_identity') for k,r in results.items() if k in required}
    controller_ids={r.get('controller_identity') for r in results.values()}
    same_controller=p.task_id!='T10' or len(controller_ids)==1 and None not in controller_ids
    complete=required<=results.keys() and len(identities)==1 and None not in identities and same_controller
    return dict(complete=complete,task_success=all(results[k]['task_success'] is True for k in required) if complete else None,
        required={k:results.get(k) for k in sorted(required)},controls={c.condition_id:results.get(c.condition_id) for c in p.cases if c.role=='control'},
        missing=sorted(required-results.keys()),same_design=len(identities)==1 and None not in identities,same_controller=same_controller)


def aggregate_tool(ctx,args):
    p=load(args.task_id);expected=digest(plain(p));results={}
    for condition,reference in args.results.items():
        value=ctx.artifact(reference);detail=value.get('diagnostics',{})
        if detail.get('task_protocol_hash')!=expected or detail.get('condition_id')!=condition:
            raise ValueError('PROTOCOL_AGGREGATE_EVALUATION_BINDING_MISMATCH')
        results[condition]=dict(task_success=value['task_success'],validity=value['validity'],design_identity=detail.get('design_identity'),
            controller_identity=detail.get('controller_identity'),
            origin=detail.get('origin','unavailable'),reference=plain(reference))
    return Payload(contract='task.aggregate_evaluation',data=dict(**aggregate(p,results),protocol_hash=expected,
        scope='Task-adapter aggregation only; original Main independent-evidence and SELECT gates remain authoritative.'))
