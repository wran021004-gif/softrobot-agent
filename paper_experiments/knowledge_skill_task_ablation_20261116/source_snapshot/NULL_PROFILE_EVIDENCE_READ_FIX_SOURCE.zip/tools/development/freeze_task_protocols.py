"""Freeze reviewed definitions from a read-only checkout; never import its solvers."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
from schemas.task_protocol import TaskProtocol
from tools.paths import ROOT

COMMIT='2e5d1088746df0916e2a7ec60f4780998c6ba004'


def freeze(reference,p3_translation):
    reference=Path(reference)
    if subprocess.check_output(['git','rev-parse','HEAD'],cwd=reference,text=True).strip()!=COMMIT:
        raise ValueError('FROZEN_SHOWCASE_COMMIT_REQUIRED')
    def read(path):return json.loads((reference/path).read_text(encoding='utf8'))
    def source(path):return dict(path=path,sha256=hashlib.sha256((reference/path).read_bytes()).hexdigest())
    def save(task_id,name,cases,*,ref=None,status='historical_development'):
        for case in cases:case['acceptance']['task_id']=task_id
        protocol=TaskProtocol(task_id=task_id,name=name,source_status=status,cases=cases,reference=ref,
            algorithm_bindings=['candidate.family@6.0.0','model.serial_bending_cells@1.0.0',
                'controller.no_active_control@1.0.0' if task_id=='T08' else 'controller.gvs_nmpc@12.0.0',
                'backend.family_passive_mujoco@1.0.0' if task_id=='T08' else 'backend.family_mujoco@1.5.0'],
            restrictions=['No Provider, optimization, candidate search, research Study or physics integration during interface validation.',
                'Historical evidence is regression data, never a default candidate or a new Study result.',
                'Preserve all source windows, units and physical meanings.'])
        body=json.dumps(protocol.model_dump(mode='json'),ensure_ascii=False,indent=2,allow_nan=False)+'\n'
        for directory in (ROOT/'TASK_PROTOCOLS',ROOT/'tools/assets/TASK_PROTOCOLS'):
            directory.mkdir(parents=True,exist_ok=True);(directory/(task_id+'.json')).write_text(body,encoding='utf8')
    def acceptance(mode,params,sources,signals,grid='physics_including_initial',status=None):
        return dict(evaluator=mode,parameters=params,source_files=[source(s) for s in sources],required_signals=signals,grid=grid,historical_status=status)
    def case(condition,task,acceptance,channels,structure,initial,**extra):
        acceptance=deepcopy(acceptance);acceptance['parameters']['independent_channels']=channels
        return dict(condition_id=condition,task=task,acceptance=acceptance,independent_channels=channels,
            structure_sources=[source(p) for p in structure],initial_state_source=initial,**extra)
    common=['time_s','tip_m','qpos','qvel','tension_n','contacts','solver_errors']
    def actuator_limits(cfg):
        owned=cfg['policy']['candidate_builder']['parameters']['data']['space']['actuator_defaults']
        return dict(stroke_from_initial_bounds_m=owned['limits_m'],max_tendon_speed_m_s=owned['velocity_limit_m_s'],
            observation='Native geometric tendon length relative to the complete initial pose and actual tendon velocity at every physics state; ideal-tension actuator metadata, not a motor constitutive model.')
    for task_id,folder in [('T01','M1_reach_hold'),('T02','M2_loaded_hold'),('T03','M3_fast_reach'),('T05','M5_tool_axis'),('T06','M6_loaded_scan')]:
        cases=[]
        for path in sorted((reference/folder).glob('*/task.json')):
            rel=path.relative_to(reference).as_posix();x=read(rel);task=x['definition'];cfg=read(str(path.parent.relative_to(reference)/'configuration.json').replace('\\','/'))
            count=len(cfg['robot']['structure']['data']['actuators'])
            mode={'T05':'tool_axis','T06':'oriented_tracking'}.get(task_id,'reach_hold')
            p=dict(tension_bounds_n=[0.,8.],initial_tension_n=0.,geometric_actuator_limits=actuator_limits(cfg))
            p['prohibit_contact']='no_environment_contact' in x['historical_acceptance']['components']
            payload=next(c for c in cfg['robot']['structure']['data']['components'] if c['kind']=='payload')
            p['rigid_tool']=dict(body=payload['id'],**{k:payload[k] for k in ('mass_kg','com_local_m','inertia_com_local_kg_m2')})
            if mode=='reach_hold':
                p.update(holding_window_s=x['holding_window_s'],position_limit_m=x['acceptance_margins']['holding_position']['limit'],speed_limit_m_s=x['acceptance_margins']['holding_speed']['limit'])
            if task_id=='T06':p['rigid_tool']=task['goal']['data']['rigid_tool']
            cfg_rel=(path.parent.relative_to(reference)/'configuration.json').as_posix()
            spec=acceptance(mode,p,[rel,cfg_rel],common+['tendon_length_m','tendon_speed_m_s']+(['tip_velocity_m_s'] if mode=='reach_hold' else ['tool_axis_world']))
            folder_rel=path.parent.relative_to(reference).as_posix()
            structure=[folder_rel+'/structure.json'] if (path.parent/'structure.json').exists() else [folder+'/structure.json']
            cases.append(case(path.parent.name,task,spec,count,structure,rel+'#/definition/initializer'))
        save(task_id,folder,cases)
    # Exact figure-eight phase is analytical. No successful qpos, preload,
    # feedforward bank or tension trajectory is copied into the protocol.
    original=read('figure_eight_tracking/task.json')
    ref=dict(kind='figure_eight',center_m=original['center_m'],amplitude_y_m=original['amplitude_y_m'],amplitude_z_m=original['amplitude_z_m'],
        frequency_hz=original['frequency_hz'],cycles=original['cycles'],start_ramp_s=original['start_ramp_s'],stop_ramp_s=original['stop_ramp_s'],duration_s=original['duration_s'])
    task=deepcopy(read('M1_reach_hold/central_high/task.json')['definition'])
    task.update(task_id='figure-eight-tracking-v1',name='Frozen figure-eight tracking',family='task.tracking',
        source='Showcase '+COMMIT+' figure_eight_tracking/task.json and scripts/solve_figure_eight.py; prepared candidate equilibrium required')
    task['timing'].update(duration_s=22.,timestep_s=.001,control_period_s=.01,sample_period_s=.01)
    task['environment']['data']['mount']['position_m']=[0.,0.,.17]
    task['sampling']['window_s']=[.01,22.]
    task['initializer']['parameters']['data'].update(qpos_rad={},qvel_rad_s={})
    task['goal']=dict(contract='reference.parametric_tracking_goal',version='1.0.0',data=dict(reference=ref,time_requirement='timed'))
    task['evaluator']=dict(extension_id='evaluate.tracking',version='1.0.0',parameters=dict(contract='reference.tracking_evaluation',version='1.0.0',data=dict(max_error_m=.006,geometry_step_m=.001)))
    task['objectives']=[dict(metric='rms_position_error',direction='minimize',units='m')]
    # Read task-owned payload data, never the successful backbone or control.
    payload=read('figure_eight_tracking/design.json')['components'][-1]
    rigid={k:payload[k] for k in ('mass_kg','com_local_m','inertia_com_local_kg_m2')};rigid['body']='payload'
    params={**original['limits'],'initial_static_balance_max_nm':1e-7,'initial_state_mode':'qualified_candidate_equilibrium',
        'rigid_tool':rigid,'cycle_windows_s':[[0,11],[11,22.001]],'lobe_y_min_m':-.018,'lobe_y_max_m':.018,'lobe_z_min_m':.163,'lobe_z_max_m':.177}
    spec=acceptance('figure_eight',params,['figure_eight_tracking/task.json','scripts/solve_figure_eight.py'],[k for k in common if k!='solver_errors']+['warnings','tendon_length_m'])
    extension=dict(robot_hinge_range_rad=[-.3,.3],actuator_min_tension_n=.2,replace_robot_geometries=['payload_shape'],
        geometries=[dict(name='pointer_shaft',body='payload',kind='capsule',position_m=[.007,0,0],quaternion_wxyz=[2**-.5,0,2**-.5,0],size_m=[.002,.007],contype=1,conaffinity=2),
            dict(name='pointer_head',body='payload',kind='sphere',position_m=[.014,0,0],size_m=[.003],contype=1,conaffinity=2)])
    save('T04','Figure-eight Tracking',[case('default',task,spec,4,['figure_eight_tracking/robot.xml','figure_eight_tracking/structure.json'],'candidate-qualified equilibrium; never copy historical qpos',environment_extension=extension)],ref=ref)
    cases=[]
    for condition in ['M1_A','M1_B','M1_C','M5']:
        path=f'C1_four_tendons/{condition}/configuration.json';task=read(path)['task'];mode='tool_axis' if condition=='M5' else 'reach_hold'
        params=dict(tension_bounds_n=[0,8],initial_tension_n=0.,prohibit_contact=False,geometric_actuator_limits=actuator_limits(read(path)))
        payload=next(c for c in read(path)['robot']['structure']['data']['components'] if c['kind']=='payload')
        params['rigid_tool']=dict(body=payload['id'],**{k:payload[k] for k in ('mass_kg','com_local_m','inertia_com_local_kg_m2')})
        if condition!='M5':params.update(holding_window_s=[.54,.6],position_limit_m=.01,speed_limit_m_s=.03)
        spec=acceptance(mode,params,['C1_four_tendons/task.txt',path],common+['tendon_length_m','tendon_speed_m_s']+(['tool_axis_world'] if mode=='tool_axis' else ['tip_velocity_m_s']))
        cases.append(case(condition,task,spec,4,['C1_four_tendons/design.json'],path+'#/task/initializer'))
    save('T07','C1 Four-tendon Multi-task',cases)
    # A reviewed existing Core translation is reused only after verifying its
    # source hash against the authoritative frozen P3 data.
    p3=read('P3_progressive_stiffness/task.json');translation=json.loads(Path(p3_translation).read_text(encoding='utf8'))['task']
    from tools.state_io import digest
    if translation['goal']['data']['protocol_source']['artifact_id']!=digest(p3):
        raise ValueError('REVIEWED_P3_TRANSLATION_SOURCE_HASH_MISMATCH')
    spec=acceptance('passive_program',p3,['P3_progressive_stiffness/task.json'],['time_s','material_positions_m','material_velocities_m_s','qpos','qvel','length_residual_m','tension_n','static_balance_inf_nm'],status=p3['status'])
    save('T08','P3 Progressive Stiffness',[case('both_directions',translation,spec,0,['P3_progressive_stiffness/design.json'],'same qualified unloaded equilibrium for plus_x and minus_x')],status=p3['status'])
    # Source-only protocol blob, needed by the existing passive worker.
    for directory in (ROOT/'TASK_PROTOCOLS',ROOT/'tools/assets/TASK_PROTOCOLS'):
        (directory/'T08_SOURCE.json').write_text(json.dumps(p3,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n',encoding='utf8')
    original=read('spring_button_press/task.json');env=read('spring_button_press/environment.json');ev=read('spring_button_press/evaluation.json')
    center=env['button_center_unpressed_m'];geometries=[]
    def geom(name,body,kind,position,size,ctype=1,affinity=13,quaternion=(1,0,0,0)):
        return dict(name=name,body=body,kind=kind,position_m=position,size_m=size,contype=ctype,conaffinity=affinity,quaternion_wxyz=quaternion)
    geometries.extend([geom('tool_block','payload','box',[.007,0,0],[.007,.004,.004]),geom('tool_bracket','payload','box',[.014,.011,0],[.002,.007,.002]),geom('probe','payload','sphere',[.014,.021,0],[.003])])
    quat=[2**-.5,2**-.5,0,0]
    geometries.extend([geom('button_cap','button_slider','cylinder',[0,0,0],[env['cap_radius_m'],env['cap_thickness_m']/2],4,1,quat),geom('button_rod','button_slider','cylinder',[0,.0075,0],[env['rod_radius_m'],env['rod_length_m']/2],4,1,quat)])
    for j,(x,z,sx,sz) in enumerate([(-.009,0,.002,.011),(.009,0,.002,.011),(0,-.009,.007,.002),(0,.009,.007,.002)]):
        geometries.append(geom('housing_rail_'+str(j),'world','box',[center[0]+x,center[1]+.011,center[2]+z],[sx,.01,sz],8,1))
    geometries.append(geom('mount_plate','world','box',[center[0],center[1]+.026,center[2]],[.018,.003,.018],8,1))
    extension=dict(bodies=[dict(name='button_slider',position_m=center,mass_kg=env['button']['mass_kg'],com_local_m=env['button']['com_m'],inertia_com_local_kg_m2=env['button']['inertia_com_kg_m2'],joint_name='button_slide',axis_local=[0,1,0],joint_range=env['slide_range_m'],stiffness=env['spring_n_m'],damping=env['damping_ns_m'])],
        geometries=geometries,contact_pairs=[dict(geom1='probe',geom2='button_cap',condim=env['contact_dimension'],solref=env['contact_solref'],solimp=env['contact_solimp'])],
        replace_robot_geometries=['payload_shape'],sites=[dict(name='probe_center',body='payload',position_m=[.014,.021,0])],collision_policy='self_environment_frictionless',solver_iterations=100,solver_tolerance=1e-10)
    task=deepcopy(read('C1_four_tendons/M1_A/configuration.json')['task']);task.update(task_id='spring-button-contact-v1-2',name='Spring Button Press v1.2',family='task.tracking')
    task['timing'].update(duration_s=2.,control_period_s=.01,sample_period_s=.01,timestep_s=.001);task['sampling']['window_s']=[.01,2.]
    # The task reference is a safe position reference. Existing controllers may
    # be selected; the true contact evaluator remains the success authority.
    initial=env['reference_probe_center_m'];touch=[center[0],center[1]-.0045,center[2]];pressed=[touch[0],touch[1]+original['target_travel_m'],touch[2]]
    ref_button=dict(kind='quintic_nodes',center_m=initial,duration_s=2.,times_s=[0,.5,.9,1.4,1.8,2.],positions_m=[initial,touch,pressed,pressed,initial,initial])
    task['goal']=dict(contract='reference.parametric_tracking_goal',version='1.0.0',data=dict(reference=ref_button,time_requirement='timed'))
    task['evaluator']=dict(extension_id='evaluate.tracking',version='1.0.0',parameters=dict(contract='reference.tracking_evaluation',version='1.0.0',data=dict(max_error_m=.002,geometry_step_m=.001)))
    task['objectives']=[dict(metric='max_position_error',direction='minimize',units='m')]
    rigid=dict(body='payload',mass_kg=env['tool']['mass_kg'],com_local_m=env['tool']['com_m'],inertia_com_local_kg_m2=env['tool']['inertia_com_kg_m2'])
    params={**ev,'observation_site':'probe_center','initial_tension_n':original['initial_tension_n'],'button_center_unpressed_m':center,'rigid_tool':rigid}
    signals=['time_s','qpos','qvel','button_q_m','button_qdot_m_s','contact_force_n','contact_pairs','lateral_error_m','tension_n','tendon_length_m','tendon_speed_m_s','tip_speed_m_s','unexpected_contact_count','warnings','external_force_max']
    spec=acceptance('contact_press',params,['spring_button_press/task.json','spring_button_press/environment.json','spring_button_press/evaluation.json','spring_button_press/evaluator.py'],signals)
    save('T09','Spring Button Press v1.2',[case('default',task,spec,4,['C1_four_tendons/design.json'],'original zero robot qpos/qvel, zero button state, 0.20 N initial tension',environment_extension=extension)])
    original=read('M7_external_impact_active_recovery/task.json');cases=[]
    from extensions.tendon_family.contracts import Design,Discretization
    original_structure=read('M7_external_impact_active_recovery/structure.json')
    frozen_design=digest(Design.model_validate(original_structure['design']).model_dump(mode='json'))
    frozen_mesh=digest(Discretization.model_validate(original_structure['discretization']).model_dump(mode='json'))
    for name,sign,role in [('positive_y',1,'required'),('negative_y',-1,'required'),('no_impulse',0,'required'),('positive_y_frozen',1,'control'),('negative_y_frozen',-1,'control')]:
        task=deepcopy(read('M2_loaded_hold/zero/task.json')['definition']);task.update(task_id='m7-'+name.replace('_','-'),name='External impact recovery '+name)
        task['timing'].update(duration_s=original['duration_s']);task['environment']['data']['external_forces']=[];task['sampling']['window_s']=[0,1.]
        impulse=original['impulse'];wrenches=[]
        if sign:wrenches=[dict(entity='payload',force_n=[0,sign*impulse['peak_n'],0],start_s=impulse['onset_s'],end_s=impulse['onset_s']+impulse['duration_s'],waveform='half_sine')]
        params={k:original[k] for k in ['target_m','acceptance','windows_s']};params.update(initial_tension_n=.2,condition_direction=sign,control_mode='frozen_pre_impact_input' if role=='control' else 'active_feedback',
            frozen_design_identity=frozen_design,frozen_discretization_identity=frozen_mesh)
        spec=acceptance('impact_recovery',params,['M7_external_impact_active_recovery/task.json','M7_external_impact_active_recovery/run.py'],[k for k in common if k!='solver_errors']+['warnings','tip_velocity_m_s','tendon_length_m','tendon_velocity_m_s','force_n','control_n'])
        cases.append(case(name,task,spec,6,['M7_external_impact_active_recovery/structure.json'],'original M2 zero qpos/qvel; 0.20 N initial input',role=role,environment_extension=dict(wrenches=wrenches,input_freeze_after_s=impulse['onset_s'] if role=='control' else None)))
    save('T10','M7 External Impact Recovery',cases)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reference',required=True);parser.add_argument('--p3-translation',required=True)
    args=parser.parse_args();freeze(args.reference,args.p3_translation)
