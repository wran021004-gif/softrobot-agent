"""Read-only historical evidence regression. Never import a runner or integrate."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import numpy as np
from tools.task_protocols import load
from extensions.reference.protocol_evaluation import evaluate

COMMIT='2e5d1088746df0916e2a7ec60f4780998c6ba004'
C009='9928d7f71233ee931005bfe1f8b4cc5d34cdf61fd315d91b217e65686f5c7c0f'


def csv_arrays(path):
    a=np.genfromtxt(path,delimiter=',',names=True,dtype=float,encoding='utf8');names=a.dtype.names
    def columns(prefix):return np.column_stack([a[n] for n in names if n.startswith(prefix)])
    return dict(time_s=a['time_s'],qpos=columns('qpos_rad__'),qvel=columns('qvel_rad_s__'),
        tip_m=columns('tip_position_m_'),tip_velocity_m_s=columns('tip_velocity_m_s_'),
        tool_axis_world=columns('tool_axis_world_'),tension_n=columns('actual_tension_n__'),
        contacts=np.maximum(a['integration_cache_contact_count'],a['post_state_contact_count']))


def read_case(reference,task_id,case):
    root=Path(reference)
    def read(path):return json.loads((root/path).read_text(encoding='utf8'))
    metadata=[]
    if task_id in ('T01','T02','T03','T05','T06'):
        folder={'T01':'M1_reach_hold','T02':'M2_loaded_hold','T03':'M3_fast_reach','T05':'M5_tool_axis','T06':'M6_loaded_scan'}[task_id]+'/'+case.condition_id
        arrays=csv_arrays(root/folder/'trajectory_timestep.csv');original=read(folder+'/task.json')['historical_acceptance']
        errors=original['components']['solver_errors']['value'];arrays['solver_errors']=np.full(len(arrays['time_s']),errors)
        metadata.append('solver_errors is the original recorded aggregate count, repeated for maximum reduction; no per-step warning observation inferred')
        return arrays,original['accepted'],original.get('metrics',{}),folder+'/trajectory_timestep.csv',metadata
    if task_id=='T07':
        folder='C1_four_tendons/'+case.condition_id;arrays=csv_arrays(root/folder/'trajectory.csv');original=read(folder+'/result.json')
        arrays['solver_errors']=np.full(len(arrays['time_s']),original['profile']['solver_error_count'])
        metadata.append('solver_errors is the original profile aggregate count')
        return arrays,original['status']=='PASS',{},folder+'/trajectory.csv',metadata
    if task_id=='T04':
        file='figure_eight_tracking/trajectory_full.npz';raw=np.load(root/file,allow_pickle=False);arrays={k:raw[k] for k in raw.files};original=read('figure_eight_tracking/results.json')
        for key,value in [('contacts',original['metrics']['contacts']),('warnings',max(original['metrics']['solver_warnings']))]:arrays[key]=np.full(len(arrays['time_s']),value)
        metadata.append('contact and warning totals come from original result metadata; the NPZ has no per-step contact/warning channels')
        return arrays,original['status']=='PASS',original['metrics'],file,metadata
    if task_id=='T09':
        file='spring_button_press/v1_2/candidates/FINAL_C009/trajectory.npz';raw=np.load(root/file,allow_pickle=False)
        original=read('spring_button_press/v1_2/candidates/FINAL_C009/result.json')
        return {k:raw[k] for k in raw.files},original['status']=='PASS',original['metrics'],file,metadata
    if task_id=='T10':
        condition=case.condition_id.replace('_frozen','_no_feedback');folder='M7_external_impact_active_recovery/candidates/startup_shaped_feedback/'+condition
        file=folder+'/trajectory.npz';raw=np.load(root/file,allow_pickle=False);original=read(folder+'/result.json')
        return {k:raw[k] for k in raw.files},original['status']=='PASS',original['metrics'],file,metadata
    raise ValueError('FULL_HISTORICAL_PASSIVE_EVIDENCE_NOT_PRESENT')


def run(reference):
    root=Path(reference)
    if subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()!=COMMIT:raise ValueError('REFERENCE_COMMIT_MISMATCH')
    before=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    protected=root/'spring_button_press/v1_2/candidates/C009/result.json'
    if hashlib.sha256(protected.read_bytes()).hexdigest()!=C009:raise ValueError('PROTECTED_C009_CHANGED')
    records=[]
    for i in range(1,11):
        task_id=f'T{i:02}';protocol=load(task_id)
        for case in protocol.cases:
            if task_id=='T08':
                from tools.paths import ROOT
                recovered=ROOT/'T08_HISTORICAL_RECOVERY_RESULTS.json'
                recovery=json.loads(recovered.read_text(encoding='utf8'))['data'] if recovered.exists() else None
                records.append(dict(task_id=task_id,condition_id=case.condition_id,regression='PARTIAL',historical_status='HISTORICAL_RESULT_PASS',
                    reason='Recovered 1,600,000 legacy CSV rows, original evaluator and v2 stiffness metrics agree. Legacy complete integration-state/current binding proofs remain absent; no current v2 full-evidence equivalence or fresh success asserted.' if recovery else 'Frozen Showcase has display_replay.npz and original_result.json, but no complete physical-step states, route checks, paired mechanism or confirmation evidence. Original evaluator source is absent. No equivalence or fresh success asserted.',
                    recovered_legacy_evidence=recovery,
                    source_status=protocol.source_status,new_study_status='NOT_RUN'))
                continue
            arrays,expected,metrics,source,notes=read_case(root,task_id,case)
            full_acceptance=evaluate(case.acceptance,case.task,arrays,reference=protocol.reference.model_dump(mode='json') if protocol.reference else None)
            legacy=case.acceptance.model_dump(mode='json')
            if 'geometric_actuator_limits' in legacy['parameters']:
                legacy['parameters'].pop('geometric_actuator_limits')
                legacy['required_signals']=[k for k in legacy['required_signals'] if k not in ('tendon_length_m','tendon_speed_m_s')]
                notes.append('Original oracle regression only: historical CSV has no dense tendon length/velocity. Full actuator-envelope acceptance is separately incomplete and cannot be upgraded to PASS.')
            actual=evaluate(legacy,case.task,arrays,reference=protocol.reference.model_dump(mode='json') if protocol.reference else None)
            comparable={k:dict(original=v,core=actual.get('metrics',{}).get(k)) for k,v in metrics.items()
                if type(v) in (float,int) and k in actual.get('metrics',{})}
            matches={k:bool(np.isclose(v['original'],v['core'],rtol=1e-9,atol=1e-10)) for k,v in comparable.items()}
            passed=actual['validity']=='valid' and actual['task_success']==expected and all(matches.values())
            records.append(dict(task_id=task_id,condition_id=case.condition_id,role=case.role,regression='PASS' if passed else 'FAIL',
                historical_status='HISTORICAL_RESULT_PASS' if expected else 'HISTORICAL_RESULT_FAIL',original_task_success=expected,core=actual,
                full_current_acceptance=full_acceptance,original_oracle_scope_only='geometric_actuator_limits' in case.acceptance.parameters,
                metric_comparison=comparable,metric_matches=matches,source_file=source,source_sha256=hashlib.sha256((root/source).read_bytes()).hexdigest(),
                source_limitations=notes,new_study_status='NOT_RUN'))
    after=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
    if before!=after or hashlib.sha256(protected.read_bytes()).hexdigest()!=C009:raise ValueError('REFERENCE_MUTATED')
    return dict(reference_commit=COMMIT,protected_c009_sha256=C009,reference_unchanged=True,
        provider_requests=0,physics_steps=0,optimization_calls=0,new_candidates=0,records=records,
        counts={status:sum(r['regression']==status for r in records) for status in ('PASS','FAIL','PARTIAL')})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reference',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args();result=run(args.reference)
    Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps(result['counts']))
    raise SystemExit(bool(result['counts']['FAIL']))
