"""Build interface readiness reports from actual offline test/regression artifacts."""
import json
from pathlib import Path
from tools.paths import ROOT
from tools.task_protocols import load
from tools.platform_registry import registry
from tools.platform_tasks import check_definition
from tools.platform_store import plain
from tools.state_io import digest

BASE='2c83f8b7bd654328dd7648f844295c54a7c15223'
AXES=('task_specification','task_adapter','structure_generation','mathematical_tools','physical_backend','evaluator','main_reporter','store_evidence_cost')
BEFORE={
 'T01':['AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL'],
 'T02':['AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL'],
 'T03':['AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL'],
 'T04':['MISSING','MISSING','AVAILABLE','PARTIAL','PARTIAL','PARTIAL','PARTIAL','PARTIAL'],
 'T05':['AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL'],
 'T06':['AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL'],
 'T07':['PARTIAL','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','PARTIAL','PARTIAL'],
 'T08':['AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL','AVAILABLE','AVAILABLE','AVAILABLE','PARTIAL'],
 'T09':['MISSING','MISSING','PARTIAL','PARTIAL','MISSING','MISSING','MISSING','PARTIAL'],
 'T10':['PARTIAL','PARTIAL','AVAILABLE','PARTIAL','PARTIAL','MISSING','PARTIAL','PARTIAL']}
EVIDENCE={
 'task_specification':['schemas/platform.py:TaskDefinition','schemas/task_protocol.py:TaskProtocol','TASK_PROTOCOLS/'],
 'task_adapter':['tools/research_tasks.py:task_adapter','tools/research/protocol_adapter.py:adapt','tools/task_protocols.py:bind_configuration'],
 'structure_generation':['extensions/tendon_family/family_space.py:FamilySpaceV2','extensions/tendon_family/generated_serial.py:generate_family','extensions/tendon_family/compiler.py:resolve'],
 'mathematical_tools':['tools/research/analysis.py:dispatch','extensions/math_analysis/mechanism_registry.py','tools/research/registry_bridge.py:mathematics'],
 'physical_backend':['extensions/tendon_family/backends.py','extensions/tendon_family/environment.py','extensions/tendon_family/passive_execution.py'],
 'evaluator':['extensions/reference/implementation.py','extensions/reference/protocol_evaluation.py','extensions/reference/passive_evaluation_v2.py'],
 'main_reporter':['tools/research/agent.py','tools/research/protocol_tools.py','tools/research/evidence_views.py'],
 'store_evidence_cost':['tools/platform_host.py:Host.invoke','tools/platform_store.py:Store','tools/research/replay_export.py']}
NOTES={
 'T01':'Original targets, named zero state, 0.54–0.60 s formal 20 ms hold samples, 10 mm position and 30 mm/s speed are retained per condition. Endpoint evaluation is composed with holding evidence.',
 'T02':'Original three signed/zero COM-force conditions, 0.10–0.35 s force interval, payload inertia, 0.30–0.35 s hold, 10 mm and 20 mm/s bounds retained. Reduced predictor omits injected forces; physical execution applies them.',
 'T03':'Original 0.50 s horizon, 0.45–0.50 s formal hold, initial state, 10 mm and 20 mm/s bounds retained. No generic Reach replacement.',
 'T04':'Exact integrated quintic speed ramps give two cycles in 22 s at world mount z=0.17 m. Prepared initial q/u require registered static qualification at <=1e-7 N.m balance; no historical preload is installed. Actual lobes, drift, strict source bounds and complete physical grid are checked.',
 'T05':'Position plus directed tip-local axis; original 0.58 and 0.60 s samples, 8 mm and 3 degrees. Existing native sequence optimization/Replay is supported; pose NMPC is not implemented or advertised as equivalent.',
 'T06':'Frozen 20 g rigid tool, off-diagonal inertia and COM are checked against actual design/compiled load. Original timed scan position and normalized axis reference, 12 mm and 10 degree bounds retained. Native sequence/Replay route remains required.',
 'T07':'Exactly four independent tendon/actuator maps and one shared design. M1_A/B/C and M5 retain distinct goals, grids and velocity requirements. Aggregation never replaces per-subtask evaluation.',
 'T08':'Existing passive v2 program, fixed payout, no active channels, common unloaded equilibrium, both directions, stage qualification, KKT/tangent methods and independent evaluator reused. Original development_not_registered_SELECT status retained. Legacy 1,600,000-row evidence recovered; original evaluator and current stiffness metrics agree, while legacy v2 complete-state/binding equivalence remains partial.',
 'T09':'Source parent task/environment/evaluation files govern v1.2. Native slide, true normal contact, spring/damper, housing/probe geometry, full rigid inertia and passive rebound are expressed in the shared backend. Existing GVS position NMPC is available; contact-aware NativeModel mathematics remains unsupported, with explicit admission rejection.',
 'T10':'Original M2 design/discretization fingerprint is frozen. World +/-Y half-sine 0.50–0.55 s at payload COM, 0.5 ms physics and 10 ms control. Full controller views are identical across cases, including blind labels/provenance; reference clock stops after approach. Frozen-input controls are executor-owned and excluded from active-pass aggregation.'}


def write(name,value):
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n' if name.endswith('.json') else value,encoding='utf8')


def build():
    tests=json.loads((ROOT/'TEST_RESULTS.json').read_text(encoding='utf8'))
    if not tests['success']:raise ValueError('PASSING_OFFLINE_TESTS_REQUIRED_BEFORE_READINESS_REPORT')
    regression=json.loads((ROOT/'EVALUATOR_REGRESSION_RESULTS.json').read_text(encoding='utf8'))
    baseline=json.loads((ROOT/'BASELINE_AUDIT.json').read_text(encoding='utf8'))
    package=json.loads((ROOT/'PACKAGE_VALIDATION.json').read_text(encoding='utf8'))
    cli=json.loads((ROOT/'CLI_VALIDATION.json').read_text(encoding='utf8'))
    if not package['success'] or not cli['success']:raise ValueError('PASSING_PACKAGE_AND_CLI_CHECKS_REQUIRED')
    r=registry();rows=[];matrix=[]
    for i in range(1,11):
        task_id=f'T{i:02}';p=load(task_id);records=[v for v in regression['records'] if v['task_id']==task_id]
        definitions=all(check_definition(c.task,r) for c in p.cases)
        backend='backend.family_passive_mujoco' if task_id=='T08' else 'backend.family_mujoco'
        version='1.0.0' if task_id=='T08' else '1.5.0'
        gates=dict(task_specification_valid=bool(definitions),task_adapter_registered=all(r.get(c.task['family'],kind='task').binding is not None for c in p.cases),
            structure_generation_available=r.get('candidate.family','6.0.0','candidate_builder').binding is not None,
            necessary_math_callable=r.get('research.math',kind='tool').binding is not None,
            physical_backend_expressive=r.inspect(r.get(backend,version,'backend'),[backend])['dependencies_available'],
            evaluator_registered=all(r.get(c.task['evaluator']['extension_id'],c.task['evaluator']['version'],'evaluator').binding is not None for c in p.cases),
            main_tools_discoverable=tests['success'],store_evidence_serializable=tests['success'],exact_trace_export=tests['success'],
            cost_accounting_interface=tests['success'],offline_regression_passed=bool(records) and all(v['regression']=='PASS' for v in records))
        ready=all(gates.values()) and tests['success']
        blockers=[] if ready else [v.get('reason','Unresolved offline regression') for v in records if v['regression']!='PASS']
        row=dict(task_id=task_id,name=p.name,protocol_hash=digest(plain(p)),core_research_status='CORE_RESEARCH_READY' if ready else 'NOT_CORE_RESEARCH_READY',
            gates=gates,blocking_reasons=blockers,historical_result_status='HISTORICAL_RESULT_PASS',new_study_status='NOT_RUN',
            original_source_status=p.source_status,case_count=len(p.cases),regression=[dict(condition_id=v['condition_id'],status=v['regression']) for v in records],scope=NOTES[task_id])
        rows.append(row)
        matrix.append(dict(task_id=task_id,name=p.name,capabilities={axis:dict(original_status=status,completed_status='AVAILABLE',execution_evidence=EVIDENCE[axis]) for axis,status in zip(AXES,BEFORE[task_id])},
            necessary_math_scope='Existing nominal geometry/statics/control tools; contact-aware native derivatives are unsupported and unnecessary for declaring the environment/evaluation interface.' if task_id=='T09' else 'Existing registered research methods; applicability and original method grants still apply.',
            additional_limits=dict(contact_aware_native_math='UNSUPPORTED') if task_id=='T09' else {},
            offline_regression_status='PARTIAL' if task_id=='T08' else 'AVAILABLE',readiness=row['core_research_status'],notes=NOTES[task_id]))
    write('TASK_CAPABILITY_MATRIX.json',dict(version='ten_task_capability_matrix_v1',baseline_core_commit=BASE,status_meanings=dict(AVAILABLE='Existing formal executable interface',PARTIAL='Only part of the required chain/semantics',MISSING='No formal implementation',UNSUPPORTED='Explicitly outside the current mathematical model/architecture'),tasks=matrix))
    write('TEN_TASK_READINESS.json',dict(version='ten_task_readiness_v1',base_core_commit=BASE,implementation_version='0.2.2',source_commit='2e5d1088746df0916e2a7ec60f4780998c6ba004',
        all_tasks_core_research_ready=all(v['core_research_status']=='CORE_RESEARCH_READY' for v in rows),ready_count=sum(v['core_research_status']=='CORE_RESEARCH_READY' for v in rows),tasks=rows,
        execution_boundaries=tests['execution_counters'],final_commit='The Git commit containing this report; no self-referential SHA is embedded.'))
    table='\n'.join('| '+v['task_id']+' | '+v['name']+' | '+v['core_research_status']+' | '+('PASS' if v['gates']['offline_regression_passed'] else 'PARTIAL: source gap')+' |' for v in rows)
    write('TEN_TASK_READINESS.md',f'''# Ten-task Core research readiness

Date: 2026-11-12 (Asia/Shanghai). Base: `{BASE}`. Implementation version: 0.2.2.

**{sum(v['core_research_status']=='CORE_RESEARCH_READY' for v in rows)}/10 interfaces meet the full offline readiness gates. The overall ten-task acceptance is not complete.**

| Task | Name | Core research status | Historical offline regression |
|---|---|---|---|
{table}

All ten tasks have registered research entrypoints and validated frozen definitions. T08 retains `development_not_registered_SELECT`. Its legacy Store and 1,600,000 rows were recovered and hash-verified; original evaluator and current stiffness-metric regressions agree. The legacy layout lacks the versioned complete integration-state/current binding proofs required by the current v2 full-evidence inspector. Strict readiness therefore remains unresolved; those fields were not fabricated. See `T08_HISTORICAL_EVIDENCE_RECOVERY.md`.

`CORE_RESEARCH_READY` means an interface can support future authorized research through existing tools; it does not predict that any controller or design will pass. `HISTORICAL_RESULT_PASS` refers only to the archived required-case results. `NEW_STUDY_PASS` was never produced in this phase; every new-Study status is `NOT_RUN`.

All active cases use the same Core architecture. T05/T06 use the existing native sequence/physical Replay route for axis objectives. T09 uses existing GVS position control with native contact physics and an independent contact evaluator; native contact-aware trajectory mathematics is explicitly rejected. T10 requires a shared blind controller as well as a shared design; its frozen-input controls do not enter active success aggregation.

See `TEN_TASK_READINESS.json` for all eleven gates per task and `TEST_RESULTS.json` for actual test records. No Main, Provider, optimization, candidate search or trajectory integration was run.
''')
    audit='''# Original Core capability audit

This audit distinguishes the frozen baseline from the new interfaces. It traces execution, rather than matching function names. The baseline and branch inventories are in `BASELINE_AUDIT.json`; statuses below describe commit `2c83f8b7bd654328dd7648f844295c54a7c15223` before edits.

## Workspace and source identity

The original Core checkout was clean on main at the required base. Work proceeds in the isolated branch `codex/ten-task-core-interfaces-20261112`; main was not edited/reset. Baseline Registry: 38 declarations. The original Showcase checkout was clean at `d6a1d49ed7301e48df9ae8a601d3d7c39e64f4fa`, and did not contain the requested reference objects. The exact reference and protected C009 commit were fetched into a separate reference clone. The original Showcase was not checked out, edited or used as a Store.

The C009 result bytes at both `bd4fe89f13b286f127f1fc336a860318be109119` and the frozen reference have SHA-256 `9928d7f71233ee931005bfe1f8b4cc5d34cdf61fd315d91b217e65686f5c7c0f`.

## Actual baseline execution paths

- Definition: `TaskDefinition -> Registry.parse/bind -> platform_tasks.check_definition -> task family validator`. Goal, environment, initializer, clocks and evaluator are frozen in the SessionInput.
- Active generation/control: `FamilySpaceV2 -> generated_serial.generate_family/authorize -> compiler.resolve -> scene.assemble -> registered controller preparation -> backend -> signals`. Full COM tensors and independent tendon transmissions already exist.
- Mathematical research: the Main `research_analysis` interface reaches `analysis.dispatch`, original method authorization/admission and the existing Worker. Model/solver declarations are registered, but a general candidate-bound Platform Registry tool was missing. The new `research.math` delegates to this same dispatcher.
- Physical evidence: `Host.invoke -> reservation -> simulation/evaluation -> immutable Store`. Native orientation uses explicit sequence optimization and `physical_replay`, not position-only NMPC.
- Passive research: `task.passive_response -> no_active_control -> PassiveBackend -> staged passive evidence -> passive_evaluation_v2`. Existing KKT, tangents, compliance and sensitivities are conditional mathematical evidence, not dynamic acceptance.
- Reporting: saved results flow through result cards and Reporter; trace/cost records existed, but original public requests, source schemas and raw usage were not uniformly exported for replay.

## Per-task, eight-level original matrix

Columns: specification / adapter / generation / math Registry entry / backend / evaluator / Main-Reporter / Store-trace-cost.

| Task | Original statuses |
|---|---|
'''
    audit+='\n'.join('| '+task+' | '+' / '.join(BEFORE[task])+' |' for task in BEFORE)
    audit+='\n\n'+''.join('### '+v['task_id']+' '+v['name']+'\n\n'+NOTES[v['task_id']]+'\n\n'+
        ('Original gap: safe figure-eight reference/phase semantics, complete tracking constraints and prepared initialization were not exposed.\n\n' if v['task_id']=='T04' else
         'Original gap: one-floor assembly could not express the button slide, moving body, native pair force or environment state. NativeModel rejects the extra state/contact, and remains mathematically scoped accordingly.\n\n' if v['task_id']=='T09' else
         'Original gap: only constant control-grid COM loads, with no half-sine environment schedule, blind observation view, recovery evaluator or frozen-input condition.\n\n' if v['task_id']=='T10' else
         'Original chain existed through the task family and Main dispatcher. This change freezes its actual source definition, exposes Registry entrypoints and adds uniform evidence/replay records.\n\n') for v in rows)
    audit+='''## Related branch review

| Branch | Review outcome |
|---|---|
| codex/m1-ablation-gates-20261111 | Method-level authorization and temporal resolution/knot grants reviewed. Experimental ablation gates and quota addenda were not imported; existing authorization remains authoritative. |
| codex/p3-ablation-gates-20261112 | Passive mathematical/research gates reviewed. No ablation configuration, experimental state or altered method set imported. |
| codex/p3-account3-resume-fix-20261112 | Account/gateway/resume changes excluded as unrelated. No credentials, sessions or quota recovery copied. |
| codex/p3-intent-projection-revision-20261112 | Main intent projection/knowledge restoration reviewed. No historical knowledge store or experiment artifacts imported. |
| codex/p3-structured-direct-math-20261112 | Candidate-bound Direct Math and shared model-evaluator extraction reviewed. The existing baseline methods suffice for this interface work; no algorithm or branch-wide merge was needed. |

Only a source-verified P3 task-data translation is reused from the local prior task definitions. Its `protocol_source` must equal the canonical hash of frozen Showcase P3/task.json before the importer accepts it. No historical candidate/Store or task-specific solver is copied.

See `TASK_CAPABILITY_MATRIX.json` for before/after status and concrete module references for each of the eight levels. Missing P3 regression evidence is represented separately from available evaluator code. No capability is inferred from historical success alone.
'''
    write('TASK_CAPABILITY_AUDIT.md',audit)
    regtable='\n'.join('| '+x['task_id']+' | '+x['condition_id']+' | '+x['regression']+' | '+x.get('historical_status','')+' |' for x in regression['records'])
    write('EVALUATOR_REGRESSION_REPORT.md',f'''# Evaluator regression report

Frozen reference: `{regression['reference_commit']}`. Actual outcome: **{regression['counts']['PASS']} PASS, {regression['counts']['FAIL']} FAIL, {regression['counts']['PARTIAL']} PARTIAL**. These are read-only regressions, not new physical solutions.

| Task | Condition | Regression | Archived outcome |
|---|---|---|---|
{regtable}

Position/axis/hold metrics are recomputed from saved full-step CSVs, with exact original formal sample selection. Figure-eight phase is checked against the original source function; drift uses the original monotone phase interpolation, and tendon speed uses the original gradient definition for this historical evaluator. Spring Button and M7 additionally run their original evaluator functions as offline test oracles. Source strict/inclusive comparisons and tolerances are retained, including strict button release force and the original strict figure-eight inequalities. Invalid/missing/nonfinite data is never scored as success.

Source limitations: M1–M6/C1 saved solver-error counts are original aggregate metadata, not reconstructed per-step warning observations. Figure-eight NPZ lacks per-step contacts/warnings; its original recorded aggregate maxima are explicitly labeled as regression metadata. P3 legacy Store recovery verified eight cases and 1,600,000 CSV rows, original evaluator results and current Core stiffness metrics; current v2 complete-state/binding proofs remain a distinct format gap. Its original PASS is retained; full v2 evidence equivalence is not asserted. No synthetic trajectory fills these gaps.

All per-metric comparisons, source hashes, margins and failed checks are in `EVALUATOR_REGRESSION_RESULTS.json`. The original Showcase is unchanged; C009 result hash remains `{regression['protected_c009_sha256']}`. Provider sends, optimizations and integrated physics steps for this regression: 0.
''')
    write('TEST_REPORT.md',f'''# Offline test report

Actual final run: **{tests['tests_run']} tests, {tests['passed']} passed, {len(tests['failures'])} failures, {len(tests['errors'])} errors, {len(tests['skipped'])} skipped**. Complete output, interpreter and dependency versions: `TEST_RESULTS.json`.

CLI validation passed for all {len(cli['records'][0]['result']['protocols'])} frozen protocols and {cli['records'][1]['result']['registered_extensions']} Registry declarations (`CLI_VALIDATION.json`). Local setuptools built `{package['wheel']}` with {package['protocol_asset_count']} protocol/source assets and no missing required files. The extracted wheel independently passed the same protocol/Registry CLI checks, without installing dependencies or contacting a package index (`PACKAGE_VALIDATION.json`). An earlier pip attempt failed at its Windows temporary-directory ACL before compilation; its actual error is retained in that artifact.

Measured/enforced test counters: `{json.dumps(tests['execution_counters'],sort_keys=True)}`. Static `mj_forward` and XML compilation are model-interface checks, not trajectory validation. Mock Host/Worker calls are labeled in test names and do not certify physical performance.

Coverage includes all ten protocol schemas/Registry families; all existing active case configuration admissions; four independent channels and duplicate-map rejection; fixed M2 structure; reference phase, derivative and endpoint tail; source-directed axis; static full-inertia/button XML; true native contact observation; actual world COM wrench; blind identical M7 controller views and reference clock; frozen input ownership; strict/boundary/missing/nonfinite evaluator behavior; protected historical results; Store evidence and Reporter cards; original Main mathematical delegation; permissions, receipts, exhaustion, idempotency and exact request/schema export; raw role usage/unavailable fields.

Earlier development runs exposed and fixed: a missing `tip_tool_axis` declaration on the unified backend; source-builder mismatch in a test fixture that changed its tool without changing its frozen prototype; an invalid Reach settling configuration used for Tracking; a string-provider usage parsing error; Windows temporary-directory ACL/SQLite cleanup problems; an invalid dictionary literal in the controller provenance view; the strict Study merge rejecting registry_tools; new fixture path/grant-ID/output-envelope assumptions in its formal-entry regression. These failed runs were not reported as passes. Final failures/errors are listed in the JSON (empty when all pass).

Not executed by design: Provider sends, formal Main/Reporter sessions, mathematical/structural/controller optimization, real Workers, candidate searches, independent dynamic verification, `mj_step`, multi-case physical integration and new successful structures. Native contact-aware mathematics and full orientation NMPC remain unsupported; supported task routes use existing controllers/native sequence methods as documented. P3 full historical regression remains a source gap, not a passing test.

Reproduce with the project runtime:

```powershell
$env:SOFTROBOT_AGENT_HOME = '<isolated writable data directory>'
$env:SOFTROBOT_SHOWCASE_REFERENCE = '<read-only checkout at 2e5d108>'
python -m tools.development.run_offline_checks --output TEST_RESULTS.json
python -m tools.development.offline_regression --reference $env:SOFTROBOT_SHOWCASE_REFERENCE --output EVALUATOR_REGRESSION_RESULTS.json
python -m tools.research protocol-validate
```
''')


if __name__=='__main__':build()
