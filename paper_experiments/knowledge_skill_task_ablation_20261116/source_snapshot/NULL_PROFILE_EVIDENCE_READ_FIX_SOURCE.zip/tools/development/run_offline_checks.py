"""Persist actual unittest outcomes and enforced execution boundaries."""
import argparse
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import sys
import time
import unittest
from tools.paths import ROOT


def run():
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_ten_task_interfaces.py')
    stream=io.StringIO();start=time.perf_counter()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    module=sys.modules['test_ten_task_interfaces']
    dependencies={}
    for name in ('pydantic','numpy','scipy','mujoco','casadi','jsonschema','strands-agents','strands-harness'):
        try:dependencies[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:dependencies[name]='unavailable'
    return dict(phase='offline_interface_validation',tests_run=result.testsRun,passed=result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
        failures=[dict(test=str(t),traceback=trace) for t,trace in result.failures],errors=[dict(test=str(t),traceback=trace) for t,trace in result.errors],
        skipped=[dict(test=str(t),reason=reason) for t,reason in result.skipped],success=result.wasSuccessful(),
        duration_s=time.perf_counter()-start,python=sys.version,executable=sys.executable,platform=platform.platform(),dependencies=dependencies,
        execution_counters=module.COUNTERS,
        boundaries='mj_step, network sends, optimizer entrypoints and real Workers are blocked. Only model XML compilation and mj_forward are permitted. Mock calls never become physical verification.',
        log=stream.getvalue())


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='TEST_RESULTS.json');args=parser.parse_args()
    result=run();Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({k:result[k] for k in ('tests_run','passed','success','execution_counters')}))
    raise SystemExit(not result['success'])
