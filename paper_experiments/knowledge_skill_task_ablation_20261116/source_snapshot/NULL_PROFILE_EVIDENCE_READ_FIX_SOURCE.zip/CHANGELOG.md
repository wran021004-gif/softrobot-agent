# Changelog

## 0.2.4 — 2026-11-13

- Freeze source-owned geometric tendon stroke and speed limits for Reach/Axis tasks T01/02/03/05/06/07. Check complete physics-state observations, including the initial state, independently of the original goal/holding sampling windows.
- Expose these limits to the existing native response optimizer through its existing norm-constraint interface. Observe dense native extrema and count the additional forward evaluations; no optimizer, controller or integration algorithm is added.
- Preserve historical oracle regression separately from full current acceptance. Legacy trajectories without dense tendon observations remain incomplete for the full envelope and cannot be upgraded to a new pass.
- Affected frozen Studies require versioned re-execution with only their remaining authorized quota. Keep original results, actual implementation SHAs and cumulative costs. P3's protocol, passive evaluator, recorder and source kernels are unchanged.

## 0.2.3 — 2026-11-13

- Fix frozen multi-condition aliases inheriting an exact protocol binding for a different case. The original parent proof remains immutable; the new alias uses its existing frozen-condition identity checks.
- Preserve and replace the specific legacy invalid cached alias, with the previous artifact referenced in provenance. Read-only lookup never repairs state, and normal cached aliases remain verified.
- Add two offline regressions, including legacy-cache recovery and task-tampering rejection. All 45 tests pass without integration, optimization, Provider calls or real Workers.
- This is a research binding metadata repair. Scientific source hashes and scientific Registry dependencies are unchanged; actual earlier execution commits and cumulative budgets must remain visible through explicit implementation rebinding.

## 0.2.2 — 2026-11-12

- Fix the strict formal Study resolver rejecting the new explicit Registry tool grants before composition. Add a complete offline prepare/bind/Host/Plan/generator regression using a new mock grant.
- This issue was found before the first new scientific candidate or integration; the batch is refrozen from 42d4e81 before any solve.

## 0.2.1 — 2026-11-12

- Add registered read-only legacy passive evidence recovery, pinned source/oracle hashes, full CSV grid/force/route checks and current stiffness regression.
- Recover the original eight P3 cases and 1,600,000 physical-step rows without altering source Stores or transferring historical candidates.
- Extend the existing passive CSV with actual material-point observations, full constraint-row arrays, classifications, route status and solver warm state on every successful physical step.
- Preserve the distinction between complete legacy regression, partial current v2 complete-state equivalence and a future new Study result. No algorithm or controller was added.

## 0.2.0 — 2026-11-12

- Add source-frozen protocols and shared registered research entrypoints for T01–T10; T04 is figure-eight tracking, never legacy M4.
- Add safe parameterized references, prepared-equilibrium qualification, native dynamic environment/contact/slide/spring support, blind world-COM disturbance injection and dense typed observations.
- Preserve original task hold/axis/multi-case/passive/contact/recovery evaluation semantics, per-check margins and expected-failure control cases.
- Expose existing mathematical/Plan dispatch through Registry and existing Main; add source-bound candidate adaptation and Reporter cards.
- Add Store-derived replay export, exact original public/native/Worker requests, raw role usage and separate computation/budget records.
- Add guarded offline tests and historical regression reports. No research solution, Provider request, optimization, physical integration or Main replay is included.
- Keep original main/Showcase/C009/PHS2D data unchanged. P3 source status is preserved; complete historical P3 regression remains unavailable and is not labeled Ready.

Compatibility: new optional fields retain legacy serialized shape when absent or at their legacy default. New implementation/schema hashes require an explicitly bound new session or the existing migration procedure. No existing Study, account state, quota or branch is automatically modified.
