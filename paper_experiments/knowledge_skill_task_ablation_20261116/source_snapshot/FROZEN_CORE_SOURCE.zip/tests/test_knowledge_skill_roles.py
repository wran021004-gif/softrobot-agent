"""Focused migration and real Store retrieval checks; no Provider or physics."""
from pathlib import Path
from types import SimpleNamespace
import json
import os
from uuid import uuid4
import unittest
from unittest.mock import patch
from tools.platform_store import Store
from tools.research import experience
from tools.research.contracts import KnowledgePolicy
from tools.research.state import update


class ResourceRoles(unittest.TestCase):
    def setUp(self):
        root=Path(os.environ['SOFTROBOT_AGENT_HOME'])/'focused-tests'/uuid4().hex
        root.mkdir(parents=True)
        self.anchor=patch('tools.platform_store.RUNS',root/'authority');self.anchor.start();self.addCleanup(self.anchor.stop)
        self.store=Store(root/'store')
        self.store.create(dict(project_id='focused-test',grant_id='focused-test',authorization_source='offline focused tests',
            budget=dict(tool_calls=50,model_calls=0,backend_solves=0,worker_calls=0,wall_s=None)))
        self.store.create_session(dict(input=dict(run_id='test')))
        self.host=SimpleNamespace(store=self.store,run_id='test')

    def configure(self,roles):
        policy=KnowledgePolicy(organization='typed_knowledge_v1',allowed_resource_roles=roles).model_dump(mode='json')
        frozen=experience.freeze_knowledge(policy)
        update(self.host,spec=dict(study_id='test',knowledge=policy,knowledge_manifest=frozen),retrievals=[])
        return frozen

    def test_four_conditions_metadata_and_exact_reads(self):
        for roles in ([],['knowledge'],['skill'],['knowledge','skill']):
            with self.subTest(roles=roles):
                frozen=self.configure(roles)
                reply=experience.retrieve(self.host,dict(operation='search'))
                self.assertEqual(reply['matched_count'],len(frozen['entries']))
                self.assertFalse(reply['scientific_evidence'])
                self.assertTrue(all(r['resource_role'] in roles for r in reply['results']))
                self.assertTrue(all('content' not in r for r in reply['results']))
                for row in frozen['entries']:
                    read=experience.retrieve(self.host,dict(operation='read',entry_id=row['entry_id'],revision=row['revision']))
                    self.assertEqual(read['results'][0]['exact_key'],row['entry_id']+'@'+row['revision'])
                    self.assertEqual(self.store.artifact(read['reference'])['results'],read['results'])
                if not roles:self.assertEqual(reply['results'],[])

    def test_denied_exact_reads_do_not_reveal_metadata(self):
        for roles,blocked in (([],('skill-parameter-model','4')),(['knowledge'],('skill-parameter-model','4')),
                              (['skill'],('research-contact-causality-principle','1'))):
            self.configure(roles)
            with self.assertRaisesRegex(ValueError,'EXACT_EXPERIENCE_READ_REQUIRES_ONE_ENTRY_AND_REVISION'):
                experience.retrieve(self.host,dict(operation='read',entry_id=blocked[0],revision=blocked[1]))
        with self.assertRaisesRegex(ValueError,'EXPERIMENT_READ_REQUIRES_ENTRY_ID_AND_REVISION'):
            experience.retrieve(self.host,dict(operation='read',key='skill-parameter-model@4'))

    def test_frozen_rows_also_filtered_and_dispositions_require_reads(self):
        both=self.configure(['knowledge','skill'])
        with self.store.transaction() as db:
            state=self.store.session('test',db)['state'];state['spec']['knowledge']['allowed_resource_roles']=['knowledge']
            self.store.update_state(db,'test',state)
        self.assertTrue(all(r['resource_role']=='knowledge' for r in experience.entries(self.host)))
        with self.assertRaises(ValueError):experience.disposition_bindings(self.host,{'research-contact-causality-principle@1':'adopted'})
        receipt=experience.retrieve(self.host,dict(operation='read',entry_id='research-contact-causality-principle',revision='1'))
        bindings=experience.disposition_bindings(self.host,{'research-contact-causality-principle@1':'adopted'})
        self.assertEqual(bindings[0]['read_receipt'],receipt['reference'])

    def test_existing_content_integrity_is_retained(self):
        frozen=self.configure(['knowledge'])
        row=frozen['entries'][0];row['content_sha256']='0'*64
        update(self.host,spec=dict(study_id='test',knowledge=dict(organization='typed_knowledge_v1',allowed_resource_roles=['knowledge']),knowledge_manifest=frozen))
        with self.assertRaisesRegex(ValueError,'FROZEN_KNOWLEDGE_CONTENT_CHANGED'):
            experience.retrieve(self.host,dict(operation='read',entry_id=row['entry_id'],revision=row['revision']))

    def test_original_33_bodies_and_restrictions(self):
        import csv
        core=Path(__file__).resolve().parents[1];work=core.parents[1]
        experiment=work/'paper_experiments/knowledge_skill_codex_replay_20261116'
        source=work/'.worktrees/u1-u2-general-task-adaptation'
        original=json.loads((source/'memory/diagnostic_index.json').read_text(encoding='utf8'))['entries']
        with (experiment/'RESOURCE_MIGRATION_MANIFEST.csv').open(encoding='utf8') as stream:
            manifest=list(csv.DictReader(stream))
        self.assertEqual(len(manifest),33)
        bodies=[]
        for row in original:
            dest=next(r for r in manifest if (r['original_entry'],r['original_revision'])==(row['entry_id'],row['revision']))
            body=(source/row['path']).read_bytes();bodies.append(body)
            self.assertEqual(body,(core/dest['new_resource_location']).read_bytes())
        self.assertEqual(len(set(bodies)),33)
        frozen=self.configure(['knowledge','skill'])
        self.assertFalse(any(r.get('benchmark_sensitive') for r in frozen['entries']))
        self.assertFalse(any(r['revision']=='draft' for r in frozen['entries']))
        self.assertEqual(sum(r['entry_id'].endswith('-principle') for r in frozen['entries']),8)

    def test_legacy_policy_serialization_and_aliases(self):
        self.assertNotIn('allowed_resource_roles',KnowledgePolicy().model_dump(mode='json'))
        self.assertTrue(experience._role_permitted(dict(kind='case',resource_role='experience'),dict(allowed_resource_roles=['knowledge'])))
        self.assertTrue(experience._role_permitted(dict(kind='procedure',resource_role='expert_process'),dict(allowed_resource_roles=['skill'])))


if __name__=='__main__':unittest.main()
