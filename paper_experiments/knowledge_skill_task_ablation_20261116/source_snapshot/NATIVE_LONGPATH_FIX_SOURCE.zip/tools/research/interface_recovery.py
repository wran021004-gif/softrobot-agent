"""Explicit operator recovery after an evidenced pre-simulation I/O stop."""
from tools.research.state import state,save,update


def prelaunch_io_failure(result):
    execution=result.get('execution') or {}
    receipt=execution.get('receipts',{}).get('simulation') or {}
    return (result.get('status')=='execution_incomplete' and result.get('acceptance') is None
        and execution.get('stage')=='simulation' and receipt.get('execution_status')=='failed'
        and receipt.get('solver_status')=='not_run' and '[WinError 206]' in str(receipt.get('error')))


def resume_after_prelaunch_io_stop(host,*,user_authorization,reason):
    """Retain all charged costs/evidence; no scientific result is reclassified."""
    if user_authorization is not True or not reason:raise ValueError('EXPLICIT_OPERATOR_AUTHORIZATION_REQUIRED')
    s=state(host)
    if s['research_status']!='stopped' or s.get('selected') or s.get('success_gate') or s.get('pending'):
        raise ValueError('ONLY_UNSELECTED_STOPPED_IO_EPISODE_CAN_RESUME')
    with host.store.connect(True) as db:
        if db.execute('SELECT count(*) FROM calls WHERE receipt IS NULL').fetchone()[0]:raise ValueError('UNSEALED_OPERATION_RETAINS_HOLD')
    failures=[(ref,host.store.artifact(ref)) for ref in s.get('results',[])]
    if not failures or not all(prelaunch_io_failure(value) for _,value in failures):
        raise ValueError('EXACT_PRELAUNCH_IO_FAILURE_EVIDENCE_REQUIRED')
    if any((host.store.artifact(ref).get('profile') or {}).get('complete') for ref in s.get('physical_replays',[])):
        raise ValueError('COMPLETED_PHYSICAL_EPISODE_REQUIRES_SEPARATE_REVIEW')
    before=host.store.remaining(host.run_id)
    proof=save(host,dict(user_authorization=True,reason=reason,original_final_disposition=s.get('final_disposition'),
        original_closed_unix=s.get('closed_unix'),failure_references=[ref for ref,_ in failures],
        retained_costs=before,scientific_failure=False,new_scientific_executions=0,budgets_reset=False),
        'operator_authorized_prelaunch_io_continuation')
    update(host,research_status='ready',final_disposition=None,closed_unix=None,
        interface_continuations=[*s.get('interface_continuations',[]),proof])
    assert before==host.store.remaining(host.run_id)
    return proof
