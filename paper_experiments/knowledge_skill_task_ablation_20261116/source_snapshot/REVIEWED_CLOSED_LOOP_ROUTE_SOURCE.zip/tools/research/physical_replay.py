"""One candidate-bound fixed-tension MuJoCo rollout and existing task settlement."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import time

import numpy as np

from schemas.platform import BackendResult, Payload, Signal, SessionInput
from tools.platform_store import plain, zero, Store
from tools.state_io import atomic_json, digest, read,io_path
from tools.research.state import state, update, save, guard
from tools.research.design import verify_candidate


def numerically_verified_source(value):
    """Keep legacy witness meaning; explicitly version complete failing controls."""
    if value.get('source_kind')=='independently_integrated_control_v1':
        proof=value['integration_verification'];trajectory=value['trajectory']
        return (proof['complete'] and proof['maximum_root_residual_inf']<1e-9 and
            proof['root_count']==len(trajectory['tensions_n'])*trajectory['integration_substeps'])
    proof=value.get('posthoc_verification',{})
    return (value.get('source_kind')=='verified_mathematical_trajectory' and
        proof.get('checks',{}).get('repaired_verification_passed',False) and
        proof.get('original_task_satisfied') is not False)


def explicit_control_source(value):
    """An executable schedule carries no mathematical feasibility assertion."""
    return (value.get('source_kind')=='explicit_control_schedule_v1'
        and value.get('task_acceptance')=='unmeasured'
        and bool(value.get('provenance')))


def legal_control_sources(host, candidate, selected=None):
    """Existing complete schedules, deduplicated by exact bound trajectory."""
    s=state(host);configuration=verify_candidate(host,candidate)['configuration']
    sources=[r['source'] for r in s.get('control_initializations',[]) if r['candidate']==candidate]
    for ref in s.get('analysis_results',[]):
        raw=host.store.artifact(ref,paths=('candidate','control_schedule_reference'))
        if raw.get('candidate')==candidate and raw.get('control_schedule_reference'):
            sources.append(raw['control_schedule_reference'])
    legal=[];trajectories=[]
    for ref in ([selected] if selected else sources):
        if ref in legal:continue
        try:
            raw=host.store.artifact(ref)
            if not (explicit_control_source(raw) or numerically_verified_source(raw)):continue
            binding(configuration,raw['trajectory'])
        except (ValueError,KeyError):continue
        if raw['trajectory'] not in trajectories:
            legal.append(ref);trajectories.append(raw['trajectory'])
    return legal


def schedule_identity(configuration, trajectory):
    """Exact executed inputs plus physical/task binding, independent of provenance."""
    bound={k:trajectory[k] for k in ('times_s','tensions_n','tendon_order','task_identity','model_identity','design_identity')}
    # Adding a zero correction turns -0.0 into +0.0; this is the same physical input.
    bound['tensions_n']=[[0. if u==0 else u for u in row] for row in trajectory['tensions_n']]
    return digest(dict(robot=configuration['robot'],task=configuration['task'],seed=configuration['seed'],
        physics={k:configuration['policy'][k] for k in ('backend','discretization','dynamics_model')},
        trajectory=bound))


def evaluate_schedule(host, candidate, source, plan_factory, *, origin='engineering'):
    """Reuse completed Store results, including settlement before a driver crash.

    There is no second cache or budget: the Store owns durable receipts and
    cumulative costs. An unfinished request must be recovered, never relaunched.
    """
    from tools.research import core
    cfg=verify_candidate(host,candidate)['configuration']
    binding(cfg,source['trajectory'])
    identity=schedule_identity(cfg,source['trajectory'])
    for ref in state(host).get('physical_replays',[]):
        result=host.store.artifact(ref);previous=host.store.artifact(result['source_reference'])
        prior_cfg=host.store.artifact(result['candidate'])['configuration']
        if schedule_identity(prior_cfg,previous['trajectory'])==identity:
            return dict(reference=ref,**result),True
    if host.store.remaining()['remaining']['backend_solves']<1:
        raise ValueError('PHYSICAL_REPLAY_LAUNCH_BUDGET_EXHAUSTED')
    source_ref=save(host,source,'bound_applied_control_schedule')
    result=core.dispatch(host,plan_factory('physical_replay',physical_replay=dict(candidate=candidate,source=source_ref)),
        'schedule-'+identity,origin=origin)['result']
    return result,False


def model_context(configuration):
    from extensions.tendon_family.sorosim_control import checked_control
    from extensions.tendon_family.sorosim_spec import SorosimModel
    from extensions.tendon_family.backends import physics_for
    from extensions.tendon_family.scene import assemble

    inp=SessionInput.model_validate(configuration)
    if inp.policy.controller.extension_id in ('controller.gvs_nmpc','controller.native_state_feedback'):
        from extensions.tendon_family.gvs_basis import resolve_basis
        physics=physics_for(inp);scene=assemble(inp,physics)
        # Use the existing physical execution identity, never the affine model hash.
        spec=dict(identity=scene['experiment_spec']['dynamics_model_identity'],design_identity=physics['design_identity'],
            coordinate_order=(list(physics['dofs']) if inp.policy.controller.extension_id=='controller.native_state_feedback' else
                list(resolve_basis(inp.robot.structure.data,inp.policy.controller.parameters.data['recipe']['basis']).coordinate_order)),
            tendon_order=[t['entity'] for t in physics['tendons']])
        return inp,physics,scene,spec
    control=checked_control(inp)
    spec=SorosimModel(dict(basis=control.recipe.basis,
        gauss_per_interval=control.solver.gauss_per_interval)).convert(
        inp.robot.structure.data,inp.policy.discretization.data,inp.task.environment.data,solver=control.solver)
    physics=physics_for(inp);scene=assemble(inp,physics)
    return inp,physics,scene,spec


def initialize_schedule(configuration, source, parent):
    """Explicit same-channel initialization for a new design; no acceptance transfer."""
    from copy import deepcopy
    inp,physics,scene,spec=model_context(configuration)
    tr=deepcopy(source['trajectory']);order=[t['entity'] for t in physics['tendons']]
    if tr['tendon_order']!=order:raise ValueError('UNSUPPORTED_CROSS_TOPOLOGY_CONTROL_INITIALIZATION')
    tr.update(model_identity=spec['identity'],design_identity=spec['design_identity'],task_identity=digest(plain(inp.task)))
    binding(configuration,tr)
    return dict(source_kind='explicit_control_schedule_v1',task_acceptance='unmeasured',trajectory=tr,
        provenance=dict(control_initialization='same_channels_new_candidate_binding_v1',parent=plain(parent),
            inherited_acceptance=False,source_provenance=source['provenance']))


def seed_control(host, request, operation_key=None, plan=None):
    """Candidate-owned bounded inputs; explicit ZOH time/channel transfer or pretension."""
    started=time.perf_counter()
    try:
        if request.condition_id is not None:
            from schemas.platform import EvidenceRef
            from tools.research.conditions import condition_candidate
            candidate=condition_candidate(host,request.candidate,request.condition_id)
            request=request.model_copy(update=dict(candidate=EvidenceRef.model_validate(candidate),condition_id=None))
        if request.method=='capability_sequence':return capability_seed(host,request,operation_key)
        if request.method!='baseline':return guided_seed(host,request,operation_key,plan)
        return _seed_control(host,request,operation_key)
    finally:
        elapsed=time.perf_counter()-started;s=state(host)
        update(host,numerical_s=s['numerical_s']+elapsed,
            control_initialization_s=s.get('control_initialization_s',0.)+elapsed)


def _seed_control(host,request,operation_key):
    cfg=verify_candidate(host,request.candidate)['configuration']
    inp,physics,scene,spec=model_context(cfg)
    period=inp.task.timing.control_period_s
    count=round(inp.task.timing.duration_s/period)
    order=[t['entity'] for t in physics['tendons']]
    tendons={t['id']:t for t in cfg['robot']['structure']['data']['tendons']}
    inputs=np.tile([tendons[t]['pretension_n'] for t in order],(count,1))
    provenance=dict(control_initialization='bounded_candidate_control_v1',inherited_acceptance=False,
        parent=plain(request.parent),source=plain(request.source),channel_map=request.channel_map,operation_key=operation_key,
        time_rule='zero-order hold; hold last input beyond source horizon; new channels use candidate pretension')
    if request.source:
        parent=host.store.artifact(request.parent)
        source=host.store.artifact(request.source,paths=('candidate','execution_id','trajectory','control_schedule_reference','independent_evaluation_executed'))
        if not source.get('trajectory') and not source.get('execution_id'):
            raise ValueError('CONTROL_INITIALIZATION_REQUIRES_EXECUTABLE_SOURCE')
        if source.get('execution_id') and not source.get('trajectory'):
            from tools.research.rl import measured_nmpc_trajectory,measured_rl_trajectory
            rl_source=bool(source.get('independent_evaluation_executed'))
            if plain(request.parent)!=plain(request.candidate) or source.get('candidate')!=plain(request.candidate) or request.channel_map is not None:
                raise ValueError('EXACT_NMPC_CANDIDATE_WITHOUT_CHANNEL_MAPPING_REQUIRED')
            trajectory,origin=(measured_rl_trajectory(host,request.source) if rl_source else
                measured_nmpc_trajectory(host,request.source))
            source=dict(trajectory=trajectory)
            provenance.update(source_kind='measured_rl_evaluation_v1' if rl_source else 'measured_nmpc_execution_v1',**origin)
        binding(parent['configuration'],source['trajectory'])
        old=source['trajectory'];old_order=old['tendon_order']
        mapping=request.channel_map
        if mapping is None:
            # Unequal topology gets a new baseline, never an implicit channel copy.
            mapping=dict(zip(order,old_order)) if order==old_order else {}
        if set(mapping)-set(order) or set(mapping.values())-set(old_order):
            raise ValueError('CONTROL_CHANNEL_MAP_OUTSIDE_CANDIDATES')
        indices=np.clip(np.searchsorted(old['times_s'],np.arange(count)*period+1e-12,side='right')-1,
            0,len(old['tensions_n'])-1)
        for name,original in mapping.items():
            inputs[:,order.index(name)]=np.asarray(old['tensions_n'])[indices,old_order.index(original)]
        provenance['effective_channel_map']=mapping
    elif request.tensions_n is not None:
        inputs=np.asarray(request.tensions_n,dtype=float)
        if inputs.shape==(1,len(order)):inputs=np.repeat(inputs,count,axis=0)
    elif request.tension_knots is not None:
        inputs=expand_tension_knots(request.tension_knots,period,count,len(order))
        provenance.update(tension_knots=plain(request.tension_knots),
            time_rule='linear interpolation at control interval starts, then zero-order hold; no inherited acceptance')
    trajectory=dict(times_s=[i*period for i in range(count+1)],tensions_n=inputs.tolist(),
        tendon_order=order,model_identity=spec['identity'],design_identity=spec['design_identity'],
        task_identity=digest(plain(inp.task)))
    binding(cfg,trajectory)  # Reject bounds, dimensions and ineffective execution modes.
    source=save(host,dict(source_kind='explicit_control_schedule_v1',task_acceptance='unmeasured',
        trajectory=trajectory,provenance=provenance),'candidate_control_initialization')
    entry=dict(candidate=plain(request.candidate),source=source,task_acceptance='unmeasured')
    update(host,control_initializations=[*state(host).get('control_initializations',[]),entry])
    return entry


def expand_tension_knots(knots,period,count,channels):
    if abs(knots.times_s[-1]-period*count)>1e-10 or len(knots.tensions_n[0])!=channels:
        raise ValueError('TENSION_KNOTS_MUST_SPAN_FROZEN_TASK_AND_CHANNELS')
    values=np.asarray(knots.tensions_n);times=np.arange(count)*period
    return np.column_stack([np.interp(times,knots.times_s,values[:,j]) for j in range(channels)])


def capability_seed(host,request,operation_key=None):
    """Registered SOCP witness -> existing ZOH schedule; no solve or physical launch."""
    from schemas.platform_analysis import EndpointLinearizedModel, TaskAnalysisProtocol, TaskAnalysisRequirement
    from extensions.math_analysis.trajectory import prepare_trajectory, verify_witness
    from tools.research.optimal_capability import CONIC
    from tools.research.task_constraints import describe_analysis_requirements
    s=state(host);reference=plain(request.response_evidence)
    if reference not in s.get('analysis_results',[]):raise ValueError('REGISTERED_CURRENT_ANALYSIS_REQUIRED')
    candidate=verify_candidate(host,request.candidate);cfg=candidate['configuration'];raw=host.store.artifact(reference)
    tr=raw.get('trajectory') or {}
    if (raw.get('candidate')!=plain(request.candidate) or raw.get('implementation')!=s['freeze']
            or raw.get('status')!='computed' or raw.get('operation')!='task_capability'
            or tr.get('method_version')!=CONIC or raw.get('optimal_sensitivity')
            or raw.get('requested_operation',{}).get('capability_method')!=CONIC):
        raise ValueError('CURRENT_CANDIDATE_FROZEN_SOCP_RESULT_REQUIRED')
    m=EndpointLinearizedModel.model_validate(raw['model']);p=TaskAnalysisProtocol.model_validate(raw['protocol'])
    req=TaskAnalysisRequirement.model_validate(raw['task_analysis']);outer=raw['binding']
    inp,physics,scene,execution=model_context(cfg)
    expected=dict(candidate=plain(request.candidate),candidate_id=candidate['candidate_id'],
        effective_configuration_identity=digest(cfg),task_identity=digest(cfg['task']),
        source_identity=candidate['source_identity'],tendon_order=execution['tendon_order'],
        coordinate_order=execution['coordinate_order'])
    if (any(outer.get(k)!=v or m.binding.get(k)!=v for k,v in expected.items())
            or plain(p)!=s['spec']['analysis_protocol'] or m.protocol_identity!=digest(plain(p))
            or m.binding.get('analysis_protocol_identity')!=m.protocol_identity
            or plain(req)!=plain(describe_analysis_requirements(inp,outer))
            or raw['operating_point']!=m.operating_point
            or raw['requested_operation'].get('operating_point') not in ('controller_start_input','standardized_initial_pretension')
            or any(v.units!='N' or v.dimension!=1 for v in m.input_definition)
            or [v.entity for v in m.input_definition]!=execution['tendon_order']):
        raise ValueError('SOCP_MODEL_TASK_INPUT_OR_OPERATING_POINT_MISMATCH')
    provenance=tr.get('provenance',{})
    if any(provenance.get(k)!=digest(v) for k,v in (
            ('model_identity',plain(m)),('requirement_identity',plain(req)),('protocol_identity',plain(p)))):
        raise ValueError('SOCP_NUMERICAL_PROVENANCE_MISMATCH')
    info=dict(coverage=[])
    scope,dynamics,initial,rows,lower,upper,_=prepare_trajectory(m,req,p,info,tr.get('initial_delta_state'))
    timing=inp.task.timing;count=round(timing.duration_s/timing.control_period_s)
    delta=np.asarray(tr.get('delta_input_n'),dtype=float);applied=np.asarray(tr.get('applied_input_n'),dtype=float)
    if (scope['start_time_s']!=0 or scope['step_count']!=count or p.period_s!=timing.control_period_s
            or p.duration_s!=timing.duration_s or tr.get('horizon')!=json.loads(json.dumps(scope))
            or np.any(initial!=0) or delta.shape!=(count,len(m.u0)) or applied.shape!=delta.shape
            or not np.isfinite(delta).all() or not np.isfinite(applied).all()
            or not np.allclose(applied,delta+np.asarray(m.u0),rtol=0,atol=1e-12)
            or np.any(delta.ravel()<lower) or np.any(delta.ravel()>upper)):
        raise ValueError('COMPLETE_ALIGNED_FINITE_BOUNDED_SOCP_SEQUENCE_REQUIRED')
    replay=verify_witness(m,dynamics,initial,delta,rows,scope,p.endpoint_check_atol)
    if (not tr.get('replay',{}).get('numerically_valid') or not replay.get('finite') or not rows
            or len(replay['records'])!=len(rows) or replay['max_prediction_replay_error']>p.endpoint_check_atol):
        raise ValueError('INDEPENDENT_SOCP_REPLAY_REQUIRED')
    trajectory=dict(times_s=[i*timing.control_period_s for i in range(count+1)],tensions_n=applied.tolist(),
        tendon_order=execution['tendon_order'],model_identity=execution['identity'],
        design_identity=execution['design_identity'],task_identity=digest(cfg['task']))
    binding(cfg,trajectory)
    source=save(host,dict(source_kind='explicit_control_schedule_v1',task_acceptance='unmeasured',inherited_acceptance=False,
        trajectory=trajectory,provenance=dict(control_initialization='capability_sequence_v1',operation_key=operation_key,
            mathematical_result=reference,local_model_identity=digest(plain(m)),
            mathematical_model_identity=m.binding['model_identity'],execution_model_identity=execution['identity'],
            input_identity=digest(applied.tolist()),independent_replay=replay,
            numerical_task_passed=replay['passed'],diagnostic_only=not replay['passed'],
            optimality_status=tr.get('optimality_status'),inherited_acceptance=False,
            time_rule='Complete original ZOH grid; no interpolation, truncation, padding or channel transfer')),
        'candidate_control_initialization')
    entry=dict(candidate=plain(request.candidate),source=source,task_acceptance='unmeasured')
    update(host,control_initializations=[*state(host).get('control_initializations',[]),entry])
    return entry


def verified_input_response(host,candidate,reference):
    """Side-effect-free handoff admission, shared by display and seed execution."""
    if plain(reference) not in state(host).get('analysis_results',[]):
        raise ValueError('REGISTERED_CURRENT_ANALYSIS_REQUIRED')
    cfg=verify_candidate(host,candidate)['configuration']
    if cfg['task']['family']!='task.reach':raise ValueError('NOT_APPLICABLE_SEED_REQUIRES_ENDPOINT_TARGET')
    analysis=host.store.artifact(reference);model=analysis.get('model') or {}
    bound=model.get('binding') or {};outer=analysis.get('binding') or {}
    inp,physics,scene,spec=model_context(cfg)
    expected=dict(candidate=plain(candidate),task_identity=digest(cfg['task']),
        effective_configuration_identity=digest(cfg),tendon_order=spec['tendon_order'])
    if (analysis.get('status')!='computed' or analysis.get('operation')!='input_sensitivity'
            or analysis.get('candidate')!=plain(candidate)
            or analysis.get('sensitivity',{}).get('verification',{}).get('passed') is not True
            or any(bound.get(k)!=v or outer.get(k)!=v for k,v in expected.items())
            or bound.get('model_identity')!=spec['identity']
            or model.get('operating_point')!=analysis.get('operating_point')
            or model.get('protocol_identity')!=digest(state(host)['spec']['analysis_protocol'])
            or bound.get('coordinate_order')!=spec['coordinate_order']):
        raise ValueError('VERIFIED_CANDIDATE_INPUT_SENSITIVITY_REQUIRED')
    return analysis


def guided_seed(host,request,key,plan):
    """Resolve trusted local evidence or charge complete public MuJoCo probes."""
    from copy import deepcopy
    from tools.research.control_seed import directed_inputs
    from tools.research.feedback import task_gap
    from tools.research.budget import backend_capacity, protected
    cfg=verify_candidate(host,request.candidate)['configuration']
    if cfg['task']['family']!='task.reach':raise ValueError('NOT_APPLICABLE_SEED_REQUIRES_ENDPOINT_TARGET')
    inp,physics,scene,spec=model_context(cfg);order=spec['tendon_order']
    channels=request.channels or order
    if not set(channels)<=set(order):raise ValueError('SEED_CHANNEL_OUTSIDE_CANDIDATE')
    indices=[order.index(c) for c in channels]
    if request.method=='mathematical_response':
        analysis=verified_input_response(host,request.candidate,request.response_evidence)
    else:
        required=len(indices)+1
        if required>request.evaluation_requests or required>backend_capacity(host):raise ValueError('INSUFFICIENT_SHARED_BUDGET_FOR_SEED_RESPONSE')
        if plan is None:raise ValueError('PHYSICAL_RESPONSE_REQUIRES_PUBLIC_PLAN')
    baseline=_seed_control(host,request.model_copy(update={'method':'baseline'}),key)
    source=host.store.artifact(baseline['source']);tr=source['trajectory']
    limits=np.array([{t['id']:t['force_limit_n'] for t in cfg['robot']['structure']['data']['tendons']}[c] for c in order])
    u=np.asarray(tr['tensions_n']);evidence=[];calls=[]
    if request.method=='mathematical_response':
        sensitivity=analysis['sensitivity'];model=analysis['model']
        u=np.tile(model['u0'],(len(u),1));position=np.asarray(model['y0']);response=np.asarray(sensitivity['dp_du'])
        evidence=[plain(request.response_evidence)]
    else:
        def factory(action,**payload):
            value={k:getattr(plan,k) for k in ('hypothesis','supporting_evidence','expected_observation','weakening_observation','fixed_conditions','stopping_condition','interpretation')}
            decision=plain(plan.decision);decision.update(research_intent='PHYSICAL_VALIDATION',requested_budget=1)
            return dict(value,action=action,decision=decision,**payload)
        response=np.zeros((3,len(order)))
        for j in [None,*indices]:
            if protected(host):raise ValueError('PROTECTED_BUDGET_BLOCKS_SEED_PROBES')
            trial=deepcopy(source)
            if j is not None:
                h=min(request.difference_step_n,float(np.min(limits[j]-u[:,j])))
                if h<1e-10:h=-min(request.difference_step_n,float(np.min(u[:,j])))
                if abs(h)<1e-10:return dict(status='no_input_room',candidate=plain(request.candidate),source=baseline['source'])
                moved=u.copy();moved[:,j]+=h;trial['trajectory']['tensions_n']=moved.tolist()
            result,cached=evaluate_schedule(host,request.candidate,trial,factory,origin='model')
            evidence.append(result['reference']);calls.append(dict(reference=result['reference'],cache_hit=cached))
            gap=task_gap(result)
            if gap['accepted']:return dict(status='first_original_task_pass',evaluation=result['reference'],candidate=plain(request.candidate),source=result['source_reference'])
            if not gap['valid_complete']:return dict(status='invalid_physical_response',evidence=evidence)
            raw=host.store.artifact(result['raw_reference']);endpoint=np.asarray(raw['samples'][-1]['tip_m'])
            if j is None:position=endpoint
            else:response[:,j]=(endpoint-position)/h
    fit=directed_inputs(u[:,indices],response[:,indices],np.asarray(cfg['task']['goal']['data']['target_m'])-position,
        limits[indices],request.trust_radius_n,request.regularization)
    provenance=dict(control_initialization=request.method,candidate=plain(request.candidate),evidence=evidence,
        task_identity=tr['task_identity'],model_identity=tr['model_identity'],operating_position_m=position.tolist(),
        channel_order=channels,settings=plain(request),response_diagnostic={k:v for k,v in fit.items() if k!='inputs'},
        physical_requests=calls,new_physical_evaluations=sum(not c['cache_hit'] for c in calls),
        limitations='Local constant input response; static mathematics and terminal physics do not certify dynamic holding constraints',
        inherited_acceptance=False,operation_key=key)
    diagnostic=save(host,provenance,'control_seed_response_diagnostic')
    if fit['status']!='generated':return dict(status=fit['status'],diagnostic=diagnostic,candidate=plain(request.candidate))
    u[:,indices]=fit['inputs'];source['trajectory']['tensions_n']=u.tolist();source['provenance']=provenance
    binding(cfg,source['trajectory'])
    source_ref=save(host,source,'candidate_directed_initialization')
    entry=dict(candidate=plain(request.candidate),source=source_ref,task_acceptance='unmeasured',diagnostic=diagnostic,method=request.method)
    update(host,control_initializations=[*state(host).get('control_initializations',[]),entry])
    return entry


def binding(configuration, trajectory, *, mathematical_outputs=None):
    inp,physics,scene,spec=model_context(configuration)
    timing=inp.task.timing;count=round(timing.duration_s/timing.control_period_s)
    order=[t['entity'] for t in physics['tendons']]
    u=np.asarray(trajectory['tensions_n'],dtype=float)
    configured_limits={t['id']:t['force_limit_n'] for t in configuration['robot']['structure']['data']['tendons']}
    limits=np.asarray([configured_limits[name] for name in order])
    if (trajectory['model_identity']!=spec['identity'] or trajectory['design_identity']!=spec['design_identity']
            or trajectory['task_identity']!=digest(plain(inp.task)) or trajectory['tendon_order']!=order
            or u.shape!=(count,len(order)) or not np.isfinite(u).all() or np.any(u<0) or np.any(u>limits)
            or len(trajectory['times_s'])!=count+1 or
            not np.isfinite(trajectory['times_s']).all() or
            any(abs(t-k*timing.control_period_s)>1e-12 for k,t in enumerate(trajectory['times_s']))
            or scene['control']['tension_execution_mode']!='ideal_tension'):
        raise ValueError('PHYSICAL_REPLAY_CANDIDATE_TASK_MODEL_OR_SEQUENCE_MISMATCH: '+json.dumps(dict(
            expected_tension_shape=[count,len(order)],received_tension_shape=list(u.shape),
            expected_time_points=count+1,received_time_points=len(trajectory['times_s']),
            tendon_order_matches=trajectory['tendon_order']==order,
            identity_matches={key:trajectory[key]==expected for key,expected in (
                ('model_identity',spec['identity']),('design_identity',spec['design_identity']),
                ('task_identity',digest(plain(inp.task))))},
            scope='Binding dimensions and identity facts; original bounds, timing and execution-mode checks still apply.'),separators=(',',':')))
    if mathematical_outputs is not None:
        outputs=mathematical_outputs
        if (outputs['model_identity']!=trajectory['model_identity'] or
                outputs['times_s']!=trajectory['times_s'] or outputs['samples']!=count+1 or
                np.asarray(outputs['tip_positions_m']).shape!=(count+1,3) or
                np.asarray(outputs['tip_velocities_m_s']).shape!=(count+1,3)):
            raise ValueError('MATHEMATICAL_OUTPUT_BINDING_MISMATCH')
    return inp,physics,scene


def calculate(request,folder):
    from extensions.tendon_family.backends import playback_tensions
    store=Store(request['store_root'])
    from tools.research.prepared_initial import validate as validate_initial
    validate_initial(store,request['configuration'])
    current=store.session(request['study_id'])['state']
    pending=current.get('pending') or {}
    row=store.lookup(request['study_id'],request['request_id'])
    if (not row or row['receipt'] or row['request_hash']!=digest(request)
            or pending.get('kind')!='physical_replay' or pending.get('worker_request_id')!=request['request_id']
            or Path(pending['folder']).resolve()!=Path(folder).resolve()):
        raise ValueError('OWNED_ACTIVE_PHYSICAL_REPLAY_RESERVATION_REQUIRED')
    if request.get('route')=='passive_protocol':
        from extensions.tendon_family.passive_execution import execute,source_binding
        expected=passive_source(request['configuration'],request['candidate'],request['passive_source'].get('execution',{}))
        if (request['passive_source']!=expected or pending.get('candidate')!=request['candidate'] or
                store.artifact(request['source_reference'])!=expected):
            raise ValueError('PASSIVE_WORKER_SOURCE_BINDING_MISMATCH')
        options=request['passive_source'].get('execution',{})
        if options.get('validation_source'):
            from extensions.tendon_family.passive_execution import execute_confirmation
            source_result,source_raw=resolve_passive_confirmation(store,request['study_id'],request['candidate'],request['configuration'],options)
            return execute_confirmation(SessionInput.model_validate(request['configuration']),folder,source_raw,
                options['validation_source'],source_result['execution_id']).data.data
        initial=resolve_passive_state(store,request['study_id'],request['candidate'],request['configuration'],options)
        if options.get('passive_ablation'):
            from extensions.tendon_family.passive_execution import execute_pair
            return execute_pair(SessionInput.model_validate(request['configuration']),folder,options['passive_ablation'],
                initial_state=initial,initial_state_result=options.get('initial_state_result')).data.data
        return execute(SessionInput.model_validate(request['configuration']),folder,initial_state=initial,
            initial_state_result=options.get('initial_state_result')).data.data
    inp,physics,scene=binding(request['configuration'],request['trajectory'])
    result=playback_tensions(inp,physics,scene,request['trajectory']['tensions_n'],folder)
    result.update(candidate=request['candidate'],source_reference=request['source_reference'],
        task_identity=digest(plain(inp.task)),mathematical_model_identity=request['trajectory']['model_identity'])
    source=store.artifact(request['source_reference'])
    if source.get('provenance',{}).get('control_initialization')=='capability_sequence_v1':
        result.update(execution_model_identity=request['trajectory']['model_identity'],
            mathematical_model_identity=source['provenance']['mathematical_model_identity'],
            local_model_identity=source['provenance']['local_model_identity'])
    return result


def passive_source(configuration,candidate,options=None):
    """Frozen protocol and explicit finite execution choices share one identity."""
    from extensions.tendon_family.passive_execution import source_binding
    from extensions.tendon_family.backends import physics_for
    from extensions.reference.passive_response import goal_definition
    from tools.research.contracts import PhysicalReplayRequest
    parsed=PhysicalReplayRequest.model_validate(dict(candidate=candidate,**(options or {})))
    options={k:plain(getattr(parsed,k)) for k in ('passive_ablation','initial_state_result','initial_state_episode','validation_source') if getattr(parsed,k) is not None}
    inp=SessionInput.model_validate(configuration);goal=goal_definition(inp.task)
    if options and goal.version!='passive_response_v2':raise ValueError('PASSIVE_V2_EXECUTION_CHOICES_REQUIRED')
    names=options.get('passive_ablation',[])
    if names and (goal.allowed_ablation!='disable_selected_passive_limits' or len(set(names))!=len(names)
            or set(names)-{t['entity'] for t in physics_for(inp)['tendons']}):raise ValueError('EXACT_GRANTED_PASSIVE_LIMIT_NAMES_REQUIRED')
    if bool(options.get('initial_state_result'))!=bool(options.get('initial_state_episode')):raise ValueError('SAVED_STATE_RESULT_AND_EPISODE_REQUIRED')
    if options.get('initial_state_result') and not goal.allow_saved_state:raise ValueError('SAVED_STATE_NOT_GRANTED_BY_TASK')
    if options.get('validation_source'):
        if len(options)!=1 or not inp.task.evaluator.parameters.data.get('numerical_confirmation'):
            raise ValueError('EXCLUSIVE_FROZEN_NUMERICAL_CONFIRMATION_SOURCE_REQUIRED')
    return dict(**source_binding(configuration),candidate=plain(candidate),**(dict(execution=options) if options else {}))


def resolve_passive_confirmation(store,study_id,candidate,configuration,options):
    """Owned source results only; no user-supplied metric or historical seed."""
    from extensions.reference.passive_evaluation_v2 import metrics
    from extensions.tendon_family.passive_execution import source_binding
    ref=options['validation_source'];current=store.session(study_id)['state']
    if ref not in current.get('physical_replays',[]):raise ValueError('CURRENT_OWNED_CONFIRMATION_SOURCE_REQUIRED')
    result=store.artifact(ref);raw=store.artifact(result['raw_reference'])
    if (result.get('owning_study')!=study_id or result.get('candidate')!=candidate or result.get('status')!='evaluated'
            or not result.get('boundary',{}).get('termination_confirmed') or raw.get('numerical_confirmation')
            or raw.get('physical_binding')!=source_binding(configuration)
            or metrics(SessionInput.model_validate(configuration).task,raw,check_confirmation=False).get('task_success') is not True):
        raise ValueError('COMPLETE_MATCHED_PASSING_PAIRED_SOURCE_REQUIRED')
    return result,raw


def resolve_passive_state(store,study_id,candidate,configuration,options):
    ref=options.get('initial_state_result')
    if ref is None:return None
    from extensions.tendon_family.passive_execution import source_binding,baseline_arm
    from extensions.reference.passive_evaluation_v2 import inspect
    current=store.session(study_id)['state']
    if ref not in current.get('physical_replays',[]):raise ValueError('CURRENT_OWNED_PHYSICAL_STATE_SOURCE_REQUIRED')
    result=store.artifact(ref)
    if (result.get('owning_study')!=study_id or result.get('candidate')!=candidate or result.get('status')!='evaluated'
            or not result.get('boundary',{}).get('termination_confirmed')):raise ValueError('COMPLETED_OWNED_PHYSICAL_STATE_SOURCE_REQUIRED')
    raw=store.artifact(result['raw_reference'])
    if raw.get('paired_ablation',{}).get('baseline_cost'):raw=baseline_arm(raw)
    if raw.get('physical_binding')!=source_binding(configuration) or inspect(SessionInput.model_validate(configuration).task,raw)[0]!='valid':
        raise ValueError('QUALIFIED_MATCHED_DYNAMIC_STATE_SOURCE_REQUIRED')
    episode=next((e for e in raw['episodes'] if e['load_condition']==options['initial_state_episode']),None)
    if episode is None or not episode.get('qualified_state'):raise ValueError('SAVED_QUALIFIED_EPISODE_STATE_REQUIRED')
    return episode['qualified_state']


def dispatch(host,arguments,key,*,role='development',selected=None,plan_reference=None):
    confirmation=role=='confirmation'
    guard(host,not confirmation)
    s=state(host)
    if s['spec'].get('research_decisions') and 'physical_replay' not in s['spec']['capabilities']:
        raise ValueError('PHYSICAL_REPLAY_CAPABILITY_REQUIRED')
    from tools.research.budget import replay_remaining
    replay_left=replay_remaining(s['spec'],s.get('physical_replay_launches',0))
    if replay_left is not None and replay_left<1:
        raise ValueError('PHYSICAL_REPLAY_LAUNCH_BUDGET_EXHAUSTED')
    candidate=plain(arguments.candidate)
    if plan_reference:
        plan=host.store.artifact(plan_reference)['original_plan']
        if (plain(plan_reference) not in s.get('plans',[]) or plan['action']!='physical_replay'
                or plan['physical_replay']!=plain(arguments)
                or host.store.artifact(plan_reference)['request_id']!=key):
            raise ValueError('PHYSICAL_REPLAY_PLAN_CANDIDATE_MISMATCH')
    cfg=verify_candidate(host,candidate)['configuration']
    from tools.research_tasks import passive_registered
    passive=passive_registered(cfg['task'])
    episodes=len(cfg['task']['goal']['data']['load_conditions']) if passive else 1
    route='passive_protocol' if passive else 'fixed_tension'
    if cfg['task'].get('physical_problem') and not passive:raise ValueError('PASSIVE_INDEPENDENT_EVALUATOR_NOT_REGISTERED')
    if passive:
        options={k:plain(getattr(arguments,k)) for k in ('passive_ablation','initial_state_result','initial_state_episode','validation_source') if getattr(arguments,k) is not None}
        if arguments.source and not options:options=host.store.artifact(arguments.source).get('execution',{})
        expected=passive_source(cfg,candidate,options)
        resolve_passive_state(host.store,host.run_id,candidate,cfg,options)
        if options.get('validation_source'):
            resolve_passive_confirmation(host.store,host.run_id,candidate,cfg,options)
            from extensions.reference.contracts import PassiveResponseEvaluationV2
            confirmation_spec=PassiveResponseEvaluationV2.model_validate(cfg['task']['evaluator']['parameters']['data']).numerical_confirmation
            episodes*=2+len(confirmation_spec.variants)
        if options.get('passive_ablation'):episodes*=2
        if cfg['task']['goal']['data'].get('version')=='passive_response_v2':
            host.store.artifact(cfg['task']['goal']['data']['protocol_source'])
        source_ref=plain(arguments.source) if arguments.source else save(host,expected,'frozen_passive_protocol')
        source=host.store.artifact(source_ref)
        if source!=expected:raise ValueError('FROZEN_PASSIVE_PROTOCOL_CANDIDATE_MISMATCH')
    else:
        if arguments.source is None:raise ValueError('ACTIVE_REPLAY_REQUIRES_CONTROL_SOURCE')
        source_ref=plain(arguments.source)
        source=host.store.artifact(source_ref)
    if explicit_control_source(source) and 'control_correction' not in s['spec']['capabilities']:
        raise ValueError('EXPLICIT_CONTROL_SCHEDULE_CAPABILITY_REQUIRED')
    if not passive and not (numerically_verified_source(source) or explicit_control_source(source)):
        raise ValueError('VERIFIED_OR_EXPLICIT_DIAGNOSTIC_MATHEMATICAL_SOURCE_REQUIRED')
    if not passive:binding(cfg,source['trajectory'],mathematical_outputs=source.get('mathematical_outputs'))
    from tools.research.feedback import experiment_preflight,eligibility
    if confirmation:
        if s.get('selected')!=plain(selected):raise ValueError('CONFIRM_REQUIRES_PRIOR_FORMAL_SELECT')
        old=host.store.artifact(selected)
        if old['candidate']!=candidate or old.get('source_reference')!=source_ref:
            raise ValueError('CONFIRMATION_REQUIRES_EXACT_SELECTED_CONTROL_SOURCE')
        choice=eligibility(host,selected,selection=False,root_operation=False)
        if not choice['eligible']:raise ValueError('; '.join(choice['reasons']))
    from tools.research.budget import capacity
    if capacity(host,episodes,confirmation,route=route)['admitted']<episodes:
        raise ValueError('PHYSICAL_REPLAY_AND_CONFIRMATION_RESERVE_CANNOT_FIT')
    novelty=experiment_preflight(host,candidate,route,source_ref=source_ref,repeat=confirmation)
    if not novelty['admitted']:
        raise ValueError('EQUIVALENT_SCIENTIFIC_EXPERIMENT_REQUIRES_EXPLICIT_REPLICATION_GRANT: '
            +json.dumps(novelty,sort_keys=True))
    request=dict(kind='physical_replay',implementation=s['freeze'],study_id=host.run_id,
        store_root=str(host.store.root),request_id=key+'-physical',candidate=candidate,
        source_reference=source_ref,configuration=cfg,route=route,episode_count=episodes,
        **(dict(passive_source=source) if passive else dict(trajectory=source['trajectory'])),
        role=role,selected_execution=plain(selected),operation_key=key)
    if plan_reference:request['plan_reference']=plain(plan_reference)
    worker_key=request['request_id']
    old=host.store.lookup(host.run_id,worker_key)
    if old:
        if old['request_hash']!=digest(request):raise ValueError('PHYSICAL_REPLAY_OPERATION_COLLISION')
        if not old['receipt']:raise ValueError('RECOVER_PHYSICAL_REPLAY_NO_RELAUNCH')
        return dict(reference=json.loads(old['receipt'])['output'],additional_physical_launches=0)
    def charge(db):
        current=host.store.session(host.run_id,db)['state']
        from tools.research.budget import backend_capacity
        remaining=backend_capacity(host,db)
        if remaining is not None and remaining<episodes:raise ValueError('BACKEND_CAPACITY_PROTECTS_RESERVED_RL_EVALUATIONS')
        current['physical_replay_launches']=current.get('physical_replay_launches',0)+episodes
        host.store.update_state(db,host.run_id,current)
    row,_=host.store.reserve(host.run_id,worker_key,digest(request),host.actor,
        {**zero(),'backend_solves':episodes},resources=('backend.family_mujoco',),guard=charge)
    folder=host.store.root/'physical_replay'/row['execution_id']
    io_path(folder).mkdir(parents=True,exist_ok=True)
    save(host,dict(request_id=worker_key,entrypoint='tools.research.execution_worker',request=request),'worker_request')
    atomic_json(folder/'request.json',request)
    update(host,pending=dict(kind='physical_replay',worker_request_id=worker_key,folder=str(folder),
        implementation=s['freeze'],candidate=candidate,source_reference=source_ref,
        role=role,selected_execution=plain(selected),operation_key=key,route=route,episode_count=episodes,started_unix=time.time(),
        **(dict(plan_reference=plain(plan_reference)) if plan_reference else {})))
    from tools.service_execution import _run_contained
    started=time.perf_counter()
    try:
        with io_path(folder/'worker.log').open('w',encoding='utf8') as log:
            done=_run_contained([s['spec']['runtime']['research_python'],'-m','tools.research.execution_worker',
                str(folder/'request.json')],log,s['spec'].get('physical_worker_watchdog_s'),lifecycle_path=folder/'worker_lifecycle.json')
        boundary=dict(termination_confirmed=True,returncode=done.returncode,worker_started=True)
    except subprocess.TimeoutExpired as exc:
        boundary=dict(termination_confirmed=getattr(exc,'termination_confirmed',False),timed_out=True,worker_started=True)
    boundary['elapsed_s']=time.perf_counter()-started
    atomic_json(folder/'boundary.json',boundary)
    return recover(host)


def playback_profile(inp,raw,evaluation):
    """Task-layer diagnostics from physical samples; no integration or solver."""
    from tools.research_tasks import task_adapter
    adapter=task_adapter(inp)
    samples=raw.get('samples',[])
    timing=inp.task.timing;intervals=round(timing.duration_s/timing.control_period_s)
    substeps=round(timing.control_period_s/timing.timestep_s)
    complete=raw.get('status')=='completed' and len(samples)==intervals+1 and raw.get('physics_steps')==intervals*substeps
    configured_limits={t['id']:t['force_limit_n'] for t in inp.robot.structure.data['tendons']}
    tendon_limits=[configured_limits[name] for name in raw.get('tendon_order',list(configured_limits))]
    force_violation=max((max(0.,-v,v-hi) for row in samples[1:]
        for v,hi in zip(row['actual_tension_n'],tendon_limits)),default=0.)
    profile=dict(complete=complete,task=plain(inp.task),official_task_success=evaluation.task_success,
        solver_error_count=0 if complete else 1,force_bound_violation_n=force_violation)
    if inp.task.family in ('task.tracking','task.position_tool_axis','task.oriented_tracking'):
        # Motion is post-step; each sample's actual tension was applied during
        # the preceding interval. Verify both grids without scheduling the path.
        profile['tracking_sampling_complete']=bool(complete and
            all(abs(row['time_s']-k*timing.sample_period_s)<=1e-12 for k,row in enumerate(samples)) and
            all(np.asarray(row['actual_tension_n']).shape==(len(tendon_limits),) for row in samples[1:]))
        if inp.task.family in ('task.position_tool_axis','task.oriented_tracking'):
            from extensions.reference.implementation import tool_axis_angles
            try:
                tool_axis_angles([v['tip_tool_axis_world'] for v in samples],
                    inp.task.goal.data['target_axis_world'] if inp.task.family=='task.position_tool_axis' else inp.task.goal.data['axis_vertices_world'][0])
                profile['tool_axis_sampling_complete']=profile.pop('tracking_sampling_complete')
            except (KeyError,ValueError):profile['tool_axis_sampling_complete']=False
        if inp.task.family=='task.oriented_tracking':
            profile['rigid_tool_binding']=raw.get('rigid_tool_binding',{}).get('matched')
            contact=raw.get('environment_contact',{})
            profile['no_environment_contact']=(contact.get('contact_free') if contact.get('checked_physics_steps')==raw.get('physics_steps') and complete else None)
    else:
        limits=adapter.ranking_limits();settling=inp.policy.controller.parameters.data['settling']
        hold=[v for v in samples if v['time_s']>=adapter.holding_start_s()-1e-12]
        expected_hold=round(settling['window_s']/timing.sample_period_s)+1
        covered=complete and len(hold)==expected_hold
        reference,_=adapter.reference_at([v['time_s'] for v in hold])
        max_error=max((float(np.linalg.norm(np.asarray(v['tip_m'])-r)) for v,r in zip(hold,reference)),default=None)
        max_speed=max((v['speed_m_s'] for v in hold),default=None)
        profile['sampled_settling']=dict(window_s=settling['window_s'],
            position_limit_m=limits['holding_max_error_m'],speed_limit_m_s=limits['holding_max_speed_m_s'],
            available=covered,max_error_m=max_error,max_speed_m_s=max_speed,
            passed=bool(covered and max_error<=limits['holding_max_error_m'] and max_speed<=limits['holding_max_speed_m_s']))
    return profile


def evaluate_playback(configuration, raw, raw_reference, comparison_identity):
    """Registered endpoint evaluation and original profile from fresh backend data."""
    from tools.platform_registry import registry
    inp=SessionInput.model_validate(configuration)
    if inp.task.family=='task.passive_response':
        from extensions.tendon_family.passive_execution import backend_result,source_binding
        from extensions.reference.passive_response import inspect_evidence
        if raw.get('kind') not in ('passive_dynamic_execution_v1','passive_dynamic_execution_v2'):
            from schemas.platform import EvaluationResult
            evaluation=EvaluationResult(validity='incomplete',task_success=None,metrics=[],constraints=[],
                reason=raw.get('reason','PASSIVE_NATIVE_RECORD_UNAVAILABLE'),source=raw_reference,evaluator=inp.task.evaluator.extension_id,
                evaluator_version=inp.task.evaluator.version,comparison_identity=comparison_identity)
            return evaluation,dict(complete=False,task=plain(inp.task),official_task_success=None,solver_error_count=1,
                dynamic_sampling=False,all_load_cases=False,physical_source=False,initial_qualification=False,stage_program=False,actual_constraints=False,
                cost=raw.get('cost'),execution_failure_reason=evaluation.reason)
        result=backend_result(inp,raw)
        evaluator=registry().get(inp.task.evaluator.extension_id,inp.task.evaluator.version,'evaluator').resolve()
        evaluation=evaluator(inp.task,result,raw_reference,registry(),comparison_identity)
        bound=raw.get('physical_binding')==source_binding(configuration)
        if not bound:
            evaluation=evaluation.model_copy(update=dict(validity='invalid',task_success=None,metrics=[],constraints=[],
                reason='PASSIVE_PHYSICAL_MODEL_SOURCE_MISMATCH'))
        validity,reason=inspect_evidence(inp.task,raw)
        complete=raw.get('status')=='completed' and all(e.get('complete') for e in raw.get('episodes',[]))
        profile=dict(complete=complete,task=plain(inp.task),official_task_success=evaluation.task_success,
            solver_error_count=int(bool(raw.get('numerical_failure') or raw.get('reason'))),
            dynamic_sampling=validity=='valid',all_load_cases=[e.get('load_condition') for e in raw.get('episodes',[])]==inp.task.goal.data['load_conditions'],
            physical_source=bound,
            evaluation_validity=evaluation.validity,valid_complete_execution=evaluation.validity=='valid' and complete,
            physics_steps=raw.get('physics_steps'),cost=raw.get('cost'),execution_failure_reason=reason,
            simulation_wall_s=raw.get('timings_s',{}).get('total'))
        if inp.task.goal.data.get('version')=='passive_response_v2':
            from extensions.reference.passive_evaluation_v2 import summary
            profile.update(initial_qualification=validity=='valid',stage_program=validity=='valid',actual_constraints=validity=='valid',
                passive_program=summary(inp.task,raw),physics_steps=raw.get('cost',{}).get('physics_steps'))
        return evaluation,profile
    samples=raw.get('samples',[])
    signal=next(v for v in inp.task.observations if v.name=='tip_position' and v.phase=='post_step')
    signals=[Signal(spec=signal,times_s=[v['time_s'] for v in samples[1:]],values=[v['tip_m'] for v in samples[1:]])]
    if inp.task.family in ('task.position_tool_axis','task.oriented_tracking') and all('tip_tool_axis_world' in v for v in samples[1:]):
        axis=next(v for v in inp.task.observations if v.name=='tip_tool_axis')
        signals.append(Signal(spec=axis,times_s=[v['time_s'] for v in samples[1:]],values=[v['tip_tool_axis_world'] for v in samples[1:]]))
    result=BackendResult(solver_status='completed' if raw.get('status')=='completed' else 'failed',
        backend_id='backend.family_mujoco',model_id='mujoco_serial_bending_v1',
        signals=signals,
        data=Payload(contract='family.backend_data',data=dict(physical_replay=True,task_evidence=raw.get('task_evidence'))),
        limitations=['Ideal direct tendon tension; no hardware or robustness claim'],
        initial_state=inp.task.initializer.parameters,seed=inp.seed)
    evaluator=registry().get(inp.task.evaluator.extension_id,inp.task.evaluator.version,'evaluator').resolve()
    evaluation=evaluator(inp.task,result,raw_reference,registry(),comparison_identity)
    if inp.task.acceptance:
        from tools.task_protocols import evaluate_backend
        evaluation=evaluate_backend(inp.task,result,raw_reference,registry(),comparison_identity)
    return evaluation,playback_profile(inp,raw,evaluation)


def record_orphan_exit(host):
    """Operator-only settlement proof; never infer an exit from a stale heartbeat."""
    from datetime import datetime
    from tools.service_execution import request_exit_observation
    p=state(host).get('pending')
    if not p or p.get('kind')!='physical_replay':raise ValueError('PENDING_PHYSICAL_REPLAY_REQUIRED')
    folder=io_path(p['folder']);request=read(folder/'request.json')
    if (folder/'boundary.json').exists():raise ValueError('USE_ORIGINAL_PHYSICAL_BOUNDARY')
    recovered=folder/'recovery_boundary.json'
    if recovered.exists():return read(recovered)
    row=host.store.lookup(host.run_id,p['worker_request_id'])
    if (not row or row['receipt'] or row['execution_id']!=folder.name
            or request.get('kind')!='physical_replay' or request.get('request_id')!=p['worker_request_id']
            or request.get('study_id')!=host.run_id or Path(request['store_root']).resolve()!=host.store.root.resolve()
            or request.get('implementation')!=p['implementation'] or request.get('candidate')!=p['candidate']
            or request.get('source_reference')!=p['source_reference']):
        raise ValueError('ORIGINAL_PHYSICAL_WORKER_IDENTITY_REQUIRED')
    matches=[]
    for event in host.store.events(host.run_id):
        if event['kind']!='worker_request':continue
        for reference in event['outputs']:
            value=host.store.artifact(reference)
            if value.get('request_id')==p['worker_request_id'] and value.get('request')==request:
                matches.append((event,reference))
    if len(matches)!=1:raise ValueError('ORIGINAL_DURABLE_WORKER_REQUEST_REQUIRED')
    event,reference=matches[0]
    started=datetime.fromisoformat(event['timestamp']).timestamp()
    observation=request_exit_observation(host.store.root.parent)
    if not started<=observation['observed_started_unix']<=observation['observed_unix']<=time.time():
        raise ValueError('INVALID_EXIT_OBSERVATION_TIME')
    proof=save(host,dict(worker_request=reference,request=request,process_exit=observation,
        original_lifecycle_missing=not (folder/'worker_lifecycle.json').exists(),
        classification='Verified original request absent from current OS inventory; original PID/exit time/code unknown; no relaunch'),
        'verified_physical_orphan_exit')
    boundary=dict(termination_confirmed=True,timed_out=False,returncode=None,worker_started=None,
        elapsed_s=observation['observed_unix']-started,elapsed_semantics='conservative upper bound through verified exit observation',
        recovery_source=proof,original_boundary_missing=True)
    atomic_json(recovered,boundary)
    return boundary


def recover(host):
    from tools.research_tasks import assemble_acceptance

    p=state(host)['pending'];folder=io_path(p['folder'])
    outcome=folder/'boundary.json'
    if not outcome.exists():outcome=folder/'recovery_boundary.json'
    if not outcome.exists():raise ValueError('UNKNOWN_PHYSICAL_REPLAY_OUTCOME_RETAINS_RESERVATION')
    boundary=read(outcome)
    if not boundary['termination_confirmed']:
        raise ValueError('UNKNOWN_PHYSICAL_REPLAY_OUTCOME_RETAINS_RESERVATION')
    raw=read(folder/'result.json') if (folder/'result.json').exists() else dict(status='incomplete',reason='worker_result_missing')
    if p.get('route')=='passive_protocol' and raw.get('status')!='completed' and (folder/'baseline/passive_progress.json').exists():
        from extensions.tendon_family.passive_execution import paired_raw
        first=read(folder/'baseline/passive_progress.json')
        second=read(folder/'ablation/passive_progress.json') if (folder/'ablation/passive_progress.json').exists() else None
        options=read(folder/'request.json')['passive_source'].get('execution',{})
        if options.get('passive_ablation'):
            outer_reason=raw.get('reason','worker_interrupted')
            raw=paired_raw(first,second,folder,options['passive_ablation'],boundary['elapsed_s'],interrupted=True)
            raw['reason']=outer_reason
    if p.get('route')=='passive_protocol' and raw.get('status')!='completed' and (folder/'passive_progress.json').exists():
        if not raw.get('unobserved_work_possible'):
            partial=read(folder/'passive_progress.json')
            partial.update(status='incomplete',reason=raw.get('reason','worker_interrupted'),
                cost_observation_scope='last_durable_observed_lower_bounds',unobserved_work_possible=True)
            if raw.get('numerical_failure'):partial['numerical_failure']=raw['numerical_failure']
            raw=partial
    if p.get('route')=='passive_protocol' and raw.get('kind')!='passive_dynamic_execution_v2' and (folder/'independent/passive_progress.json').exists():
        partial=read(folder/'independent/passive_progress.json')
        partial['trace_files']=[dict(t,path='independent/'+t['path']) for t in partial.get('trace_files',[])]
        partial.update(status='incomplete',reason=raw.get('reason','validation_worker_interrupted'),
            cost_observation_scope='last_durable_observed_lower_bounds',unobserved_work_possible=True)
        raw=partial
    # Preserve compiled-load and first-contact facts even if a later engine call raises.
    if (folder/'rigid_tool_binding.json').exists():raw.setdefault('rigid_tool_binding',read(folder/'rigid_tool_binding.json'))
    if (folder/'first_environment_contact.json').exists():raw.setdefault('environment_contact',read(folder/'first_environment_contact.json'))
    if raw.get('status')!='completed' and (folder/'samples.json').exists():
        raw['samples']=read(folder/'samples.json')
    passive_l2=None
    if raw.get('kind')=='passive_dynamic_execution_v2':
        # Import immutable bytes and arm receipts into the existing Store. Keep
        # native arm bodies unchanged so their measured identities remain valid.
        passive_l2=dict(traces=[],arms={})
        with host.store.transaction() as db:
            for manifest in raw.get('trace_files',[]):
                path=(folder/manifest['path']).resolve()
                if not path.is_relative_to(folder.resolve()):raise ValueError('PASSIVE_TRACE_OUTSIDE_OWNED_WORKER_FOLDER')
                body=path.read_bytes()
                if len(body)!=manifest['bytes'] or hashlib.sha256(body).hexdigest()!=manifest['sha256']:
                    raise ValueError('PASSIVE_TRACE_IMMUTABILITY_MISMATCH')
                passive_l2['traces'].append(dict(**manifest,reference=plain(host.store.put(db,body,media='text/csv'))))
            pair=raw.get('paired_ablation') or {}
            if pair.get('arm_receipts'):
                from extensions.tendon_family.passive_execution import baseline_arm
                for arm in pair['arm_receipts']:
                    value=baseline_arm(raw) if arm=='baseline' else pair['ablation']
                    native=pair['arm_receipts'][arm]
                    if native['raw_identity']!=digest(value):raise ValueError('PASSIVE_ARM_RECEIPT_RAW_MISMATCH')
                    ref=plain(host.store.put(db,value))
                    receipt=dict(**native,raw_reference=ref,parent_request_id=p['worker_request_id'],
                        owning_study=host.run_id,parent_boundary=boundary,parent_implementation=p['implementation'])
                    passive_l2['arms'][arm]=dict(raw_reference=ref,receipt_reference=plain(host.store.put(db,receipt)))
            accounted={v['path'] for v in raw.get('trace_files',[])}
            for path in sorted(folder.rglob('episode_*.csv')):
                relative=path.relative_to(folder).as_posix()
                if relative in accounted:continue
                body=path.read_bytes()
                passive_l2.setdefault('unsealed_traces',[]).append(dict(path=relative,reference=plain(host.store.put(db,body,media='text/csv')),
                    bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),scope='Interrupted file; no complete-grid, state or qualification assertion.'))
    raw.update(boundary=boundary,implementation=p['implementation'])
    raw_ref=save(host,raw,'physical_playback_raw')
    source=host.store.artifact(p['source_reference'])
    candidate=verify_candidate(host,p['candidate']);cfg=candidate['configuration']
    if p.get('route')=='passive_protocol' and raw.get('kind') in ('passive_dynamic_execution_v1','passive_dynamic_execution_v2'):
        from extensions.tendon_family.passive_execution import backend_result
        backend_reference=save(host,plain(backend_result(SessionInput.model_validate(cfg),raw)),'physical_playback_backend_result')
    else:backend_reference=None
    samples=raw.get('samples',[])
    evaluation,profile=evaluate_playback(cfg,raw,raw_ref,digest(dict(candidate=p['candidate'],source=p['source_reference'])))
    evaluation_ref=save(host,plain(evaluation),'physical_playback_endpoint_evaluation')
    profile.update(execution_id=folder.name,simulation=raw_ref,evaluation=evaluation_ref)
    profile_ref=save(host,profile,'physical_playback_profile')
    complete=profile['complete']
    acceptance=assemble_acceptance(cfg,evaluation,profile,evaluation_reference=evaluation_ref,
        profile_reference=profile_ref,motion=[dict(time_s=v['time_s']) for v in samples])
    predicted=source.get('mathematical_outputs')
    aligned=bool(predicted and len(samples)==len(predicted['times_s']) and
        all(abs(v['time_s']-t)<1e-12 for v,t in zip(samples,predicted['times_s'])))
    differences=[dict(time_s=v['time_s'],position_m=(np.asarray(v['tip_m'])-predicted['tip_positions_m'][i]).tolist(),
        position_norm_m=float(np.linalg.norm(np.asarray(v['tip_m'])-predicted['tip_positions_m'][i])),
        velocity_m_s=(np.asarray(v['tip_velocity_m_s'])-predicted['tip_velocities_m_s'][i]).tolist(),
        velocity_norm_m_s=float(np.linalg.norm(np.asarray(v['tip_velocity_m_s'])-predicted['tip_velocities_m_s'][i])))
        for i,v in enumerate(samples)] if aligned else []
    comparison=dict(aligned=aligned and complete,available_samples=len(differences),
        initial_position_offset_m=differences[0]['position_norm_m'] if differences else None,
        max_position_difference_m=max((v['position_norm_m'] for v in differences),default=None),
        max_velocity_difference_m_s=max((v['velocity_norm_m_s'] for v in differences),default=None),
        samples=differences)
    log_bytes=(folder/'worker.log').read_bytes()
    log_ref=save(host,dict(raw_base64=base64.b64encode(log_bytes).decode('ascii'),
        raw_sha256=hashlib.sha256(log_bytes).hexdigest(),text=log_bytes.decode('utf8',errors='replace')),
        'physical_playback_log')
    final=dict(status='evaluated' if complete else 'execution_incomplete',candidate=p['candidate'],
        role=p.get('role','development'),selected_execution=p.get('selected_execution'),operation_key=p.get('operation_key',p['worker_request_id']),
        scientific_configuration=candidate['scientific_configuration'],profile_identity=candidate['profile_identity'],
        evaluation_version=candidate['evaluation_version'],
        route=p.get('route','fixed_tension'),
        model_identity=(source if p.get('route')=='passive_protocol' else source['trajectory'])['model_identity'],
        design_identity=(source if p.get('route')=='passive_protocol' else source['trajectory'])['design_identity'],
        owning_study=host.run_id,execution_id=folder.name,request_id=p['worker_request_id'],
        source_reference=p['source_reference'],raw_reference=raw_ref,evaluation_reference=evaluation_ref,profile_reference=profile_ref,
        acceptance=acceptance,comparison=comparison,profile=profile,boundary=boundary,
        charged_numerical_s=boundary['elapsed_s'],implementation=p['implementation'],log_reference=log_ref,
        physical_launches=p.get('episode_count',1),actual_resource_consumption=raw.get('cost'),
        backend_reference=backend_reference,mathematical_reintegrations=0,rl_actions=0,nmpc_updates=0)
    if p.get('plan_reference'):final['plan_reference']=p['plan_reference']
    if raw.get('kind')=='passive_dynamic_execution_v2':
        from tools.research_tasks import task_adapter
        final['diagnostic_task_gap']=task_adapter(cfg).diagnostic_task_gap(raw,p['candidate'],raw_ref)
        final['physical_cost_status']=dict(observation_scope=raw.get('cost_observation_scope',raw.get('cost',{}).get('observation_scope','observed_native_counts')),
            unobserved_work_possible=raw.get('unobserved_work_possible',raw.get('cost',{}).get('unobserved_work_possible',False)))
    if passive_l2 is not None:final['passive_l2']=passive_l2
    ref=save(host,final,'physical_playback_result')
    row=host.store.lookup(host.run_id,p['worker_request_id'])
    with host.store.transaction() as db:
        current=host.store.session(host.run_id,db)['state']
        if current.get('pending')!=p:raise ValueError('ALREADY_SETTLED_PHYSICAL_REPLAY')
        current['numerical_s']+=boundary['elapsed_s']
        current['pending']=None
        current.setdefault('physical_replays',[]).append(ref)
        host.store.update_state(db,host.run_id,current)
        host.store.complete(row,dict(request_id=row['request_id'],execution_id=row['execution_id'],
            caller=host.actor,tool_id='research.physical_replay',tool_version='1.0.0',
            execution_status='completed',charged=zero()),final,elapsed=boundary['elapsed_s'],db=db)
    from tools.research.budget import observe_pass
    observe_pass(host,ref)
    return dict(reference=ref,**final)
