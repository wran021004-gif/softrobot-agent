from copy import deepcopy
import unittest
from tools.research.core import material_dependency_change
from tools.research.interface_recovery import prelaunch_io_failure


class PrelaunchIO(unittest.TestCase):
    def test_only_exact_unmeasured_prelaunch_error_is_eligible(self):
        r=dict(status='execution_incomplete',acceptance=None,execution=dict(stage='simulation',receipts=dict(simulation=dict(
            execution_status='failed',solver_status='not_run',error='[WinError 206] original owned path'))))
        self.assertTrue(prelaunch_io_failure(r))
        for field,value in [('solver_status','failed'),('error','optimizer did not converge')]:
            changed=deepcopy(r);changed['execution']['receipts']['simulation'][field]=value
            self.assertFalse(prelaunch_io_failure(changed))
        r['acceptance']=dict(accepted=False);self.assertFalse(prelaunch_io_failure(r))

    def test_only_reviewed_exact_host_io_versions_preserve_profile(self):
        a=dict(sources={'tools/platform_host.py':'2341f6a03f56df2032e64f6df9b6e0ab76ab307b14c408f5c729dc7aab409345','physics.py':'same'})
        b=dict(sources={'tools/platform_host.py':'3059488be6a5133401f58c4035ddf6e2121f7e49708b0f5668c5d02d7f8f548f','physics.py':'same'})
        self.assertFalse(material_dependency_change(a,b,store_io_only=True))
        self.assertTrue(material_dependency_change(a,b))
        b['sources']['physics.py']='different';self.assertTrue(material_dependency_change(a,b,store_io_only=True))
        b['sources']['physics.py']='same';b['sources']['tools/platform_host.py']='unreviewed'
        self.assertTrue(material_dependency_change(a,b,store_io_only=True))


if __name__=='__main__':unittest.main()
