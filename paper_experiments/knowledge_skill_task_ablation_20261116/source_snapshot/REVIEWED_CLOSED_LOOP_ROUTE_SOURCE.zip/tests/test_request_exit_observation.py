import unittest
from tools.service_execution import validate_request_absence


class RequestAbsence(unittest.TestCase):
    def test_another_episode_worker_does_not_block(self):
        rows=[dict(Name='python.exe',CommandLine='python -m tools.research.execution_worker D:/study/other/STORE/request.json')]
        self.assertEqual(validate_request_absence(rows,'D:/study/owned'),rows)

    def test_original_worker_or_executor_blocks(self):
        for command in ('python -m tools.research.execution_worker d:\\study\\owned\\STORE\\request.json',
                        'python executor.py serve D:/study/owned'):
            with self.assertRaisesRegex(ValueError,'STILL_PRESENT'):
                validate_request_absence([dict(Name='python.exe',CommandLine=command)],'D:/study/owned')

    def test_unreadable_python_command_fails_closed(self):
        with self.assertRaisesRegex(ValueError,'UNOBSERVABLE'):
            validate_request_absence([dict(Name='python.exe',CommandLine=None)],'D:/study/owned')


if __name__=='__main__':unittest.main()
