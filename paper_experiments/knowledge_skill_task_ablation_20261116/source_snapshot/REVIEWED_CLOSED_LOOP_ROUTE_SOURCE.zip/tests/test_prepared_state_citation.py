"""Prepared T04 evidence retains exact state and original scope restrictions."""
from copy import deepcopy
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch

from tools.research.evidence_policy import comparable_task,admit_decision
from tools.research.prepared_initial import static_binding


class PreparedStateCitation(unittest.TestCase):
    def fixture(self):
        canonical=dict(initializer=dict(parameters=dict(data=dict(unspecified='zero',qpos_rad={},qvel_rad_s={}))),
                       acceptance=dict(evaluator='figure_eight'),environment=dict(load='original'),goal=dict(reference='original'))
        cfg=dict(task=deepcopy(canonical),robot=dict(length=1),policy=dict(discretization=dict(mesh=2)))
        initial=cfg['task']['initializer']['parameters']['data']
        initial.update(qpos_rad=dict(joint=.1),qvel_rad_s=dict(joint=0),tensions_n=dict(tendon=1),qualification=dict(artifact_id='q'))
        qualification=dict(contract='task.prepared_initial',data=dict(qualified=True,static_binding=static_binding(cfg),
                    **{k:deepcopy(initial[k]) for k in ('qpos_rad','qvel_rad_s','tensions_n')}))
        store=Mock();store.artifact.return_value=qualification
        spec=dict(start_mode='family_space',candidate_initialization='all_candidate_dofs_zero_v1',canonical_task=canonical,task_conditions=[])
        return spec,cfg,store,qualification

    def test_valid_qualification_keeps_nonzero_task(self):
        spec,cfg,store,_=self.fixture();before=deepcopy(cfg)
        self.assertEqual(comparable_task(spec,cfg['task'],configuration=cfg,store=store),cfg['task'])
        self.assertEqual(cfg,before)
        with self.assertRaisesRegex(ValueError,'INITIAL_STATE_MISMATCH'):comparable_task(spec,cfg['task'])

    def test_different_goal_or_modified_state_is_rejected(self):
        spec,cfg,store,_=self.fixture()
        cfg['task']['goal']['reference']='different'
        with self.assertRaisesRegex(ValueError,'INITIAL_STATE_MISMATCH'):comparable_task(spec,cfg['task'],configuration=cfg,store=store)
        spec,cfg,store,_=self.fixture();cfg['task']['initializer']['parameters']['data']['qpos_rad']['joint']=.2
        with self.assertRaisesRegex(ValueError,'STATE_OR_MODEL_MISMATCH'):comparable_task(spec,cfg['task'],configuration=cfg,store=store)

    def test_stop_can_cite_prepared_observation_only_as_empirical_search(self):
        spec,cfg,store,qualification=self.fixture()
        spec['research_decisions']={};spec['research_decisions']['version']='research_decision_v1'
        ref=dict(artifact_id='a');candidate=dict(artifact_id='b')
        store.artifact.side_effect=lambda r: qualification if r==dict(artifact_id='q') else dict(configuration=cfg) if r==candidate else dict(candidate=candidate)
        host=SimpleNamespace(store=store,run_id='test')
        current=dict(spec=spec,base_configuration=dict(task=spec['canonical_task']))
        decision=SimpleNamespace(research_intent='STOP',selected_candidate=None,claimed_inference='empirical_search',version='research_decision_v1')
        plan=SimpleNamespace(action='stop',decision=decision,candidate=None,control_seed=None,control_search=None,physical_replay=None,supporting_evidence=[ref])
        summary=dict(evidence_reference=ref)
        from tools.research.contracts import PLAN_RESEARCH_INTENTS
        decision.research_intent=PLAN_RESEARCH_INTENTS['stop']
        with patch('tools.research.state.state',return_value=current),patch('tools.research.evidence_policy.registered_references',return_value=[ref]),patch('tools.research.evidence_policy.summarize_evidence',return_value=summary):
            self.assertEqual(admit_decision(host,plan)['claimed_inference'],'empirical_search')
            decision.claimed_inference='observed_task_pass'
            with self.assertRaisesRegex(ValueError,'EVIDENCE_TASK_IDENTITY_MISMATCH'):admit_decision(host,plan)


if __name__=='__main__':unittest.main()
