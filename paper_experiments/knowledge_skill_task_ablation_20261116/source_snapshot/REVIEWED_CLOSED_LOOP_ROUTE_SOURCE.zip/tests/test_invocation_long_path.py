"""The original numerical context must survive deeply nested Windows Stores."""
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4
import os
import shutil
import unittest
from unittest.mock import Mock,patch

from tools.paths import ROOT
from tools.platform_host import InvocationContext
from tools.state_io import io_path


class InvocationLongPath(unittest.TestCase):
    @unittest.skipUnless(os.name=='nt','Windows path regression')
    def test_original_context_and_native_mujoco_file_io(self):
        base=ROOT/'.offline-home/long-path-tests';base.mkdir(parents=True,exist_ok=True)
        root=base/uuid4().hex
        logical=root/('nested_'+'a'*90)/('nested_'+'b'*90)
        self.assertGreater(len(str(logical/'executions'/('c'*32))),300)
        store=Mock();store.session.return_value=dict(snapshot=dict(input={}))
        host=SimpleNamespace(store=store,reg=Mock(),run_id='test',folder=logical)
        inp=SimpleNamespace(policy=SimpleNamespace(operation_allowances={},timeout_s=None))
        try:
            with patch('tools.platform_host.SessionInput.model_validate',return_value=inp):
                context=InvocationContext(host,dict(execution_id='c'*32),SimpleNamespace(tool_id='simulation.run'))
            self.assertTrue(context.folder.is_dir())
            self.assertLess(len(str(context.folder/'model.xml')),240)
            self.assertTrue(os.path.samefile(context.folder,io_path(logical/'executions'/('c'*32))))
            xml=context.folder/'model.xml'
            xml.write_text('<mujoco><worldbody><body><freejoint/><geom type="sphere" size="0.01" mass="0.1"/></body></worldbody></mujoco>',encoding='utf8')
            import mujoco
            model=mujoco.MjModel.from_xml_path(str(xml))
            self.assertEqual(model.nq,7)
            # A native parse is sufficient to verify the physical entrypoint's
            # path boundary. No simulation, solver or task evaluator is run.
        finally:
            root.resolve().relative_to(base.resolve())
            if 'context' in locals() and context.folder!=logical/'executions'/('c'*32):
                # Remove only this junction, never its target recursively.
                io_path(context.folder.resolve()).relative_to(io_path(root.resolve()))
                os.rmdir(context.folder)
            if io_path(root).exists():shutil.rmtree(io_path(root))


if __name__=='__main__':unittest.main()
