from copy import deepcopy
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch
from tools.research.feedback import experiment_preflight


class PrelaunchRetryAdmission(unittest.TestCase):
    def check(self,authorize,scientific_result=False):
        candidate={'artifact_id':'candidate'};result={'artifact_id':'result'};grant={'artifact_id':'grant'}
        failed=dict(candidate=candidate,status='execution_incomplete',acceptance=None,execution=dict(stage='simulation',receipts=dict(simulation=dict(execution_status='failed',solver_status='not_run',error='[WinError 206] path'))))
        if scientific_result:failed.update(status='evaluated',acceptance=dict(status='valid_failure'))
        values={'candidate':{},'result':failed,'grant':dict(user_authorization=True,budgets_reset=False,failure_references=[result])}
        store=Mock();store.artifact.side_effect=lambda ref:deepcopy(values[ref['artifact_id']])
        host=SimpleNamespace(store=store,run_id='same-study')
        s=dict(spec={},results=[result],interface_continuations=[grant] if authorize else [])
        comparison=dict(relation='equivalent_repeat')
        with patch('tools.research.state.state',return_value=s),patch('tools.research.feedback.experiment_identity',return_value=dict(identity='exact-same')),patch('tools.research.feedback.compare_experiments',return_value=comparison):
            return experiment_preflight(host,candidate,'nmpc')

    def test_unstarted_io_attempt_requires_operator_authorization(self):
        self.assertFalse(self.check(False)['admitted'])
        repaired=self.check(True)
        self.assertTrue(repaired['admitted'])
        self.assertEqual(len(repaired['authorized_prelaunch_retries']),1)
        self.assertFalse(repaired['authorized_prelaunch_retries'][0]['previous_science_executed'])

    def test_real_scientific_failure_still_blocks_equivalent_repeat(self):
        self.assertFalse(self.check(True,scientific_result=True)['admitted'])


if __name__=='__main__':unittest.main()
