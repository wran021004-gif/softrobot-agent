"""Recovery admits original lifecycle evidence, never guessed or live workers."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import json
import shutil
from uuid import uuid4
import unittest
from unittest.mock import Mock,patch

from tools.research.execution import record_orphan_exit


class ExecutionLifecycleRecovery(unittest.TestCase):
    @contextmanager
    def fixture(self):
        base=Path(__file__).resolve().parents[1]/'.offline-home/recovery-tests'
        base.mkdir(parents=True,exist_ok=True)
        root=base/('test-'+uuid4().hex);root.mkdir()
        try:
            owner='study-exec-owned'
            folder=root/'executions'/owner;folder.mkdir(parents=True)
            configuration=dict(run_id=owner,task=dict(frozen=True))
            request=dict(root=str(root),study='study',owner=owner,configuration=configuration)
            lifecycle=dict(pid=123456,job_name='Local\\softrobot-worker-original',started_unix=2,
                command=['python','-m','tools.research.execution_worker',str(folder/'request.json')])
            for name,value in [('request.json',request),('worker_lifecycle.json',lifecycle)]:
                (folder/name).write_text(json.dumps(value),encoding='utf8')
            store=Mock();store.root=root;store.lookup.return_value=dict(receipt=None)
            host=SimpleNamespace(store=store,run_id='study')
            state=dict(pending=dict(owner=owner,launch_intent=True,started_unix=1,configuration=configuration))
            with patch('tools.research.execution.state',return_value=state),patch('tools.research.execution.time.time',return_value=10):
                yield host,folder,request,lifecycle
        finally:
            root.resolve().relative_to(base.resolve())
            shutil.rmtree(root)

    def test_original_exited_worker_settles_with_censored_elapsed_time(self):
        with self.fixture() as (host,folder,request,lifecycle):
            with patch('tools.service_execution.process_exit_observation',return_value=dict(pid=123456,exited=True)) as observe:
                with patch('tools.research.execution.save',return_value=dict(artifact_id='proof')) as save:
                    boundary=record_orphan_exit(host)
            observe.assert_called_once_with(123456)
            self.assertTrue(boundary['termination_confirmed'])
            self.assertEqual(boundary['elapsed_s'],9)
            self.assertIsNone(boundary['returncode'])
            self.assertIn('upper bound',boundary['elapsed_semantics'])
            self.assertEqual(save.call_args.args[1]['original_worker_lifecycle'],lifecycle)
            self.assertTrue((folder/'recovery_boundary.json').exists())

    def test_mismatched_owned_request_cannot_release_reservation(self):
        with self.fixture() as (host,folder,request,lifecycle):
            request['study']='another-study'
            (folder/'request.json').write_text(json.dumps(request),encoding='utf8')
            with patch('tools.service_execution.process_exit_observation') as observe:
                with self.assertRaisesRegex(ValueError,'ORIGINAL_WORKER_IDENTITY_REQUIRED'):record_orphan_exit(host)
            observe.assert_not_called()
            self.assertFalse((folder/'recovery_boundary.json').exists())

    def test_live_or_reused_pid_cannot_release_reservation(self):
        with self.fixture() as (host,folder,request,lifecycle):
            with patch('tools.service_execution.process_exit_observation',side_effect=ValueError('PROCESS_STILL_PRESENT_OR_PID_REUSED')):
                with self.assertRaisesRegex(ValueError,'PROCESS_STILL_PRESENT'):record_orphan_exit(host)
            self.assertFalse((folder/'recovery_boundary.json').exists())

    def test_existing_sealed_simulation_uses_original_receipt(self):
        with self.fixture() as (host,folder,request,lifecycle):
            host.store.lookup.return_value=dict(receipt='sealed')
            with patch('tools.service_execution.process_exit_observation') as observe:
                with self.assertRaisesRegex(ValueError,'UNSEALED_STARTED_SIMULATION_REQUIRED'):record_orphan_exit(host)
            observe.assert_not_called()


if __name__=='__main__':unittest.main()
