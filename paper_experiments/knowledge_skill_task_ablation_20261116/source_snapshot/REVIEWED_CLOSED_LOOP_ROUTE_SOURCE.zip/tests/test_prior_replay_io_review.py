from copy import deepcopy
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch
from tools.research.interface_recovery import resume_after_prelaunch_io_stop


class PriorReplayReview(unittest.TestCase):
    def fixture(self):
        failure={'artifact_id':'a'};replay={'artifact_id':'b'};stop={'artifact_id':'c'}
        values={'a':dict(status='execution_incomplete',acceptance=None,execution=dict(stage='simulation',receipts=dict(simulation=dict(execution_status='failed',solver_status='not_run',error='[WinError 206] path')))),
            'b':dict(profile=dict(complete=True),acceptance=dict(accepted=False,status='valid_failure')),
            'c':dict(original_plan=dict(interpretation='NMPC blocked by WinError 206; valid replay fails.',weakening_observation='A repaired NMPC path could justify reopening.'))}
        store=MagicMock();store.artifact.side_effect=lambda r:deepcopy(values[r['artifact_id']])
        store.connect.return_value.__enter__.return_value.execute.return_value.fetchone.return_value=[0]
        store.remaining.return_value=dict(remaining=10)
        host=SimpleNamespace(store=store,run_id='same')
        s=dict(research_status='stopped',results=[failure],physical_replays=[replay],final_disposition=stop)
        return host,s,values,replay

    def run_review(self,host,s,replays=None,basis=None):
        with patch('tools.research.interface_recovery.state',return_value=s),patch('tools.research.interface_recovery.save',return_value={'artifact_id':'proof'}) as saved,patch('tools.research.interface_recovery.update'):
            result=resume_after_prelaunch_io_stop(host,user_authorization=True,reason='Explicit user interface continuation request',reviewed_prior_replays=replays,reviewed_reopening_basis=basis)
            return result,saved.call_args.args[1]

    def test_exact_review_preserves_real_replay_failure(self):
        host,s,values,ref=self.fixture();before=deepcopy(values)
        result,proof=self.run_review(host,s,[ref])
        self.assertTrue(proof['prior_valid_failures_retained_unchanged']);self.assertEqual(values,before)
        self.assertEqual(proof['reviewed_prior_complete_replays'],[ref])
        self.assertEqual(proof['new_scientific_executions'],0)

    def test_missing_review_or_original_pass_is_rejected(self):
        host,s,values,ref=self.fixture()
        with self.assertRaisesRegex(ValueError,'SEPARATE_REVIEW'):self.run_review(host,s)
        values['b']['acceptance']['accepted']=True
        with self.assertRaisesRegex(ValueError,'PRIOR_PASS_OR_UNKNOWN'):self.run_review(host,s,[ref])

    def test_genuine_scientific_stop_without_repair_basis_is_rejected(self):
        host,s,values,ref=self.fixture();values['c']['original_plan']['weakening_observation']='No further experiment selected.'
        with self.assertRaisesRegex(ValueError,'REOPENING_BASIS'):self.run_review(host,s,[ref])

    def feedback_fixture(self):
        host,s,values,ref=self.fixture()
        plan=values['c']['original_plan']
        plan.update(interpretation='Finite route closure.',weakening_observation='An admitted executable feedback route would reopen research.',supporting_evidence=s['results'])
        basis=dict(original_final_disposition=s['final_disposition'],failure_references=s['results'],original_weakening_observation=plan['weakening_observation'],reason='Exact cited receipts show NMPC never ran; user authorizes interface repair.')
        return host,s,values,ref,basis

    def test_exact_feedback_review_retains_original_stop_and_costs(self):
        host,s,values,ref,basis=self.feedback_fixture();before=deepcopy(values)
        _,proof=self.run_review(host,s,[ref],basis)
        self.assertEqual(proof['reviewed_reopening_basis'],basis)
        self.assertEqual(values,before);self.assertFalse(proof['budgets_reset'])

    def test_feedback_review_requires_exact_binding_and_cited_failure(self):
        for key in ['original_final_disposition','failure_references','original_weakening_observation','reason']:
            host,s,values,ref,basis=self.feedback_fixture();basis.pop(key)
            with self.assertRaisesRegex(ValueError,'REOPENING_BASIS'):self.run_review(host,s,[ref],basis)
        host,s,values,ref,basis=self.feedback_fixture();values['c']['original_plan']['supporting_evidence']=[]
        with self.assertRaisesRegex(ValueError,'REOPENING_BASIS'):self.run_review(host,s,[ref],basis)

    def test_feedback_review_cannot_override_real_execution_or_prior_pass(self):
        host,s,values,ref,basis=self.feedback_fixture()
        values['a']['execution']['receipts']['simulation']['solver_status']='failed'
        with self.assertRaisesRegex(ValueError,'EXACT_PRELAUNCH'):self.run_review(host,s,[ref],basis)
        host,s,values,ref,basis=self.feedback_fixture();values['b']['acceptance']['accepted']=True
        with self.assertRaisesRegex(ValueError,'PRIOR_PASS_OR_UNKNOWN'):self.run_review(host,s,[ref],basis)

    def test_exact_closed_loop_nmpc_reopening_statement(self):
        host,s,values,ref,basis=self.feedback_fixture()
        observation='Restoration of an executable closed-loop NMPC route would reopen the hypothesis.'
        values['c']['original_plan']['weakening_observation']=observation
        basis['original_weakening_observation']=observation
        self.run_review(host,s,[ref],basis)
        observation='More untested designs could reopen research.'
        values['c']['original_plan']['weakening_observation']=observation
        basis['original_weakening_observation']=observation
        with self.assertRaisesRegex(ValueError,'REOPENING_BASIS'):self.run_review(host,s,[ref],basis)


if __name__=='__main__':unittest.main()
