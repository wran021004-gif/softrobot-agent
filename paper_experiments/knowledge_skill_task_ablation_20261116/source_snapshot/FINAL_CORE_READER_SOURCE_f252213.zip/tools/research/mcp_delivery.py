"""Exact paged JSON delivery to external MCP researchers, with explicit acks.

No Provider requests or scientific results are fabricated. Complete-read credit
requires every exact page to have been written to this MCP connection and then
acknowledged by a subsequent client request on that connection.
"""
import hashlib,json,math,time
from tools.platform_store import plain
from tools.state_io import digest

PAGE_CHARACTERS=16000
CALLER='codex-mcp-transport'

def pack_json(value):
    """Lossless JSON DAG: exact keys/values, repeated subtrees stored once."""
    strings=[];string_ids={};schemas=[];schema_ids={};nodes=[];node_ids={}
    def string(text):
        if text not in string_ids:string_ids[text]=len(strings);strings.append(text)
        return string_ids[text]
    def visit(item):
        if isinstance(item,dict):
            keys=sorted(item);schema=tuple(string(k) for k in keys)
            if schema not in schema_ids:schema_ids[schema]=len(schemas);schemas.append(list(schema))
            node=['object',schema_ids[schema],[visit(item[k]) for k in keys]]
        elif isinstance(item,list):node=['array',[visit(v) for v in item]]
        elif isinstance(item,str):node=['string',string(item)]
        elif item is None:node=['null']
        elif type(item) is bool:node=['boolean',item]
        elif type(item) is int:node=['integer',item]
        elif type(item) is float:node=['number',item]
        else:raise ValueError('JSON_VALUES_ONLY')
        key=json.dumps(node,separators=(',',':'),ensure_ascii=True,allow_nan=False)
        if key not in node_ids:node_ids[key]=len(nodes);nodes.append(node)
        return node_ids[key]
    root=visit(value)
    return dict(codec='lossless_json_graph_v1',strings=strings,object_key_schemas=schemas,nodes=nodes,root_node=root)

def unpack_json(packed):
    if packed.get('codec')!='lossless_json_graph_v1':raise ValueError('UNKNOWN_JSON_GRAPH_CODEC')
    values=[];strings=packed['strings'];schemas=packed['object_key_schemas']
    for node in packed['nodes']:
        kind=node[0]
        if kind=='object':
            keys=schemas[node[1]];refs=node[2]
            if len(keys)!=len(refs) or any(type(i) is not int or not 0<=i<len(values) for i in refs):raise ValueError('INVALID_GRAPH_OBJECT')
            value={strings[k]:values[i] for k,i in zip(keys,refs)}
        elif kind=='array':
            if any(type(i) is not int or not 0<=i<len(values) for i in node[1]):raise ValueError('INVALID_GRAPH_ARRAY')
            value=[values[i] for i in node[1]]
        elif kind=='string':value=strings[node[1]]
        elif kind=='null':value=None
        elif kind in ('boolean','integer','number'):value=node[1]
        else:raise ValueError('UNKNOWN_GRAPH_NODE')
        values.append(value)
    return values[packed['root_node']]

def page(host,reference,index=0):
    from tools.research.core import read_evidence
    if type(index) is not int or index<0:raise ValueError('NONNEGATIVE_PAGE_INDEX_REQUIRED')
    query=dict(reference=plain(reference),view='full',pointer='')
    value=read_evidence(host,query,record_read=False)
    literal=json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
    factored=json.dumps(pack_json(value),separators=(',',':'),ensure_ascii=True,allow_nan=False)
    codec='lossless_json_graph_v1' if len(factored)<len(literal) else 'literal_json_v1'
    body=factored if codec=='lossless_json_graph_v1' else literal
    count=max(1,math.ceil(len(body)/PAGE_CHARACTERS))
    if index>=count:raise ValueError('PAGE_INDEX_OUTSIDE_EXACT_JSON_BODY')
    return dict(version='external_mcp_exact_json_page_v1',reference=query['reference'],page_index=index,page_count=count,json_text_codec=codec,
        page_characters=PAGE_CHARACTERS,total_characters=len(body),json_text_sha256=hashlib.sha256(body.encode('ascii')).hexdigest(),
        data_fragment=body[index*PAGE_CHARACTERS:(index+1)*PAGE_CHARACTERS],scientific_body_complete=False,
        notice='Complete lossless JSON, never a scientific summary. Graph codec stores repeated exact keys/strings/subtrees once: strings and object_key_schemas define original field names, typed nodes refer only to earlier nodes, root_node restores the entire original value. All original fields and precision remain present. This page alone grants no full-result read credit. Acknowledge its hash on the next evidence_page request. After last page acknowledge with page0, then select/confirm the ORIGINAL result; no physics recomputation is needed.')

def written(host,*,server_nonce,core_request_id,response_text,page_value):
    if page_value.get('version')!='external_mcp_exact_json_page_v1':raise ValueError('EXACT_JSON_PAGE_REQUIRED')
    # Check the literal tool response that was flushed, not an in-memory result
    # that might instead have been summarized before delivery.
    if json.loads(response_text)!=page_value:raise ValueError('WRITTEN_RESPONSE_DIFFERS_FROM_PAGE')
    proof=dict(version='external_mcp_response_written_v1',study_id=host.run_id,server_nonce=server_nonce,
        core_request_id=core_request_id,response_text=response_text,response_sha256=hashlib.sha256(response_text.encode('utf8')).hexdigest(),written_unix=time.time())
    with host.store.transaction() as db:
        ref=host.store.put(db,proof)
        host.store.event(db,host.run_id,'external_mcp_response_written','written',caller=CALLER,request=core_request_id,outputs=[ref])
    return plain(ref)

def acknowledge(host,written_reference,*,server_nonce,response_sha256,next_request_id):
    proof=host.store.artifact(written_reference)
    if proof.get('version')!='external_mcp_response_written_v1' or proof.get('study_id')!=host.run_id or proof.get('server_nonce')!=server_nonce:
        raise ValueError('OWNED_MCP_CONNECTION_REQUIRED')
    if proof['response_sha256']!=response_sha256 or proof['core_request_id']==next_request_id:
        raise ValueError('EXACT_PREVIOUS_RESPONSE_ACK_REQUIRED')
    if not any(e['kind']=='external_mcp_response_written' and e.get('agent_id')==CALLER and written_reference in e['outputs'] for e in host.store.events(host.run_id)):
        raise ValueError('ORIGINAL_WRITTEN_RESPONSE_EVENT_REQUIRED')
    ack=dict(version='external_mcp_response_ack_v1',study_id=host.run_id,written_reference=written_reference,
        server_nonce=server_nonce,response_sha256=response_sha256,next_request_id=next_request_id,acknowledged_unix=time.time())
    with host.store.transaction() as db:
        ref=host.store.put(db,ack)
        host.store.event(db,host.run_id,'external_mcp_response_acknowledged','acknowledged',caller=CALLER,request=next_request_id,outputs=[ref])
    complete=complete_reads(host)
    if complete:
        from tools.research.state import state,update
        s=state(host);current=[*s.get('results',[]),*s.get('physical_replays',[]),*s.get('rl_evaluations',[])]
        reads=list(s.get('evaluation_reads',[]))
        for entry in complete:
            reference=entry['query']['reference']
            if reference in current and reference not in reads:reads.append(reference)
        if reads!=s.get('evaluation_reads',[]):update(host,evaluation_reads=reads)
    return plain(ref)

def complete_reads(host):
    """Reconstruct all acknowledged pages and compare the WHOLE owned JSON."""
    events=host.store.events(host.run_id)
    written_refs={r['artifact_id'] for e in events if e['kind']=='external_mcp_response_written' and e.get('agent_id')==CALLER for r in e['outputs']}
    groups={}
    for event in events:
        if event['kind']!='external_mcp_response_acknowledged' or event.get('agent_id')!=CALLER:continue
        try:
            ack=host.store.artifact(event['outputs'][0]);wr=ack['written_reference']
            if ack.get('version')!='external_mcp_response_ack_v1' or ack['study_id']!=host.run_id or wr['artifact_id'] not in written_refs:continue
            sent=host.store.artifact(wr);text=sent['response_text']
            if (sent.get('version')!='external_mcp_response_written_v1' or sent['study_id']!=host.run_id or
                ack['server_nonce']!=sent['server_nonce'] or sent['core_request_id']==ack['next_request_id'] or
                sent['written_unix']>ack['acknowledged_unix'] or
                ack['response_sha256']!=sent['response_sha256'] or hashlib.sha256(text.encode('utf8')).hexdigest()!=sent['response_sha256']):continue
            value=json.loads(text)
            if value.get('version')!='external_mcp_exact_json_page_v1' or value.get('page_characters')!=PAGE_CHARACTERS:continue
            codec=value.get('json_text_codec','literal_json_v1')
            if codec not in ('literal_json_v1','lossless_json_graph_v1'):continue
            key=(value['reference']['artifact_id'],value['json_text_sha256'],value['total_characters'],value['page_count'],codec)
            index=value['page_index'];count=value['page_count'];length=value['total_characters']
            if (type(index) is not int or type(count) is not int or type(length) is not int or
                length<1 or count!=math.ceil(length/PAGE_CHARACTERS) or not 0<=index<count or
                len(value['data_fragment'])!=min(PAGE_CHARACTERS,length-index*PAGE_CHARACTERS)):continue
            group=groups.setdefault(key,dict(reference=value['reference'],pages={},acks=[]))
            if index in group['pages'] and group['pages'][index]!=value['data_fragment']:
                group['conflict']=True
            group['pages'][index]=value['data_fragment'];group['acks'].append(event['outputs'][0])
        except (ValueError,KeyError,TypeError):continue
    result=[]
    for key,group in groups.items():
        identity,body_hash,length,count,codec=key
        if group.get('conflict') or len(group['pages'])!=count:continue
        body=''.join(group['pages'][i] for i in range(count))
        if len(body)!=length or hashlib.sha256(body.encode('ascii')).hexdigest()!=body_hash:continue
        try:
            value=json.loads(body)
            if codec=='lossless_json_graph_v1':value=unpack_json(value)
            # Scope admission and whole-value comparison are independent of the
            # client acknowledgement; stale/foreign/edited bodies earn nothing.
            from tools.research.core import read_evidence
            expected=read_evidence(host,dict(reference=group['reference'],view='full',pointer=''),record_read=False)
            if value!=expected:continue
        except (ValueError,KeyError,TypeError):continue
        result.append(dict(query=dict(reference=group['reference'],view='full',pointer=''),owning_study=host.run_id,
            successfully_provided=True,complete_data=True,full_artifact=True,formal_acceptance_view=False,
            delivery_status='complete_exact_json_pages_acknowledged_by_external_mcp_client',
            delivery_identity=digest(value),classification='new_query',transport='external_mcp',acknowledgements=group['acks']))
    return result
