"""Reuse only an exact, sealed, current-Store passive development baseline.

The existing native execute_pair owns the new intervention and its accounting.
Independent numerical confirmation never uses this cache.
"""
from pathlib import Path
import hashlib
import shutil

from tools.platform_store import plain
from tools.state_io import io_path


def baseline(store, study_id, candidate, configuration, *, reference=None, metadata_only=False):
    from extensions.reference.passive_program import execution_identity
    from extensions.tendon_family.passive_execution import source_binding
    current = store.session(study_id)['state']
    owned = current.get('physical_replays', [])
    if reference is not None and reference not in owned:
        raise ValueError('CURRENT_OWNED_PASSIVE_BASELINE_REQUIRED')
    expected = execution_identity(configuration)
    for ref in ([reference] if reference is not None else reversed(owned)):
        result = store.artifact(ref)
        if (result.get('owning_study') != study_id or result.get('candidate') != plain(candidate)
                or result.get('status') != 'evaluated'
                or result.get('route') != 'passive_protocol'
                or result.get('boundary', {}).get('termination_confirmed') is not True):
            continue
        # Paired/confirmation bodies are deliberately excluded. A cache cannot
        # silently turn an independent comparison into a historical replay.
        fields = ('status', 'execution_identity', 'physical_binding', 'paired_ablation',
                  'numerical_confirmation', 'trace_files')
        raw = store.artifact(result['raw_reference'], paths=fields) if metadata_only else store.artifact(result['raw_reference'])
        if (raw.get('status') != 'completed' or raw.get('paired_ablation')
                or raw.get('numerical_confirmation') or raw.get('execution_identity') != expected
                or raw.get('physical_binding') != source_binding(configuration)):
            continue
        traces = result.get('passive_l2', {}).get('traces', [])
        manifests = raw.get('trace_files', [])
        if not manifests or any(not any(all(t.get(k) == m.get(k) for k in ('path', 'sha256', 'bytes'))
                                         and t.get('reference') for t in traces) for m in manifests):
            continue
        return dict(reference=plain(ref), result=result, raw=raw)
    if reference is not None:
        raise ValueError('EXACT_COMPLETE_PASSIVE_BASELINE_REQUIRED')
    return None


def execution_count(store, study_id, candidate, configuration, options):
    count = len(configuration['task']['goal']['data']['load_conditions'])
    if options.get('validation_source'):
        from extensions.reference.contracts import PassiveResponseEvaluationV2
        ev = PassiveResponseEvaluationV2.model_validate(configuration['task']['evaluator']['parameters']['data'])
        return count * (2 + len(ev.numerical_confirmation.variants)), None
    if not options.get('passive_ablation'):
        return count, None
    reusable = None if options.get('initial_state_result') else baseline(
        store, study_id, candidate, configuration, metadata_only=True)
    return (count if reusable else 2 * count), reusable['reference'] if reusable else None


def stage(store, study_id, candidate, configuration, reference, folder):
    """Copy and hash-check immutable owned trace files inside the new worker.

    No model build, integration, imported acceptance or new baseline charge.
    Original results, trace identities, costs and receipts remain untouched.
    """
    saved = baseline(store, study_id, candidate, configuration, reference=reference)
    result, raw = saved['result'], saved['raw']
    source_root = (store.root / 'physical_replay' / result['execution_id']).resolve()
    if not source_root.is_relative_to((store.root / 'physical_replay').resolve()):
        raise ValueError('PASSIVE_BASELINE_OUTSIDE_OWNED_EXECUTION')
    destination = Path(folder).resolve() / 'reused_baseline'
    io_path(destination).mkdir(parents=True, exist_ok=False)
    for manifest in raw['trace_files']:
        relative = Path(manifest['path'])
        source, target = (source_root / relative).resolve(), (destination / relative).resolve()
        if not source.is_relative_to(source_root) or not target.is_relative_to(destination):
            raise ValueError('PASSIVE_BASELINE_TRACE_PATH_OUTSIDE_EXECUTION')
        io_path(target.parent).mkdir(parents=True, exist_ok=True)
        shutil.copyfile(io_path(source), io_path(target))
        digest = hashlib.sha256()
        with io_path(target).open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
        if io_path(target).stat().st_size != manifest['bytes'] or digest.hexdigest() != manifest['sha256']:
            raise ValueError('PASSIVE_BASELINE_TRACE_IMMUTABILITY_MISMATCH')
    # These are Store/parent observation envelopes, added after the original
    # native arm completed. execute_pair signs the unchanged native arm body.
    arm = {k: v for k, v in raw.items() if k not in
           ('boundary', 'implementation', 'cost_observation_scope', 'unobserved_work_possible')}
    return dict(raw=arm, execution_directory=str(destination),
                source=dict(reference=saved['reference'], pointer='/raw_reference',
                            original_raw_reference=result['raw_reference']),
                actual_new_cost={k: 0 for k in raw.get('cost', {})
                                 if isinstance(raw['cost'][k], (int, float))})
