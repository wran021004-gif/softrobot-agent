"""Local trusted-host SQLite ledger. Transactions cover rows and immutable blobs.

Working directories are not transactions. External side effects can finish without
a commit; such reservations remain unknown and are never automatically replayed.
"""
from tools.paths import RUNS
from contextlib import contextmanager, closing, nullcontext
from copy import deepcopy
from contextvars import ContextVar

_READ_SNAPSHOT=ContextVar("store_read_snapshot",default=None)
_ARTIFACT_INLINE_BYTES=1024*1024*1024
_ARTIFACT_CHUNK_BYTES=4*1024*1024
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
from uuid import uuid4
from schemas.platform import MeasuredCost, EvidenceRef, ProjectConfig, Event, VERSION
from tools.paths import ROOT
from tools.state_io import digest


def plain(value):
    return value.model_dump(mode='json') if hasattr(value, 'model_dump') else value


def encode(value):
    return json.dumps(plain(value), ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def zero():
    return dict(tool_calls=0, model_calls=0, backend_solves=0, worker_calls=0, wall_s=0.)


def now():
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.db = self.root / 'platform.sqlite'

    def connect(self, readonly=False):
        if readonly:
            db = sqlite3.connect(self.db.as_uri() + '?mode=ro', uri=True, timeout=10)
            db.execute('PRAGMA query_only=ON')
        else:
            db = sqlite3.connect(self.db, timeout=10)
            db.execute('PRAGMA synchronous=FULL')
        db.row_factory = sqlite3.Row
        return db

    @contextmanager
    def read_snapshot(self):
        """Request-local immutable reads; discarded on exit, never persisted."""
        current=_READ_SNAPSHOT.get()
        if current is not None and current[0] is self:
            yield current[1]
            return
        # Keep a connection open only to observe commits, not a SQLite read
        # transaction. PRAGMA data_version on a fresh connection is always 1.
        with closing(self.connect(True)) as observer:
            revision=observer.execute('PRAGMA data_version').fetchone()[0]
            token=_READ_SNAPSHOT.set((self,{},observer,[revision]))
            try:yield _READ_SNAPSHOT.get()[1]
            finally:_READ_SNAPSHOT.reset(token)

    def snapshot_value(self, key, build):
        current=_READ_SNAPSHOT.get()
        if current is None or current[0] is not self:return build()
        cache=current[1]
        revision=current[2].execute('PRAGMA data_version').fetchone()[0]
        if revision!=current[3][0]:
            cache.clear();current[3][0]=revision
        if key not in cache:cache[key]=build()
        return deepcopy(cache[key])

    def create_context_archive(self):
        """Artifact-only offline checkpoint Store; never an execution grant.

        The ordinary host requires project configuration and sessions, which this
        archive deliberately does not contain. Existing project Stores are not
        converted or modified by this operation.
        """
        if self.db.exists():
            with closing(self.connect(True)) as db:
                row = db.execute("SELECT value FROM meta WHERE key='context_archive'").fetchone()
                if row is None or json.loads(row[0]) != str(self.root):
                    raise ValueError('CONTEXT_ARCHIVE_STORE_REQUIRED')
            return
        self.root.mkdir(parents=True, exist_ok=True)
        with closing(self.connect()) as db:
            with db:
                db.executescript('CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);'
                    'CREATE TABLE artifacts (id TEXT PRIMARY KEY, media TEXT NOT NULL, body BLOB NOT NULL);')
                db.execute('INSERT INTO meta VALUES (?,?)', ('context_archive', encode(str(self.root))))

    def put_context_checkpoint(self, value):
        """Use the existing immutable blob contract without creating a session."""
        self.create_context_archive()
        with closing(self.connect()) as db:
            with db:
                db.execute('BEGIN IMMEDIATE')
                return plain(self.put(db, value))

    @contextmanager
    def transaction(self):
        db = self.connect()
        try:
            db.execute('BEGIN IMMEDIATE')
            self.check_root(db)
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def create(self, config):
        config = ProjectConfig.model_validate(config)
        if any(type(n) is not int or n < 1 for n in config.exclusive_resources.values()):
            raise ValueError('INVALID_RESOURCE_CAPACITY')
        # One machine/workspace authority index: copying a project cannot mint a grant.
        # This is a trusted local anchor, NOT authentication or tamper resistance.
        anchor = RUNS / '.platform_authorities.sqlite'
        anchor.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(anchor, timeout=10) as db:
            db.execute('CREATE TABLE IF NOT EXISTS grants (grant_id TEXT PRIMARY KEY, root TEXT, config_hash TEXT)')
            db.execute('BEGIN IMMEDIATE')
            prior = db.execute('SELECT root,config_hash FROM grants WHERE grant_id=?', (config.grant_id,)).fetchone()
            if prior and prior != (str(self.root), digest(plain(config))):
                raise ValueError('GRANT_ALREADY_BOUND: copying a directory does not create a new budget')
            if self.db.exists():
                raise ValueError('PROJECT_ALREADY_EXISTS')
            self.root.mkdir(parents=True, exist_ok=True)
            db.execute('INSERT OR IGNORE INTO grants VALUES (?,?,?)', (config.grant_id, str(self.root), digest(plain(config))))
        # Crash between anchor and project creation permits only same-root retry.
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE artifacts (id TEXT PRIMARY KEY, media TEXT NOT NULL, body BLOB NOT NULL);
                CREATE TABLE sessions (run_id TEXT PRIMARY KEY, snapshot TEXT NOT NULL, status TEXT NOT NULL, state TEXT NOT NULL);
                CREATE TABLE calls (run_id TEXT, request_id TEXT, request_hash TEXT NOT NULL, execution_id TEXT UNIQUE,
                    caller TEXT, status TEXT, reserved TEXT, charged TEXT, resources TEXT, cache_key TEXT,
                    receipt TEXT, parent_id TEXT, PRIMARY KEY(run_id,request_id));
                CREATE TABLE events (seq INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, body TEXT);
                CREATE TABLE memories (id TEXT PRIMARY KEY, run_id TEXT, body TEXT);
                CREATE TABLE workers (run_id TEXT, work_id TEXT, order_json TEXT, status TEXT, pid INTEGER,
                    output TEXT, reason TEXT, PRIMARY KEY(run_id,work_id));
                CREATE TABLE merges (run_id TEXT, work_id TEXT, claim_key TEXT, conclusion TEXT,
                    output TEXT, PRIMARY KEY(run_id,work_id));
            ''')
            db.executemany('INSERT INTO meta VALUES (?,?)', [('root', encode(str(self.root))), ('config', encode(config)), ('version', encode(VERSION))])
        return plain(config)

    def check_root(self, db):
        root = json.loads(db.execute("SELECT value FROM meta WHERE key='root'").fetchone()[0])
        if root != str(self.root):
            raise ValueError('PROJECT_MOVED_OR_COPIED: read-only export is available; execution requires explicit migration of the authorization binding')
        cfg = json.loads(db.execute("SELECT value FROM meta WHERE key='config'").fetchone()[0])
        anchor = RUNS / '.platform_authorities.sqlite'
        with sqlite3.connect(anchor.as_uri() + '?mode=ro', uri=True) as grants:
            row = grants.execute('SELECT root,config_hash FROM grants WHERE grant_id=?', (cfg['grant_id'],)).fetchone()
        if row != (root, digest(cfg)):
            raise ValueError('AUTHORITY_ANCHOR_MISMATCH')

    def config(self, db=None):
        if db is not None:
            return json.loads(db.execute("SELECT value FROM meta WHERE key='config'").fetchone()[0])
        with self.connect(True) as conn:
            return self.config(conn)

    def put(self, db, value, media='application/json'):
        body = value if isinstance(value, bytes) else encode(value).encode('utf8')
        identity = hashlib.sha256(body).hexdigest()
        if db.execute('SELECT 1 FROM artifacts WHERE id=?',(identity,)).fetchone() is None:
            # Keep the original content identity and EvidenceRef contract. A large
            # native trace can exceed SQLite's per-value limit even though the
            # database has ample capacity; its immutable bytes share this same
            # transaction in bounded rows, with no filesystem side effects.
            bound=max(1,db.getlimit(sqlite3.SQLITE_LIMIT_LENGTH)-4096)
            if len(body)<=min(_ARTIFACT_INLINE_BYTES,bound):
                db.execute('INSERT INTO artifacts VALUES (?,?,?)',(identity,media,body))
            else:
                size=min(_ARTIFACT_CHUNK_BYTES,bound);count=(len(body)+size-1)//size
                marker=encode(dict(artifact_storage='sqlite_chunks_v1',bytes=len(body),chunks=count,chunk_bytes=size)).encode('utf8')
                db.execute('CREATE TABLE IF NOT EXISTS artifact_chunks (id TEXT NOT NULL,idx INTEGER NOT NULL,body BLOB NOT NULL,PRIMARY KEY(id,idx))')
                db.execute('INSERT INTO artifacts VALUES (?,?,?)',(identity,media,marker))
                for index,start in enumerate(range(0,len(body),size)):
                    db.execute('INSERT INTO artifact_chunks VALUES (?,?,?)',(identity,index,body[start:start+size]))
        return EvidenceRef(artifact_id=identity, media_type=media)

    def verified_artifact_body(self, db, ref):
        """Return the original bytes, verifying inline or transactional chunks."""
        ref=EvidenceRef.model_validate(ref)
        def invalid():raise ValueError('EVIDENCE_MISSING_OR_CHANGED: '+ref.artifact_id)
        row=db.execute('SELECT body,media FROM artifacts WHERE id=?',(ref.artifact_id,)).fetchone()
        if row is None or row['media']!=ref.media_type:invalid()
        body=row['body']
        if hashlib.sha256(body).hexdigest()==ref.artifact_id:return body
        try:
            marker=json.loads(body)
            if (set(marker)!={'artifact_storage','bytes','chunks','chunk_bytes'} or marker['artifact_storage']!='sqlite_chunks_v1'
                    or any(type(marker[k]) is not int or marker[k]<=0 for k in ('bytes','chunks','chunk_bytes'))
                    or marker['chunks']!=(marker['bytes']+marker['chunk_bytes']-1)//marker['chunk_bytes']):invalid()
            parts=[];digest=hashlib.sha256();total=0
            for index,part in enumerate(db.execute('SELECT idx,body FROM artifact_chunks WHERE id=? ORDER BY idx',(ref.artifact_id,))):
                expected=min(marker['chunk_bytes'],marker['bytes']-total)
                if index>=marker['chunks'] or part['idx']!=index or len(part['body'])!=expected:invalid()
                total+=len(part['body']);digest.update(part['body']);parts.append(part['body'])
            if len(parts)!=marker['chunks'] or total!=marker['bytes'] or digest.hexdigest()!=ref.artifact_id:invalid()
            return b''.join(parts)
        except (sqlite3.DatabaseError,TypeError,KeyError,UnicodeError,json.JSONDecodeError):invalid()

    def artifact_bodies(self, db):
        """Export actual content bytes, never a chunk-storage marker."""
        for row in db.execute('SELECT id,media FROM artifacts ORDER BY id'):
            yield dict(id=row['id'],media=row['media'],body=self.verified_artifact_body(db,
                EvidenceRef(artifact_id=row['id'],media_type=row['media'])))

    def artifact(self, ref, *, raw=False, db=None, paths=None, pointers=None, omit=None):
        """Hash-verified artifact; optional dot paths avoid decoding unrelated arrays."""
        ref = EvidenceRef.model_validate(ref)
        if db is None:
            def read():
                current=_READ_SNAPSHOT.get()
                if paths and not raw and pointers is None and omit is None and current is not None and current[0] is self:
                    # Metadata consumers often ask for different overlapping
                    # field sets. Reuse verified fields, including absent ones,
                    # without retaining a second copy of a large raw JSON blob.
                    fields=current[1].setdefault(('artifact_fields',ref.artifact_id,ref.media_type),{})
                    def field(path):
                        if path in fields:return fields[path]
                        for prefix,(present,value) in fields.items():
                            if present and path.startswith(prefix+'.'):
                                for key in path[len(prefix)+1:].split('.'):
                                    if not isinstance(value,dict) or key not in value:return False,None
                                    value=value[key]
                                return True,value
                        return None
                    missing=[path for path in paths if field(path) is None]
                    if missing:
                        with closing(self.connect(True)) as conn:
                            selected=self.artifact(ref,db=conn,paths=missing)
                        for path in missing:
                            value=selected;present=True
                            for key in path.split('.'):
                                if not isinstance(value,dict) or key not in value:present=False;value=None;break
                                value=value[key]
                            fields[path]=(present,value)
                    result={}
                    for path in paths:
                        present,value=field(path)
                        if not present:continue
                        target=result;keys=path.split('.')
                        for key in keys[:-1]:target=target.setdefault(key,{})
                        target[keys[-1]]=value
                    return result
                with closing(self.connect(True)) as conn:
                    return self.artifact(ref, raw=raw, db=conn, paths=paths,pointers=pointers,omit=omit)
            return self.snapshot_value(('artifact',ref.artifact_id,raw,tuple(paths) if paths is not None else None,
                tuple(pointers) if pointers is not None else None,tuple(omit) if omit is not None else None),read)
        def verified_body():
            return self.verified_artifact_body(db,ref)
        projected=paths is not None or pointers is not None or omit is not None
        if projected:
            if raw or ref.media_type!='application/json' or sum(v is not None for v in (paths,pointers,omit))>1:
                verified_body()
                raise ValueError('JSON_POINTER_PROJECTION_REQUIRED' if pointers is not None else 'JSON_PATH_PROJECTION_REQUIRED')
            def document():
                # SQLite JSONB is a request-local parse of the verified original,
                # never a second persisted artifact or a replacement identity.
                return db.execute('SELECT jsonb(?)',(verified_body(),)).fetchone()[0]
            body=(self.snapshot_value(('artifact_jsonb',ref.artifact_id,ref.media_type),document)
                if db.execute('PRAGMA query_only').fetchone()[0] else document())
        else:
            body=verified_body()
        if omit is not None:
            # Internal metadata projections may omit large arrays. Expand only
            # array lengths in SQLite; never materialize their elements in Python.
            # Original full/pointer reads and their content identity are unchanged.
            concrete=[]
            for pattern in omit:
                pending=['$.'+pattern]
                while pending:
                    path=pending.pop()
                    if '[*]' not in path:
                        concrete.append(path);continue
                    prefix,suffix=path.split('[*]',1)
                    length=db.execute('SELECT json_array_length(?,?)',(body,prefix)).fetchone()[0] or 0
                    pending.extend(prefix+'['+str(i)+']'+suffix for i in range(length))
            if not concrete:return json.loads(db.execute('SELECT json(?)',(body,)).fetchone()[0])
            return json.loads(db.execute('SELECT json_remove(?'+',?'*len(concrete)+')',[body,*concrete]).fetchone()[0])
        def extract(queries):
            # Bind the binary document once. Types distinguish absent fields from
            # explicit JSON null without reparsing the full document per miss.
            args=[body,*queries];parameters=['?'+str(i+2) for i in range(len(queries))]
            values='json_extract(?1,'+','.join([*parameters,parameters[0]])+')'
            types='json_array('+','.join('json_type(?1,'+p+')' for p in parameters)+')'
            row=db.execute('SELECT '+values+','+types,args).fetchone()
            return json.loads(row[0])[:-1],json.loads(row[1])
        if pointers is not None:
            queries=[]
            for pointer in pointers:
                if pointer and not pointer.startswith('/'):raise ValueError('JSON_POINTER_REQUIRED')
                path='$'
                for token in pointer[1:].split('/') if pointer else []:
                    token=token.replace('~1','/').replace('~0','~')
                    kind=(db.execute('SELECT json_type(?,?)',(body,path)).fetchone()[0]
                        if token.isdecimal() else None)
                    if kind=='array':
                        if not token.isdecimal() or str(int(token))!=token:raise KeyError(pointer)
                        path+='['+token+']'
                    else:path+='.'+json.dumps(token,ensure_ascii=False)
                queries.append(path)
            if not queries:return {}
            values,types=extract(queries)
            return {pointer:value for pointer,value,kind in zip(pointers,values,types) if kind is not None}
        if paths is not None:
            result={}
            if not paths:return result
            values,types=extract(['$.'+path for path in paths])
            for path,value,kind in zip(paths,values,types):
                if kind is None:continue
                target=result;keys=path.split('.')
                for key in keys[:-1]:target=target.setdefault(key,{})
                target[keys[-1]]=value
            return result
        return body if raw else json.loads(body)

    def session(self, run_id, db=None):
        if db is None:
            def read():
                with closing(self.connect(True)) as conn:
                    return self.session(run_id, conn)
            return self.snapshot_value(('session',run_id),read)
        row = db.execute('SELECT * FROM sessions WHERE run_id=?', (run_id,)).fetchone()
        if row is None:
            raise ValueError('SESSION_NOT_FOUND')
        value = dict(row)
        value['state'] = json.loads(value['state'])
        value['snapshot'] = self.artifact(EvidenceRef(artifact_id=value['snapshot']), db=db)
        return value

    def create_session(self, snapshot):
        run_id = snapshot['input']['run_id']
        with self.transaction() as db:
            reference = self.put(db, snapshot)
            db.execute('INSERT INTO sessions VALUES (?,?,?,?)', (run_id, reference.artifact_id, 'created', encode(dict(turn=0, pending=None, last_receipt=None, model_notes=[], reads={}, repairs=0, repeated=0))))
            self.event(db, run_id, 'session', 'created', outputs=[reference])
        return self.session(run_id)

    def update_state(self, db, run_id, state, status=None):
        db.execute('UPDATE sessions SET state=? WHERE run_id=?', (encode(state), run_id))
        if status:
            db.execute('UPDATE sessions SET status=? WHERE run_id=?', (status, run_id))

    def event(self, db, run_id, kind, status, *, parent=None, request=None, execution=None, caller='host', inputs=(), outputs=(), cost=None, candidate=None, version=VERSION):
        row = db.execute('INSERT INTO events(run_id,body) VALUES (?,?)', (run_id, '{}'))
        event_id = uuid4().hex
        event = Event(project_id=self.config(db)['project_id'], run_id=run_id, sequence=row.lastrowid,
                      event_id=event_id, parent_id=parent, candidate_id=candidate, agent_id=caller,
                      request_id=request, execution_id=execution, timestamp=now(), kind=kind, status=status,
                      inputs=list(inputs), outputs=list(outputs), cost=cost or zero(), implementation_version=version)
        db.execute('UPDATE events SET body=? WHERE seq=?', (encode(event), row.lastrowid))
        return event_id

    def events(self, run_id, parent=None, *, db=None):
        if db is None:
            with self.connect(True) as conn:
                return self.events(run_id, parent, db=conn)
        rows = [json.loads(r[0]) for r in db.execute('SELECT body FROM events WHERE run_id=? ORDER BY seq', (run_id,))]
        if parent:
            selected = {parent}
            for row in rows:
                if row['parent_id'] in selected:
                    selected.add(row['event_id'])
            rows = [r for r in rows if r['event_id'] in selected]
        return rows

    def remaining(self, run_id=None, db=None):
        if db is None:
            with self.connect(True) as conn:
                return self.remaining(run_id, conn)
        limit = self.session(run_id, db)['snapshot']['input']['policy']['budget'] if run_id else self.config(db)['budget']
        if run_id:
            scopes = [run_id]
            for item in db.execute('SELECT run_id,snapshot FROM sessions'):
                snap = self.artifact(EvidenceRef(artifact_id=item['snapshot']), db=db)
                if snap.get('parent_run_id') == run_id:
                    scopes.append(item['run_id'])
            rows = db.execute('SELECT charged FROM calls WHERE run_id IN (' + ','.join('?' for _ in scopes) + ')', scopes)
        else:
            rows = db.execute('SELECT charged FROM calls')
        used = zero()
        for row in rows:
            for key, value in json.loads(row[0]).items():
                used[key] += value
        occupied = {}
        for row in db.execute("SELECT resources FROM calls WHERE status IN ('running','unknown')"):
            for name in json.loads(row[0]):
                occupied[name] = occupied.get(name, 0) + 1
        return dict(limit=limit, used=used, remaining={k: None if limit[k] is None else max(0, limit[k] - used[k]) for k in limit}, occupied=occupied)

    def phase_remaining(self, run_id, db=None):
        """Opt-in phase ceilings and downstream reservations, in the shared ledger."""
        if db is None:
            with self.connect(True) as conn:
                return self.phase_remaining(run_id, conn)
        state = self.session(run_id, db)['state']
        phase = state.get('role_context', {}).get('phase_budget')
        if phase is None:
            return None
        project = self.remaining(None, db)['remaining']
        role = self.remaining(run_id, db)
        grant = state.get('role_grant', {}).get('budget', role['limit'])
        used = {k: role['used'][k] - phase['started_usage'][k] for k in project}
        available = {k: max(0, min(
            project[k] - phase.get('protect_project', {}).get(k, 0),
            min(role['remaining'][k], grant[k] - role['used'][k]) - phase.get('protect_role', {}).get(k, 0),
            phase.get('limit', {}).get(k, float('inf')) - used[k])) for k in project}
        return dict(**phase, used=used, remaining=available)

    def lookup(self, run_id, request_id, db=None):
        if db is None:
            with self.connect(True) as conn:
                return self.lookup(run_id, request_id, conn)
        row = db.execute('SELECT * FROM calls WHERE run_id=? AND request_id=?', (run_id, request_id)).fetchone()
        return dict(row) if row else None

    def spendable(self, run_id, db=None):
        """The same capacity checks used by reserve, including downstream protection.

        Unsealed reservations are already charged at reserved cost by remaining;
        they must not be subtracted a second time.
        """
        if db is None:
            with self.connect(True) as conn:
                return self.spendable(run_id, conn)
        session = self.session(run_id, db)
        phase = self.phase_remaining(run_id, db)
        limits = [('active phase / protected downstream capacity', phase['remaining'])] if phase else []
        grant = session['state'].get('role_grant')
        if grant:
            used = self.remaining(run_id, db)['used']
            limits.append(('diagnostic request subgrant', {k:v-used[k] for k,v in grant['budget'].items()}))
        parent = session['snapshot'].get('parent_run_id')
        for scope in ([None, run_id, parent] if parent else [None, run_id]):
            limits.append(('project' if scope is None else 'session', self.remaining(scope, db)['remaining']))
        return dict(remaining={k: min((values[k] for _,values in limits if values[k] is not None), default=None) for k in zero()},
                    constraints=[dict(scope=name,remaining=values) for name,values in limits],
                    reservations='Running/unknown calls are charged at reservation until sealed; included once in ledger usage.')

    def reserve(self, run_id, request_id, request_hash, caller, cost, resources=(), cache_key=None, parent=None, inputs=(), kind='tool', version=VERSION, guard=None):
        MeasuredCost.model_validate(cost)
        with self.transaction() as db:
            old = self.lookup(run_id, request_id, db)
            if old:
                if old['request_hash'] != request_hash or old['caller'] != caller:
                    raise ValueError('REQUEST_ID_COLLISION')
                return old, False
            if guard is not None:
                guard(db)  # Scope/count validation and state update share this reservation transaction.
            parent_run = self.session(run_id, db)['snapshot'].get('parent_run_id')
            for constraint in self.spendable(run_id, db)['constraints']:
                if any(constraint['remaining'][k] is not None and cost[k] > constraint['remaining'][k] + 1e-9 for k in cost):
                    raise ValueError('BUDGET_EXHAUSTED: ' + constraint['scope'])
            available = self.config(db)['exclusive_resources']
            occupied = self.remaining(None, db)['occupied']
            for resource in resources:
                if resource not in available or occupied.get(resource, 0) >= available[resource]:
                    raise ValueError('RESOURCE_BUSY_OR_NOT_GRANTED: ' + resource)
            execution_id = uuid4().hex
            event_id = self.event(db, run_id, kind, 'reserved', parent=parent, request=request_id,
                                  execution=execution_id, caller=caller, inputs=inputs, cost=cost, version=version)
            db.execute('INSERT INTO calls VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                       (run_id, request_id, request_hash, execution_id, caller, 'running', encode(cost), encode(cost), encode(list(resources)), cache_key, None, event_id))
            # SQLite column count checked by focused tests, not separate accounting.
            return self.lookup(run_id, request_id, db), True

    def complete(self, row, receipt, output=None, elapsed=0., kind='tool', *, result_execution=None, actual_cost=None, db=None):
        # A pure business service may seal its state and receipt in one transaction.
        with (self.transaction() if db is None else nullcontext(db)) as db:
            current = self.lookup(row['run_id'], row['request_id'], db)
            if current['receipt']:
                return json.loads(current['receipt'])
            charged = json.loads(current['reserved'])
            if actual_cost is not None:
                actual_cost = plain(MeasuredCost.model_validate(actual_cost))
                if any(actual_cost[k] > charged[k] for k in charged if k != 'wall_s'):
                    raise ValueError('SETTLEMENT_EXCEEDS_RESERVED_RESOURCE_COUNT')
                charged = actual_cost
            # Known completion settles actual wall time. Overrun remains charged.
            charged['wall_s'] = max(0, elapsed)
            if output is not None:
                receipt['output'] = plain(self.put(db, output))
            receipt['charged'] = charged
            from schemas.platform import ToolReceipt
            parsed = ToolReceipt.model_validate(receipt)
            self.put(db, parsed)
            if result_execution is not None:
                metadata = {**result_execution, 'artifact_id': parsed.output.artifact_id, 'request_id': row['request_id']}
                state = self.session(row['run_id'], db)['state']
                state.setdefault('result_executions', {})[row['execution_id']] = metadata
                self.update_state(db, row['run_id'], state)
                provenance = self.put(db, dict(execution_id=row['execution_id'], **metadata))
                self.event(db, row['run_id'], 'result_provenance', 'reused' if parsed.cache_hit else 'produced',
                    parent=current['parent_id'], request=row['request_id'], execution=row['execution_id'],
                    caller=row['caller'], inputs=[parsed.output, metadata['candidate_input']], outputs=[provenance],
                    candidate=metadata['candidate'], version=parsed.tool_version)
            db.execute('UPDATE calls SET status=?,charged=?,receipt=? WHERE run_id=? AND request_id=?',
                       (parsed.execution_status, encode(charged), encode(parsed), row['run_id'], row['request_id']))
            self.event(db, row['run_id'], kind, parsed.execution_status, parent=current['parent_id'],
                       request=row['request_id'], execution=row['execution_id'], caller=row['caller'],
                       outputs=[parsed.output] if parsed.output else [], cost=charged, version=parsed.tool_version)
            return plain(parsed)

    def cache(self, run_id, key):
        with self.connect(True) as db:
            rows = db.execute("SELECT receipt FROM calls WHERE run_id=? AND cache_key=? AND status='completed' AND receipt IS NOT NULL ORDER BY rowid DESC", (run_id, key))
            for row in rows:
                value = json.loads(row[0])
                # Reuse always points to a producer, never another cache read.
                # Solver failure is independent of a successful tool invocation.
                if value.get('cache_hit') or not value.get('output') or value.get('solver_status', 'not_run') not in ('not_run', 'completed'):
                    continue
                self.artifact(value['output'], db=db)
                return value
        return None

    def mark_unknown(self, run_id, request_id):
        with self.transaction() as db:
            row = self.lookup(run_id, request_id, db)
            if row and row['status'] == 'running':
                db.execute("UPDATE calls SET status='unknown' WHERE run_id=? AND request_id=?", (run_id, request_id))
                self.event(db, run_id, 'recovery', 'unknown', parent=row['parent_id'], request=request_id, execution=row['execution_id'], cost=json.loads(row['charged']))

    def save_memory(self, run_id, entry):
        with self.transaction() as db:
            for ref in entry.sources:
                self.artifact(ref, db=db)
            old = db.execute('SELECT body FROM memories WHERE id=?', (entry.memory_id,)).fetchone()
            if old and old[0] != encode(entry):
                raise ValueError('MEMORY_IMMUTABLE: new content requires a new identity')
            db.execute('INSERT OR IGNORE INTO memories VALUES (?,?,?)', (entry.memory_id, run_id, encode(entry)))
            self.event(db, run_id, 'memory', 'indexed', inputs=entry.sources)
        return entry

    def memories(self, filters):
        from schemas.platform import MemoryEntry
        result = []
        with self.connect(True) as db:
            for row in db.execute('SELECT body,run_id FROM memories ORDER BY id'):
                entry = MemoryEntry.model_validate_json(row[0])
                if entry.invalidated or (entry.expires_at and entry.expires_at <= now()):
                    continue
                scoped = filters.get('model_scope')
                entry_scope = entry.model_scope
                if scoped and entry_scope is None:
                    source = self.session(row['run_id'], db)['snapshot']['input']
                    entry_scope = digest(dict(robot=source['robot'], backend=source['policy']['backend']))
                transferable = scoped is not None and scoped in entry.transferable_scopes
                if scoped and entry_scope != scoped and not transferable:
                    continue
                if any(value is not None and getattr(entry, key) != value for key, value in filters.items()
                       if key not in ('tags', 'model_scope') and not (key == 'model_id' and transferable)):
                    continue
                if set(filters.get('tags', [])) - set(entry.tags):
                    continue
                try:
                    for ref in entry.sources:
                        self.artifact(ref, db=db)
                except ValueError:
                    continue
                result.append(entry)
        return result
