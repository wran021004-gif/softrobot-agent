from copy import deepcopy
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch
from tools.research.feedback import experiment_preflight


class PassiveConfirmationPreflight(unittest.TestCase):
    def check(self,proposed,previous):
        candidate=dict(artifact_id='candidate');result=dict(artifact_id='result');source=dict(artifact_id='source')
        values={'candidate':{},'source':previous,'result':dict(route='passive_protocol',source_reference=source,candidate=candidate,status='evaluated',acceptance=dict(status='incomplete'))}
        host=SimpleNamespace(store=Mock(),run_id='same');host.store.artifact.side_effect=lambda ref:deepcopy(values[ref['artifact_id']])
        def identity(candidate,route,source=None,**kwargs):
            return dict(identity_version='test',physical={},task={},controller={},runtime={},action=source,missing_effective_fields=[])
        with patch('tools.research.state.state',return_value=dict(spec={},physical_replays=[result])),\
             patch('tools.research.feedback.experiment_identity',side_effect=identity):
            return experiment_preflight(host,candidate,'passive_protocol',source_value=proposed)

    def test_frozen_confirmation_is_distinct_from_development(self):
        development=dict(protocol='same frozen protocol')
        confirmation=dict(**development,execution=dict(validation_source=dict(artifact_id='owned-development')))
        value=self.check(confirmation,development)
        self.assertTrue(value['admitted']);self.assertFalse(value['authorized_as_repeat'])
        self.assertEqual(value['proposed_identity']['action'],confirmation)

    def test_actual_repetition_remains_blocked(self):
        development=dict(protocol='same frozen protocol')
        confirmation=dict(**development,execution=dict(validation_source=dict(artifact_id='owned-development')))
        self.assertFalse(self.check(development,development)['admitted'])
        self.assertFalse(self.check(confirmation,confirmation)['admitted'])


if __name__=='__main__':unittest.main()
