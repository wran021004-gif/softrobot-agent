from copy import deepcopy
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch
from tools.research.diagnostic import diagnose
from tools.research.execution import execute


class DiagnosticAndAdmission(unittest.TestCase):
    def test_missing_measured_input_is_reported_without_inventing_comparison(self):
        refs=[dict(artifact_id='a'),dict(artifact_id='b')]
        results={r['artifact_id']:dict(status='evaluated',execution_id=r['artifact_id']) for r in refs}
        observations={'a':[dict(time_s=0.,actual_tension_n=[1.])],
                      'b':[dict(time_s=0.,policy_stop_reason='no usable returned plan')]}
        originals=deepcopy(observations)
        host=SimpleNamespace(store=MagicMock());host.store.artifact.side_effect=lambda r:results[r['artifact_id']]
        reader=MagicMock();reader.resolve.side_effect=lambda execution_id:dict(id=execution_id)
        reader.read_file.side_effect=lambda source,name,default:observations[source['id']]
        with patch('tools.research.diagnostic.state',return_value=dict(results=refs)),\
             patch('extensions.tendon_family.control_evidence.ControlEvidence',return_value=reader),\
             patch('tools.research.diagnostic.save',return_value=dict(artifact_id='diagnosis')),\
             patch('tools.research.diagnostic.update'):
            result=diagnose(host,refs)
        self.assertIsNone(result['first_action_divergence'])
        self.assertEqual(result['action_divergences'],[])
        self.assertEqual(result['unavailable_action_comparisons'][0]['missing_actual_tension_n'],['variant'])
        self.assertEqual(result['new_scientific_computations'],0)
        self.assertEqual(observations,originals)

    def test_explicit_unsupported_nmpc_rejects_before_reservation(self):
        host=SimpleNamespace(store=MagicMock())
        candidate=dict(profile_identity='same',configuration=dict(task=dict(family='task.position_tool_axis')))
        adapter=SimpleNamespace(execution_requirements=lambda:dict(unsupported_control_methods=['nmpc','ppo']))
        with patch('tools.research.execution.guard'),\
             patch('tools.research.execution.state',return_value=dict(profile=dict(identity='same'))),\
             patch('tools.research.execution.verify_candidate',return_value=candidate),\
             patch('tools.research_tasks.task_adapter',return_value=adapter):
            with self.assertRaisesRegex(ValueError,'NMPC_NOT_SUPPORTED_FOR_TASK: task.position_tool_axis'):
                execute(host,dict(artifact_id='candidate'),'operation')
        host.store.reserve.assert_not_called()


if __name__=='__main__':unittest.main()
