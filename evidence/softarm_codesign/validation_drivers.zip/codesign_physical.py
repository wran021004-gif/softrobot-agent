"""Authorized one-off engineering driver; reuse production execution/collection.

No formal Study, Provider, training or retry. Each launch owns a new directory.
"""
import sys
import time
from copy import deepcopy
import numpy as np
from schemas.platform import SessionInput, BackendResult, ProjectConfig
from tools.platform_host import Host
from tools.platform_store import plain
from tools.platform_registry import registry
from tools.platform_tasks import compile_input
from tools.state_io import read, atomic_json, digest
from tools.research.config import ROOT
from tools.research_tasks import assemble_acceptance
from tools.research.physical_replay import model_context, binding, playback_profile
from tools.execution_completion import complete_execution
from extensions.tendon_family.backends import playback_tensions
from extensions.tendon_family.control_evidence import COMPLETE_UPDATE_INPUTS
from tests.research import s135_development as development

OUT=ROOT/'evidence/softarm_codesign'
RUNS=ROOT/'runs/codesign_development'
AUTH='2026-10-23 user attachment: codesign integration engineering validation, at most 3 new physical launches and 2 full NMPC; no formal Study, Provider, PPO or hardware'
development.OUT=OUT
development.RUNS=RUNS

def light():
    folder=RUNS/'fixed_tension'
    cfg=read(ROOT/'evidence/s135_development/tracking_input.json')
    cfg['run_id']='codesign-fixed-tension'
    cfg['task']['timing'].update(control_period_s=.01,sample_period_s=.01)
    approval=compile_input(cfg)['approval']
    inp,physics,scene,spec=model_context(cfg)
    period=inp.task.timing.control_period_s;count=round(inp.task.timing.duration_s/period)
    commands=np.tile([t['pretension_n'] for t in cfg['robot']['structure']['data']['tendons']],(count,1))
    trajectory=dict(times_s=(np.arange(count+1)*period).tolist(),tensions_n=commands.tolist(),
        tendon_order=spec['tendon_order'],model_identity=spec['identity'],design_identity=spec['design_identity'],
        task_identity=digest(cfg['task']))
    binding(cfg,trajectory)
    folder.mkdir(parents=True,exist_ok=False)
    atomic_json(folder/'input.json',dict(configuration=cfg,trajectory=trajectory,authorization=AUTH,approval=approval))
    atomic_json(folder/'launch.json',dict(launch_index=1,kind='fixed_tension',status='started'))
    started=time.perf_counter()
    raw=playback_tensions(inp,physics,scene,commands,folder)
    raw['elapsed_s']=time.perf_counter()-started
    atomic_json(folder/'raw.json',raw)
    samples=raw['samples'][1:];signal=inp.task.observations[0]
    result=BackendResult(solver_status='completed' if raw['status']=='completed' else 'failed',
        backend_id='backend.family_mujoco',model_id='mujoco_serial_bending_v1',
        signals=[dict(spec=signal,times_s=[s['time_s'] for s in samples],values=[s['tip_m'] for s in samples])],
        data=dict(contract='family.backend_data',data=dict(physical_replay=True,numerical_steps=raw['physics_steps'])),
        limitations=['Fixed candidate pretension; no NMPC, feasibility, hardware or robustness claim'],
        initial_state=inp.task.initializer.parameters,seed=inp.seed)
    source=dict(artifact_id=digest(raw),media_type='application/json')
    evaluation=registry().get(inp.task.evaluator.extension_id,inp.task.evaluator.version,'evaluator').resolve()(
        inp.task,result,source,registry(),digest(cfg))
    profile=playback_profile(inp,raw,evaluation)
    acceptance=assemble_acceptance(cfg,evaluation,profile,motion=raw['samples'])
    summary=dict(authorization=AUTH,physical_launches=1,nmpc_updates=0,complete=profile['complete'],
        physics_steps=raw['physics_steps'],physics_timestep_s=raw['physics_timestep_s'],
        control_period_s=period,command_intervals=count,elapsed_s=raw['elapsed_s'],
        initial_sample=raw['samples'][0],final_sample=raw['samples'][-1],profile=profile,acceptance=acceptance)
    atomic_json(folder/'backend_result.json',plain(result))
    atomic_json(folder/'evaluation.json',plain(evaluation))
    atomic_json(OUT/'fixed_tension_summary.json',summary)
    import zipfile
    with zipfile.ZipFile(OUT/'fixed_tension_evidence.zip','x',zipfile.ZIP_DEFLATED) as archive:
        for path in folder.iterdir():
            if path.is_file():archive.write(path,path.name)
    print(dict(physics_steps=raw['physics_steps'],complete=profile['complete'],acceptance=acceptance['status']))

def tracking():
    cfg=read(ROOT/'evidence/s135_development/tracking_input.json')
    cfg['run_id']='codesign-untimed-tracking'
    approval=compile_input(cfg)['approval']
    atomic_json(OUT/'tracking_input.json',cfg)
    folder=RUNS/'tracking'
    folder.mkdir(parents=True,exist_ok=False)
    atomic_json(folder/'launch.json',dict(launch_index=2,kind='closed_loop_nmpc',status='started',
        authorization=AUTH,approval=approval))
    host=Host(folder,cfg['run_id'])
    host.store.create(ProjectConfig(project_id=cfg['run_id'],grant_id=cfg['run_id'],
        authorization_source=AUTH,budget=cfg['policy']['budget']))
    host.create(cfg)
    token=COMPLETE_UPDATE_INPUTS.set(True)
    try:outcome=complete_execution(host,cfg,'codesign-tracking')
    finally:COMPLETE_UPDATE_INPUTS.reset(token)
    atomic_json(folder/'outcome.json',outcome)
    development.collect('tracking')

if sys.argv[1]=='light':light()
elif sys.argv[1]=='tracking':tracking()
elif sys.argv[1]=='collect':development.collect('tracking')
else:raise ValueError('Unknown engineering operation')
