import json
import subprocess
import unittest
import zipfile
from pathlib import Path
import numpy as np
from tools.state_io import atomic_json, read
from tools.research.config import ROOT
from tools.platform_registry import registry
from tools.platform_store import plain
from schemas.platform import SessionInput, BackendResult
from tools.research_tasks import assemble_acceptance

OUT=ROOT/'evidence/softarm_codesign'
with zipfile.ZipFile(OUT/'tracking_evidence.zip') as archive:
    assert archive.testzip() is None
    names=archive.namelist()
    records={name:json.loads(archive.read(name+'.json')) for name in (
        'configuration','simulation_result','profile','evaluation','acceptance','controller_observations','actual_commands','motion')}
    updates=records['controller_observations']
    assert len(updates)==20 and all(u['plan_accepted'] for u in updates)
    for u in updates:
        complete=u['complete_update_record']
        assert complete['resolved_problem_reference']['filename'] in names
        assert complete['resolved_problem_reference']['filename'].startswith('p_')
    assert records['simulation_result']['data']['data']['numerical_steps']==400
    result=BackendResult.model_validate(records['simulation_result'])
    velocity=next(s for s in result.signals if s.spec.name=='tip_velocity')
    assert velocity.spec.phase=='post_step' and velocity.spec.units=='m/s'
    np.testing.assert_allclose(velocity.times_s,np.arange(1,21)*.02,rtol=0,atol=1e-12)
    assert np.isfinite(velocity.values).all()
    inp=SessionInput.model_validate(records['configuration']);saved=records['evaluation']
    evaluation=registry().get(inp.task.evaluator.extension_id,inp.task.evaluator.version,'evaluator').resolve()(
        inp.task,result,saved['source'],registry(),saved['candidate_id'])
    assert plain(evaluation)['metrics']==saved['metrics']
    acceptance=assemble_acceptance(records['configuration'],evaluation,records['profile'])
    assert acceptance['status']=='valid_failure'
    assert acceptance['components']==records['acceptance']['components']
    physics=records['simulation_result']['data']['data']['numerical_steps']
with zipfile.ZipFile(ROOT/'evidence/s135_development/tracking_evidence.zip') as archive:
    old=BackendResult.model_validate(json.loads(archive.read('simulation_result.json')))
    old_positions=next(s for s in old.signals if s.spec.name=='tip_position')
    positions=next(s for s in result.signals if s.spec.name=='tip_position')
    assert plain(old_positions)==plain(positions)
    assert json.loads(archive.read('evaluation.json'))['metrics']==saved['metrics']
    old_cfg=json.loads(archive.read('configuration.json'))
    assert old_cfg['task']==records['configuration']['task']
    assert old_cfg['robot']==records['configuration']['robot']
    assert old_cfg['policy']==records['configuration']['policy']

batches=[
    ['tests.research.test_s137_task_runtime','tests.research.test_s138_research','tests.research.test_s139_execution'],
    ['tests.research.test_codesign_integration','tests.research.test_s135_control','tests.research.test_s127_math_admission',
     'tests.research.test_mixed_search.MixedSearchTests.test_feedback_lineage_conditional_coordinates_and_reuse',
     'tests.research.test_mixed_search.MixedSearchTests.test_pending_checkpoint_recovery_reuses_sealed_analysis',
     'tests.research.test_mixed_search.MixedSearchTests.test_invalid_attempts_and_failed_math_keep_cost_and_bounds'],
    ['tests.research.test_s135_control.ControlTests.test_reward_components_and_saved_stage_configuration',
     'tests.research.test_s135_control.ControlTests.test_rl_observation_and_direct_residual_mapping_without_physical_steps',
     'tests.research.test_s139_execution','tests.research.test_tracking_math','tests.research.test_task_analysis_contract']]
def ids(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from ids(item)
        else:yield item.id()
passed=set()
for batch in batches:passed.update(ids(unittest.defaultTestLoader.loadTestsFromNames(batch)))
assert not any('_FailedTest' in t for t in passed)
assert len(passed)==61,len(passed)
legacy=read(ROOT/'evidence/s138_task_conditioned/validation.json')['baseline_reproduction']['unchanged_failures']
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
summary=read(OUT/'tracking_summary.json')
validation=dict(date='2026-10-23',timezone='Asia/Shanghai',implementation_commit=revision,
    branch='mainline/softarm-codesign',unique_tests_final_passed=len(passed),new_integration_tests=3,
    targeted_batches=[dict(modules=batch,tests=n,elapsed_s=t,final_status=status) for batch,n,t,status in zip(
        batches,[26,14,30],[11.322,55.164,11.058],['passed','12 passed; two gymnasium import errors repaired in next batch','passed'])],
    known_baseline_reproduction=dict(tests=3,elapsed_s=3.064,unchanged_failures=legacy),
    setup_corrections=['Created ignored runs directory for existing fixtures',
        'Corrected test_s137_runtime command to test_s137_task_runtime',
        'Reused installed S135 composite environment for gymnasium tests; no installations'],
    environments=dict(research_python='D:/softrobot-agent/.f3-prestudy-env/Scripts/python.exe',
        combined_python='D:/softrobot-agent/.worktrees/s135-task-conditioned-control/.s135-env/Scripts/python.exe',
        lightweight_python='D:/softrobot-agent/.rl-pilot-env/Scripts/python.exe',
        PYTHONPATH='.;tests/research',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),
    numerical_checks=dict(real_generated_gvs_models=['constant','free_progress','timed'],
        real_offline_ipopt=['constant','free_progress','timed'],offline_horizon=2,offline_substeps=1,offline_max_iterations=3,
        scope='Interface/cost/model consistency, not convergence or task feasibility'),
    new_physics=dict(launches=2,launch_limit=3,nmpc_launches=1,nmpc_launch_limit=2,
        steps=800,fixed_tension_steps=400,closed_loop_steps=physics,complete=True,
        tracking_updates=20,complete_plan_records=20,raw_solver_statuses=summary['raw_solver_statuses'],
        solver_errors=summary['solver_errors'],force_bound_violation_n=summary['force_bound_violation_n'],
        tracking_simulation_wall_s=summary['simulation_wall_s'],
        original_task_robot_and_control_unchanged=True,tracking_saved_positions_identical_to_s135=True,
        independent_archive_reevaluation='metrics and acceptance components agree; valid_failure',
        unused_physical_launches=1,unused_nmpc_launches=1,automatic_retries=0),
    excluded_execution=dict(provider_calls=0,ppo_training=0,formal_studies=0,matlab_calls=0,hardware=0),
    evidence=dict(historical='historical_recheck.json',light_rl='rl_light_reset.json',
        fixed_tension='fixed_tension_evidence.zip',tracking='tracking_evidence.zip',
        driver_sources='validation_drivers.zip'),
    limitations=['Three documented old mixed-search failures remain',
        'Existing CLARABEL synthetic sensitivity warning does not establish strict optimality',
        '20 feasible returned plans are iteration-limited, not converged; no task success or structure benefit demonstrated'])
atomic_json(OUT/'validation.json',validation)
with zipfile.ZipFile(OUT/'validation_drivers.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for name in ('codesign_offline.py','codesign_physical.py','codesign_closeout.py'):
        archive.write(ROOT/'runs'/name,name)
    archive.write(ROOT/'runs/codesign_development/tracking/launch.json','tracking_launch.json')
    archive.write(ROOT/'runs/codesign_tracking_console.txt','tracking_console.txt')
print(json.dumps(dict(passed=len(passed),physics_steps=800,complete_plan_records=20,
    tracking_metrics=acceptance['metrics'],raw_status=summary['raw_solver_statuses'],
    simulation_wall_s=summary['simulation_wall_s'])))
