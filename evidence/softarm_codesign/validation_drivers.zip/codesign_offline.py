from copy import deepcopy
import hashlib
import json
from pathlib import Path
import zipfile
from schemas.platform import SessionInput, BackendResult
from tools.platform_store import Store, plain
from tools.platform_registry import registry
from tools.research.config import ROOT, resolve
from tools.state_io import atomic_json, read
from tools.research_tasks import assemble_acceptance
from extensions.tendon_family.control_evidence import ControlEvidence
from extensions.tendon_family.backends import physics_for
from extensions.tendon_family.scene import assemble
from extensions.tendon_family.mjcf import compile_xml

OUT=ROOT/'evidence/softarm_codesign'
OUT.mkdir(parents=True,exist_ok=True)
summary={}
source_root=ROOT.parent/'s135-task-conditioned-control/runs/s135_development/reach'
store=Store(source_root)
outcome=read(source_root/'outcome.json')
cfg=store.session('s135-development-reach')['snapshot']['input']
source=ControlEvidence(store).resolve(outcome['execution_id'])
saved=store.artifact(outcome['receipts']['evaluation']['output'])
profile=store.artifact(outcome['receipts']['profile']['output'])['detail']
raw=store.artifact(outcome['receipts']['simulation']['output'])
motion=store.artifact(profile['motion'])
inp=SessionInput.model_validate(cfg)
evaluation=registry().get(inp.task.evaluator.extension_id,inp.task.evaluator.version,'evaluator').resolve()(
    inp.task,BackendResult.model_validate(raw),saved['source'],registry(),saved['candidate_id'])
assert plain(evaluation)['metrics']==saved['metrics']
assert evaluation.task_success==saved['task_success'] and evaluation.validity==saved['validity']
old_acceptance=assemble_acceptance(cfg,saved,profile,motion=motion)
acceptance=assemble_acceptance(cfg,evaluation,profile,motion=motion)
assert all(old_acceptance[k]==acceptance[k] for k in ('status','accepted','components','metrics','missing','issues'))
with zipfile.ZipFile(OUT/'historical_reach_evaluation.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for name,value in dict(configuration=cfg,simulation_result=raw,saved_evaluation=saved,profile=profile,
            motion=motion,recomputed_evaluation=plain(evaluation),acceptance=acceptance,outcome=outcome).items():
        archive.writestr(name+'.json',json.dumps(value,ensure_ascii=False,indent=2))
    for name in ('actual_commands.json','controller_observations.json'):
        archive.writestr(name,store.artifact(source['files'][name],raw=True))
summary['reach']=dict(source_store=str(source_root),source_execution_id=outcome['execution_id'],
    metrics_unchanged=True,acceptance=acceptance,physics_steps=raw['data']['data']['numerical_steps'],
    raw_solver_statuses=profile['raw_termination_counts'],complete=profile['complete'],
    updates=profile['updates'],accepted_plans=profile['accepted_plans'],new_physics_steps=0,
    source_archive='historical_reach_evaluation.zip')
with zipfile.ZipFile(ROOT/'evidence/s135_development/tracking_evidence.zip') as archive:
    data={name:json.loads(archive.read(name+'.json')) for name in ('configuration','simulation_result','evaluation','profile')}
cfg=data['configuration'];inp=SessionInput.model_validate(cfg);saved=data['evaluation']
evaluation=registry().get(inp.task.evaluator.extension_id,inp.task.evaluator.version,'evaluator').resolve()(
    inp.task,BackendResult.model_validate(data['simulation_result']),saved['source'],registry(),saved['candidate_id'])
assert plain(evaluation)['metrics']==saved['metrics']
assert evaluation.task_success==saved['task_success'] and evaluation.validity==saved['validity']
acceptance=assemble_acceptance(cfg,evaluation,data['profile'])
old_acceptance=assemble_acceptance(cfg,saved,data['profile'])
assert all(old_acceptance[k]==acceptance[k] for k in ('status','accepted','components','metrics','missing','issues'))
summary['tracking']=dict(source_archive='../s135_development/tracking_evidence.zip',metrics_unchanged=True,
    acceptance=acceptance,new_physics_steps=0,complete=data['profile']['complete'])
atomic_json(OUT/'historical_recheck.json',summary)

# Prepare a real Reach XML and frozen settings for the original light RL interpreter.
cfg=resolve(ROOT/'configs/research/study.json')['configuration'];inp=SessionInput.model_validate(cfg)
physics=physics_for(inp);scene=assemble(inp,physics)
folder=ROOT/'runs/codesign_rl_light';folder.mkdir(exist_ok=False)
xml=compile_xml(physics,scene,registry().parse(inp.policy.backend.parameters),folder/'robot.xml').read_text()
settings=deepcopy(resolve(ROOT/'configs/research/study.json')['control']['rl_defaults'])
settings.update(mode='direct',reference=None,candidate=dict(xml=xml,sha256=hashlib.sha256(xml.encode()).hexdigest(),
    identity=physics['identity'],task_identity=scene['task_identity']),
    control_object=dict(joint_names=physics['dofs'],tendon_names=[t['entity'] for t in physics['tendons']],
        actuator_names=[t['entity']+'_direct_tension' for t in physics['tendons']],tip_site='tip_site',semantics='ideal_tension'),
    task=dict(family='task.reach',original=cfg['task'],initializer=scene['initial'],
        control_period_s=scene['control_period_s'],duration_s=scene['duration_s'],
        command_intervals=round(scene['duration_s']/scene['control_period_s']),acceptance=dict(holding_steps=[0])))
atomic_json(folder/'settings.json',settings)
print(json.dumps({k:dict(status=v['acceptance']['status'],metrics=v['acceptance']['metrics']) for k,v in summary.items()}))
